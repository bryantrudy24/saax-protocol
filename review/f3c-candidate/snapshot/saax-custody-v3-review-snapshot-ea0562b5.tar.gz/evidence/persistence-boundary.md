# SAAX Pilot — Persistence Boundary (Gap 3 evidence)

**Date:** 2026-10-16 · **Instance:** isolated local testnet route-server (127.0.0.1:8899, SAAX_ESCROW_BACKED=1, chain 84532)
**Purpose:** precise statement of what is durable vs memory-only on the escrow-backed pilot path, plus the focused restart-test result.

---

## 1. Durable (survives restart)

| Record | Store | Mechanism | File |
|---|---|---|---|
| Accepted operations (escrow-access) | JSON file, atomic rename | `loadLedger()` / `persistLedger()` (write tmp + rename) | `data/escrow-access-ledger.json` (path: `SAAX_ESCROW_LEDGER`) |
| Nonce consumption (access nonce) | same ledger row | consumed at `acceptOperation` (durable acceptance, NOT external execution) | same |
| Reconcile outcomes (external-effect records) | same ledger row | `reconcile()` sets `externalEffect {occurred, txHash, state, at, block}` + status complete/failed | same |
| Commitment digests / escrow refs | same ledger row | `commitmentDigest`, `escrowId`, `custody`, `chainId` fields | same |
| On-chain truth (escrow state, funding, release) | Base Sepolia chain | the custody contract is the source of truth | custody `0x5a5472…ff5d` |

The access ledger is the durable acceptance store: an operation is durably accepted when its row (keyed by nonce) is persisted atomically. **Restart does not lose accepted operations or nonce consumption.**

## 2. Memory-only (lost on restart)

| Record | Store | Consequence |
|---|---|---|
| x402 idempotency rows (Day-8 gate) | in-memory `Map` fallback (`memStore`) when Supabase not configured | a restart forgets idempotency rows; the escrow path does not depend on them (it uses the access ledger) |
| Rate-limit rows | in-memory fallback | rate counts reset on restart (acceptable: single-participant pilot) |
| EIP-3009 nonce settled/in-flight guard (Day-9) | in-memory (route-server process state) | forgotten on restart — for the x402 IMMEDIATE-PAYMENT lane; the escrow lane never consumes EIP-3009 nonces |
| MPP rail state / rails registry | in-memory | re-registered at startup |

**Production target:** Supabase (`saax_router.idempotency_keys`, rate-limit tables) — the in-memory stores are the sanctioned no-blocking fallback. The pilot runs without Supabase; the **access ledger is the boundary that matters** and it is durable.

## 3. Focused restart test (raw output summary)

Script: `scripts/_restart-persistence-test.cjs` — dedicated port 8896, dedicated ledger `data/test-restart-ledger.json`, status action (no new funding) on the live funded escrow `0xe934dee4…cbe1`.

| Case | Result |
|---|---|
| P1 accepted durably (fresh nonce 77001) | PASS — `200 {ok:true, accepted:{status:"accepted"}}` |
| P1b ledger row persisted (atomic file) | PASS — row at `operations["77001"]`, status `accepted` |
| P2 identical retry after restart returns recorded result | PASS — `200 {ok:true, idempotent:true, recorded:{nonce:"77001",…}}` — external effect NOT repeated |
| P3 changed payload same nonce rejected | PASS — `409 {"error":"nonce 77001 already consumed with a DIFFERENT payload (conflict)"}` |
| P4 ledger intact after restart, status accepted | PASS — row survives, status `accepted` (no re-execution) |

**Restart cannot cause duplicate execution:** the nonce is consumed at durable acceptance (P1b, P4); after restart the identical retry returns the recorded result (P2) and a changed payload under the same nonce is rejected (P3) — so the same operation cannot be re-accepted, and the external effect (release via verdict path) cannot be re-triggered through the access lane.

## 4. Remaining limits (precise)

1. **The escrow-access ledger file is per-instance.** On the local instance it is `data/escrow-access-ledger.json` (durable on disk). On a deployed Railway service it must be pinned to a volume (`SAAX_ESCROW_LEDGER=/data/…`) — see `pilot/hosting-plan-base-sepolia.md` §1. Without a volume, a redeploy resets the ledger (the on-chain escrow state remains the source of truth for outcomes, but accepted-operation rows would be lost).
2. **Idempotency + rate-limit + EIP-3009 nonce guard are memory-only** in this no-Supabase configuration — precise limit: a restart forgets them; the escrow path's own protection (access-nonce ledger) is unaffected.
3. **The verdict/execution path** records tx references via `reconcile(nonce, outcome)` — durable in the ledger. A crash between broadcast and reconcile is covered by the recovery milestone's worker-replacement reconciliation (chain read), already demonstrated; the access ledger is the durable record the replacement reads.
4. **Lost-reference recovery** (a commitment whose ledger reference is lost) is **separate** work — not closed here.

## 5. Corrected claim: durable acceptance IS NOT completed execution (Day 26)

The prior §3/§4 wording conflated durable acceptance with completed execution.
Corrected semantics, established by `scripts/test-recovery-resume.cjs` (10/10
PASS against the real escrow-access module + a dedicated ledger + chain reads):

- **Durable acceptance + nonce consumption prove only that the operation was
  durably ACCEPTED** (`status:'accepted'`, `externalEffect:null`). They do NOT
  prove the external effect (e.g. the release transaction) occurred.

- **Resume semantics (explicit, not automatic):** after a crash/restart, a
  replacement worker must call `getAccepted(nonce)` (the durable row), determine
  the on-chain outcome by CHAIN READ (not by assumption), then `reconcile(nonce,
  outcome)` to record `status:'complete'|'failed'` + `externalEffect`. There is
  no automatic re-execution on restart; the operation resumes via the explicit
  recovery/reconcile path (the recovery-milestone worker-replacement proof).

- **Pending retries report pending truthfully:** a same-nonce retry while the
  operation is accepted-but-unexecuted returns `{ idempotent: true, recorded }`
  where `recorded.status === 'accepted'` and `recorded.externalEffect === null`
  — it NEVER fabricates a completion. The caller's status query (`queryStatus`)
  returns the same truthful pending record.

- **Three broadcast states distinguished (test coverage):**
  A) accepted, never broadcast — restart reads pending; replacement chain-reads
     (effect not occurred), executes, reconciles; re-reconcile is idempotent.
  B) broadcast WITH durably stored hash — restart reads complete with the
     durable txHash; no re-broadcast.
  C) broadcast BEFORE durable hash — the ledger never fabricates a hash or a
     completion; the authoritative outcome is the caller's chain read. This is
     the preserved lost-reference limitation (see §4.4 and the recovery
     milestone's bounded claim); absent receipts are NEVER inferred as
     non-broadcast.

- **Restart cannot cause duplicate execution:** because the nonce is consumed
  at durable acceptance, a restarted worker that reconciles the same nonce
  cannot re-accept or re-execute it (reconcile on a complete record is
  idempotent; a same-nonce retry returns the recorded row).
