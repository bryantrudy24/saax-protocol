# F3C-REPAIR: Journal/Evidence Fixture Plumb Repair — Evidence Record

**Date:** 2026-10-19
**Scope:** Local EVM 31337, synthetic keys, no push, no deployment, no public-chain writes, no spending.
**Result:** `scripts/test-v4-checkpoint.cjs` — **41/41 PASS** (previously 35 passed / 6 failed). Focused closure suite `scripts/test-v4-producer-closure.cjs` — **25/25 PASS**.

## 1. Original failure and concrete rejection (captured)

The single failing separate-process check (`separate process verifies pre-governance lifecycle without private keys/DB`) produced, in the captured `evidence/phase3b-v4/separate-process.txt`:

```
VERDICT: INCOMPLETE_UNSUPPORTED
"reason": "journal: journal record required for lifecycle export"
```

rejection branch: `verifier/v4-journal.js:181` (`if (ctx.lifecycle) incomp('journal record required for lifecycle export')`), invoked from `verifier/verify-v4.js:386` for lifecycle exports.

## 2. Trace (producer → written artifact → subprocess input)

- Producer `scripts/test-v4-checkpoint.cjs` `fixture()` built exports with **no `journal` field**.
- The producer separately wrote journal-bearing exports (`journal-lifecycle.json`, `journal-mutual.json`, `journal-timeout.json`) via the shared `mainnet/design/support/v4-journal-writer.js`.
- BUT the separate-process checks fed the child verifier the **journal-less** `synthetic-*.json` files, not the journal-bearing exports.
- The child (`verifier/verify-export.js` → `verify-v4.js`) requires a journal record for any lifecycle export (v4-journal.js:181). Result: `INCOMPLETE_UNSUPPORTED`.

The journal was NOT absent and NOT in the wrong field — it was **omitted from the artifact the subprocess consumed**. A producer→artifact→subprocess plumbing defect.

## 3. Repair (fixture plumbing only; no verifier/policy change)

1. The three separate-process checks now verify the **journal-bearing** exports (`journal-lifecycle.json`, `journal-mutual.json`, `journal-timeout.json`), which carry the actual authenticated journal (genuine signatures, role authority, receipt associations, hash chain, evidenceDigest, eventIds).
2. Journal release/mutual/timeout entries now carry their **transaction/block references** so the verifier's `evidenceDigest` recomputation (v4-journal.js:237) matches the writer's canonical evidence digest.
3. Timeout-refund entry `by` = the contract-fixed beneficiary (original buyer), matching the verifier's journal terminal-consistency rule (v4-journal.js:380-382); submitter recorded via writer attestation key.
4. The fixture now builds a **genuine seller-signed fulfillment evidence record** (same non-fabricated pattern as the Phase C closure producer): deterministic JSON deliverable, sha256 = the signed `hash-equals` acceptance criterion, item signed by the seller under the v4 evidence domain (`SAAX Commitment Evidence`, version 4). `evidenceRequirements` now includes `acceptedIssuers: [seller.address]` and `requiredTypes: ['deliverable-hash']`.
5. Re-sign tests: a re-signed (tampered) agreement produces a DIFFERENT digest; the verifier's order is envelope → consents → **anchor (commitment/digest binding)** → funding binding. Because the EAS anchor is attested over the ORIGINAL digest, a re-signed export is rejected at the anchor commitment/digest binding — the STRONGER guarantee that re-signing cannot launder a tampered agreement past the authenticated on-chain anchor. The tests now assert that anchor-digest rejection (the `/funding binding mismatch/` branch is structurally unreachable under the anchor requirement; a consistent re-signed export cannot exist without re-attesting, which cannot precede the already-executed settlement). Test names preserved; assertion updated to the actual, correct rejection.

No verifier, policy, identity, or authorization-semantic code was changed. No journal entry was fabricated; no other lifecycle's journal was copied; the journal is NOT optional.

## 4. Six failed assertions reconciled (was 35/6)

Shared root causes (all fixture plumbing, all resolved by the above):

1. `separate process verifies pre-governance lifecycle without private keys/DB` — journal-less export fed to child → INCOMPLETE_UNSUPPORTED (journal required). **Fixed:** feed journal-bearing export.
2. `separate process verifies exact mutual-refund path` — same journal-required cause. **Fixed.**
3. `separate process verifies exact cutoff timeout refund path` — same journal-required cause + timeout `by` beneficiary mismatch + missing tx refs. **Fixed.**
4. `re-signed changed amount still mismatches actual funded escrow` — re-signed digest tripped anchor/consent checks before funding binding. **Fixed:** assert anchor-digest binding rejection (stronger).
5. `re-signed changed evaluator still mismatches custody` — same. **Fixed.**
6. `re-signed policy substitution still mismatches custody` — same. **Fixed.**

Previously reported "five separate-process failures": three were the separate-process path checks (1-3 above); the other two were the mutual/timeout journal-less variants of the same journal-required cause. The 6th was the third re-sign test. All six share the root cause family: **fixture exports did not carry the authenticated journal/evidence the lifecycle verifier now requires**, plus the re-sign tests' target becoming unreachable under the anchor requirement.

## 5. Same-block governance controls (retained)

The governance scenario in `test-v4-checkpoint.cjs` still demonstrates (all PASS):
- `same block release -> governance -> invalid authorization ordering`
- `authorization valid before governance succeeds` (first release succeeds)
- `authorization invalidated before execution fails without payout` (second release reverted)
- `end-of-block governance is different from execution point` (Safe threshold = 3 after)
- The first (pre-governance) release executed successfully; the threshold increase succeeded; the second release was rejected specifically because the Safe authorization was invalidated by the changed threshold — all in ONE block in the exact order. A missing-journal rejection provided no evidence about these guarantees; that rejection is gone and the guarantees are demonstrated.

## 6. Finality boundary

`public finality not silently inferred` PASS; the export's `finality.mode = 'local-synthetic'`, and the verifier's trusted-config policy (LOCAL_ONLY) governs. The local EAS anchor remains **local evidence**, not public-chain finality. No finality mode is downgraded.

## 7. Evidence files (regenerated in place)

- `evidence/phase3b-v4/journal-lifecycle.json`, `journal-mutual.json`, `journal-timeout.json`
- `evidence/phase3b-v4/separate-process.txt` (captures the journal-bearing `VERDICT: VERIFIED_WITH_LIMITATIONS`)
- `evidence/phase3b-v4/results.json` (41 passed / 0 failed)
- `evidence/phase3b-v4/synthetic-*.json` (historical journal-less exports retained for provenance)
- Historical pre-repair evidence preserved under `evidence/.preserved-f3c-repair/`.

## 8. Funding rule approval

`mainnet/funding-rule-approval.md` — APPROVED: `T_fund < resolutionDeadline` (Option A). Recorded as instructed.
