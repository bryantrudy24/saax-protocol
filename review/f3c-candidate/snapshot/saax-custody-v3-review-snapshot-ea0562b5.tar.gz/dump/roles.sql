-- SAAX Protocol — Day 8 migration: roles.sql (self-hosted Postgres roles)
-- Reconstructed from the Supabase platform project. The platform runs:
--   authenticator (login, no inherit) -> switches to anon | authenticated
--   service_role (bypassrls) — the key SAAX Protocol's store uses
--   anon / authenticated (no-login roles, RLS subjects)
--
-- Self-hosted: the store client authenticates to PostgREST with a JWT carrying
-- role=service_role (the operator key in .env), which PostgREST maps to the
-- `service_role` role here. Roles are NO-LOGIN except `authenticator`.
BEGIN;

DO $$
BEGIN
  IF NOT EXISTS (SELECT FROM pg_roles WHERE rolname = 'authenticator') THEN
    CREATE ROLE authenticator NOLOGIN NOINHERIT;
  END IF;
  IF NOT EXISTS (SELECT FROM pg_roles WHERE rolname = 'anon') THEN
    CREATE ROLE anon NOLOGIN;
  END IF;
  IF NOT EXISTS (SELECT FROM pg_roles WHERE rolname = 'authenticated') THEN
    CREATE ROLE authenticated NOLOGIN;
  END IF;
  IF NOT EXISTS (SELECT FROM pg_roles WHERE rolname = 'service_role') THEN
    CREATE ROLE service_role NOLOGIN BYPASSRLS;
  END IF;
END $$;

-- platform wiring: authenticator switches to anon/authenticated
GRANT anon, authenticated TO authenticator;

-- PostgREST anonymous role: anon (brief requirement)
-- (PostgREST is configured PGRST_DB_ANON_ROLE=anon; the store uses
--  role=service_role via the JWT.)

COMMIT;