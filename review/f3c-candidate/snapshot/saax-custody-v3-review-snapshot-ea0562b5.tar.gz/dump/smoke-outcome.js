// Console smoke test for outcome logging (run from saax-protocol/: node --env-file=.env dump/smoke-outcome.js)
const store = require('../endpoint/store.js');
const ol = require('../endpoint/outcome-log.js');
(async () => {
  console.log('start');
  const client = store.buildStoreClient();
  console.log('client', !!client, client && client.schema);
  ol.setStoreClient(client);
  const r = await ol.logOutcome({
    request_id: 'smoke-test-2',
    capability: 'security scan',
    supplier_ids: ['111', '222'],
    supplier_scores: [90, 80],
    selected_supplier: '111',
    weights_used: { reputation: 0.6, freshness: 0.2, price: 0.2, formula: 'linear' },
    shrinkage_applied: false,
  });
  console.log('logOutcome ->', JSON.stringify(r));
  const q = await client.from('ranking_outcomes').select('request_id,capability,supplier_ids,supplier_scores,weights_used,shrinkage_applied').eq('request_id', 'smoke-test-2');
  console.log('readback ->', q.error ? ('ERR ' + q.error.message) : JSON.stringify(q.data));
  process.exit(0);
})().catch(e => { console.error('FAIL', String(e)); process.exit(1); });