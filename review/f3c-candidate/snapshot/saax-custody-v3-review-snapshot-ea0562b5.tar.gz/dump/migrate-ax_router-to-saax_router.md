# SAAX Protocol — Schema Migration: ax_router → saax_router

> **DO NOT RUN AUTOMATICALLY.** This file documents the manual migration procedure
> for an operator who already has a live database with the OLD schema (`ax_router`).
> It is written for the Postgres 16 / PostgREST stack in `docker-compose.yml`
> (services: `saax-db`, `saax-postgrest`).

## Background

The project was renamed from **AX Router** to **SAAX Protocol**.
As part of the rename, the Postgres schema was renamed from `ax_router` to `saax_router`:

- `dump/schema.sql` — schema definition now uses `saax_router`
- SQL queries across `endpoint/` — schema-qualified references now use `saax_router.*`
- `docker-compose.yml` — `PGRST_DB_SCHEMA=saax_router`, `POSTGRES_DB=saax_router`
- `.env.example` — `POSTGRES_DB=saax_router`

A **fresh** database (created from `dump/schema.sql` or `docker compose up -d` with the
init SQL mounted) already has the correct `saax_router` schema — no migration needed.

An **existing** database created before the rename still has `ax_router`.
Migrate it with the steps below.

## Pre-flight

Connect as a superuser to the old database (the compose stack publishes Postgres on
host port 5433):

```bash
psql -h localhost -p 5433 -U postgres -d postgres
```

Confirm the old schema exists and the new one does not:

```sql
SELECT schema_name FROM information_schema.schemata ORDER BY schema_name;
-- expect: ax_router present, saax_router absent
```

## Migration steps

### Step 1 — Create the new schema

```sql
CREATE SCHEMA IF NOT EXISTS saax_router;
```

### Step 2 — Copy every table (and its data) from ax_router

```sql
-- Copy tables individually to preserve data. Repeat for each table in ax_router:
CREATE TABLE saax_router.<table> (LIKE ax_router.<table> INCLUDING ALL);

INSERT INTO saax_router.<table> SELECT * FROM ax_router.<table>;
```

For a compact one-shot copy (Postgres 15+):

```sql
DO $$
DECLARE r record;
BEGIN
  FOR r IN SELECT tablename FROM pg_tables WHERE schemaname = 'ax_router'
  LOOP
    EXECUTE format('CREATE TABLE saax_router.%I (LIKE ax_router.%I INCLUDING ALL)', r.tablename, r.tablename);
    EXECUTE format('INSERT INTO saax_router.%I SELECT * FROM ax_router.%I', r.tablename, r.tablename);
  END LOOP;
END $$;
```

### Step 3 — Recreate indexes, sequences, and grants

```sql
-- Indexes (names were renamed in dump/schema.sql to saax_router_*):
CREATE INDEX IF NOT EXISTS saax_router_agents_active_idx ON saax_router.agents USING btree (active);
CREATE INDEX IF NOT EXISTS saax_router_agents_name_idx  ON saax_router.agents USING btree (name);

-- Sequences (adjust if any table uses a serial/identity that was copied by reference):
SELECT setval('saax_router.<table>_<col>_seq', (SELECT COALESCE(MAX(<col>),1) FROM saax_router.<table>))
  WHERE EXISTS (SELECT 1 FROM information_schema.sequences WHERE sequence_name = 'saax_router.<table>_<col>_seq');

-- Grants: replicate whatever roles/grants applied to ax_router (see dump/roles.sql).
```

### Step 4 — Re-point the application and verify

```bash
# .env (real secrets file — value names only, never print values):
#   POSTGRES_DB=saax_router

# docker-compose.yml already uses:
#   POSTGRES_DB: saax_router
#   PGRST_DB_SCHEMA: saax_router
#   PGRST_DB_URI: postgres://postgres:${POSTGRES_PASSWORD}@saax-db:5432/saax_router
```

Restart the stack:

```bash
docker compose down
docker compose up -d
```

Verify the API answers with the new schema:

```bash
curl -s http://localhost:3000/agents?select=agent_id | head -5
```

### Step 5 — Drop the old schema (only after verification)

```sql
-- Run ONLY after confirming the new schema serves the API and all suites pass:
DROP SCHEMA ax_router CASCADE;
```

## Rollback

If anything breaks after the copy and before the drop, revert `.env` to
`POSTGRES_DB=ax_router`, restart `docker compose`, and confirm the API serves
the old schema again. The old schema is untouched until Step 5.