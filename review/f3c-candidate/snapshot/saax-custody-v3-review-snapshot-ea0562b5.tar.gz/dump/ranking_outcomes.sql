-- SAAX Protocol — Sprint 2 Item 1: ranking outcome logging
--
-- Outcome logging table for the ranking engine tuning sprint.
-- Every time the ranking engine returns a ranked list, a row is inserted here
-- capturing: the ordered supplier list, the computed scores, which supplier
-- was selected, the EXACT weight configuration used at ranking time
-- (weights_used), whether shrinkage was applied, and — once settlement is
-- observed — the outcome (success | failure | dispute), routing fee and
-- settlement rail.
--
-- Security: RLS ENABLED, ZERO policies -> service-role only (matches
-- idempotency_keys / rate_limits; the store client authenticates with a
-- role=service_role JWT). Tuning analysis and weight proposals stay INSIDE
-- this Postgres instance (trade-secret protection; never exposed via API).

BEGIN;

CREATE TABLE IF NOT EXISTS saax_router.ranking_outcomes (
  id                  uuid primary key default gen_random_uuid(),
  request_id          text not null,              -- unique per demand request
  capability          text not null,
  supplier_ids        text[] not null,            -- ordered list returned by ranking
  supplier_scores     numeric[] not null,         -- corresponding computed scores
  selected_supplier   text,                       -- which supplier was chosen
  weights_used        jsonb not null,             -- snapshot of weights at ranking time
  shrinkage_applied   boolean not null default false,
  outcome             text,                       -- 'success' | 'failure' | 'dispute' | null
  outcome_timestamp   timestamptz,
  routing_fee_usd     numeric,
  settlement_rail     text,                       -- 'x402' | 'mpp' | 'unsupported'
  created_at          timestamptz not null default now()
);

-- Indexes (brief): on request_id and outcome.
CREATE INDEX IF NOT EXISTS ranking_outcomes_request_id_idx ON saax_router.ranking_outcomes (request_id);
CREATE INDEX IF NOT EXISTS ranking_outcomes_outcome_idx    ON saax_router.ranking_outcomes (outcome);

-- RLS: enabled, ZERO policies (service-role only via BYPASSRLS).
ALTER TABLE saax_router.ranking_outcomes ENABLE ROW LEVEL SECURITY;

-- Grants: mirror the strict tables (idempotency_keys / rate_limits) — only
-- service_role (and owner) may touch these rows. anon/authenticated get
-- NOTHING: tuning analysis, weight proposals and outcome data are trade
-- secrets and never leave this database.
GRANT SELECT, INSERT, UPDATE, DELETE ON saax_router.ranking_outcomes TO service_role;

COMMIT;