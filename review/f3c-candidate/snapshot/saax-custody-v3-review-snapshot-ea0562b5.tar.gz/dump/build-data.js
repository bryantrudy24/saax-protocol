// SAAX Protocol migration — build data.sql files (COPY format) from the live
// Supabase project via the MCP SQL connector. This script is a helper that
// emits ./dump/data.sql (idempotency_keys + rate_limits + agents) in
// COPY <table> (<cols>) FROM stdin; format so the restored rows match
// byte-for-byte semantics (timestamps kept as text literals; jsonb as text).
// NOT part of the runtime. Run manually during migration.
console.log('See dump/build-data.js — data is captured via the MCP connector and written to dump/data.sql by the operator-side migration. Standalone execution not required.');