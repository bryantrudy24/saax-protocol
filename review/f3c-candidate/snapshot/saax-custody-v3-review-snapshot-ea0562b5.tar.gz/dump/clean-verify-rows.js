// Clean stale verify rows from the Docker store, then run one clean pass.
const fs = require('fs');
const path = require('path');
(async () => {
  const env = fs.readFileSync(path.join(__dirname, '..', '.env'), 'utf8');
  const key = (env.match(/^SAAX_POSTGREST_KEY=(.+)$/m) || [])[1]?.trim();
  process.env.POSTGREST_URL = 'http://localhost:3000';
  process.env.SAAX_POSTGREST_KEY = key;
  const store = require('../endpoint/store.js');
  const client = store.buildStoreClient();
  for (const k of ['db-verify-key-1', 'db-verify-rpc-probe']) {
    try { await client.from('idempotency_keys').delete().eq('key', k); } catch (e) { console.log('clean ' + k + ' err ' + e.message); }
  }
  try { await client.from('rate_limits').delete().in('bucket_key', ['203.0.113.99', '0xDbVerifyWallet000000000000000000000000000001']); } catch (e) { console.log('clean rl err ' + e.message); }
  console.log('cleaned');
  process.exit(0);
})().catch(e => { console.error(e.message); process.exit(1); });