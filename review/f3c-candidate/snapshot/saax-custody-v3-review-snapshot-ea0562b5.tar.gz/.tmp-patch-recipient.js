// one-off: path-aware authorization recipient in test-gateway.js (no backticks in strings)
const fs = require('fs');
const p = 'scripts/test-gateway.js';
let c = fs.readFileSync(p, 'utf8');

const old = "  const signerAddress = gateway.getSignerAddress() || gateway.getVaultAddress() || gateway.getSellerAddress();\n  const vaultAddress = gateway.getVaultAddress();";
const next = "  // Path-aware authorization recipient (Day 14 mainnet):\n  //   eip3009: the TRANSFER destination is the VAULT (to = vault) - the\n  //            signed 'to' must be the cold storage address.\n  //   eip2612: the PERMIT spender is the SIGNER (hot broadcaster) - the\n  //            signed 'to' is the signer; the vault is the transferFrom pull\n  //            destination (enforced server-side).\n  const signerAddress = gateway.getSignerAddress() || gateway.getVaultAddress() || gateway.getSellerAddress();\n  const vaultAddress = gateway.getVaultAddress();\n  const authRecipient = ACTIVE_SIG_PATH === 'eip3009'\n    ? (vaultAddress || signerAddress)\n    : signerAddress;";
if (!c.includes(old)) { console.error('RECIPIENT BLOCK NOT FOUND'); process.exit(1); }
c = c.replace(old, next);

const callSites = [
  'signAuthorization(buyerAccount, signerAddress, amountRaw, domain, {',
  'signAuthorization(attackerAccount, signerAddress, amountRaw, domain, {',
];
let n = 0;
for (const cs of callSites) {
  const rep = cs.replace('signerAddress, amountRaw', 'authRecipient, amountRaw');
  const hits = c.split(cs).length - 1;
  c = c.split(cs).join(rep);
  n += hits;
}
fs.writeFileSync(p, c);
console.log('recipient patched; call sites replaced:', n);
console.log('authRecipient refs:', (c.match(/authRecipient/g) || []).length);
console.log('remaining old-pattern call sites:', (c.match(/signAuthorization\((buyerAccount|attackerAccount), signerAddress, amountRaw/g) || []).length);