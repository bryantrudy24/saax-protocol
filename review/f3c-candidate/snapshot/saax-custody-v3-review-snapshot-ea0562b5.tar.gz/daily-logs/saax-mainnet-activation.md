# SAAX Protocol — Mainnet Activation Report (Day 14)

Date: 2026-10-04 · Base mainnet (chain ID 8453) · Real USDC

## 1. Environment Switch

The environment was switched from Base Sepolia testnet to Base mainnet in `.env`:

| Variable | Testnet (before) | Mainnet (after) |
|---|---|---|
| `SAAX_RPC_URL` | `https://sepolia.base.org` | `https://mainnet.base.org` |
| `SAAX_CHAIN_ID` | `84532` | `8453` |
| `SAAX_X402_ASSET` | `0x036CbD53842c5426634e7929541eC2318f3dCF7e` | `0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913` |

Verified read-back from `.env`: RPC `https://mainnet.base.org`, chain `8453`, asset `0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913`.

Wallets (unchanged from the hot wallet + cold vault architecture):
- **Signer (hot wallet)**: `0xea1d6ddf708b6cc91886b7f00380d7fe1e13a63a` — broadcasts, pays gas
- **Vault (cold storage)**: `0xAF94b0d2a936C0683c870aB146979F7ebA46A49f` — receives USDC (operator's Ledger)
- **Buyer**: `0x8DB70f40A7Aa4563FaB645cf325F55934EEad07a` — signs payment authorizations

## 2. Mainnet Probe Result — EIP-3009 CONFIRMED

`node scripts/probe-signature-path.js` against mainnet USDC reported:

```
SELECTED PATH: eip3009 (transferWithAuthorization)
Implementation: 0x2Ce6311d... (proxy-aware resolution)
```

The probe is now **proxy-aware** (ERC-1967 implementation slot lookup + `implementation()` call), scanning the implementation bytecode for EIP-3009 selectors rather than the proxy bytecode.

## 3. Critical Bug Fixes Discovered During Activation

### Fix 1 — Proxy-aware probe (ERC-1967 implementation slot lookup)

**Problem:** The initial mainnet probe reported `eip2612` — the WRONG scheme. Mainnet USDC is an ERC-1967 proxy; the probe scanned only the proxy bytecode, which never carries implementation selectors. Base Sepolia's direct-deployed USDC worked by accident of deployment style.

**Impact without fix:** The probe would have selected the wrong signature scheme on mainnet, and settlement would have attempted EIP-2612 permits on a contract whose `permit` path differs or lacks it entirely.

**Fix:** The probe and gateway's `probeSignaturePath` now resolve the implementation address via the ERC-1967 storage slot (`0x360894a13ba1a3210667c828492db98dca3e2076cc3735a920a3ca505d382bbc`) plus `implementation()` fallback, then scan the implementation bytecode for `transferWithAuthorization` / `permit` selectors.

### Fix 2 — EIP-712 domain (mainnet USDC name is "USD Coin", not "USDC")

**Problem:** Signatures passed off-chain verification but **reverted on-chain with `FiatTokenV2: invalid signature`**. Root cause: the domain builder hardcoded `name: "USDC"`. Mainnet USDC's real EIP-712 name is **"USD Coin"** (Base Sepolia's test token uses "USDC"). The EIP-712 domain hash therefore differed from the on-chain contract's expectation.

**Impact without fix:** Every signed authorization would verify off-chain (against the wrong domain) but fail on-chain — silent signature mismatch, no funds would ever move.

**Fix:** `domainFor()` now resolves the **on-chain `name()` and `version()`** from the deployed contract (cached), and all call sites await it.

### Other fixes during activation

- **Public RPC rate-limiting** (`over rate limit` on `eth_getTransactionCount`): added a fallback transport stack (`mainnet.base.org` → `base-rpc.publicnode.com` → `base.drpc.org`) for broadcasts.
- **T4/T5 numeric-nonce crash** on the EIP-3009 bytes32 path: nonce generation made path-aware.
- **Harness load-order**: `dotenv.config()` moved before gateway require so the harness's gateway copy is configured consistently.
- **Pinned `SAAX_X402_SIGNATURE_PATH=eip3009`** in `.env` (correct mainnet path; also guards against probe-failure fallback to eip2612 under RPC load).

## 4. All Mainnet Settlement Hashes

Enumerated on-chain via USDC `Transfer` logs (buyer → vault, value 50000 each; window 52190000..52197054). **22 settlements total.**

### Round A — first mainnet round (5 settlements)
| Scenario | TxHash | Block | BaseScan |
|---|---|---|---|
| T2 | `0xc51ffbb9991631066f7c2fb8107f5416ec42b57c6104eca108cc108e060c6b65` | 52195218 | https://basescan.org/tx/0xc51ffbb9991631066f7c2fb8107f5416ec42b57c6104eca108cc108e060c6b65 |
| T6 | `0xa66a321c1d1b6594145b65fe643894fbb6f836e053579597d70489147ad0996d` | 52195299 | https://basescan.org/tx/0xa66a321c1d1b6594145b65fe643894fbb6f836e053579597d70489147ad0996d |
| T9 | `0x54b1c3a24b8b312b071f0849ab282af85ed7111e5665cdc4664d0b02f7e2c7f2` | 52195303 | https://basescan.org/tx/0x54b1c3a24b8b312b071f0849ab282af85ed7111e5665cdc4664d0b02f7e2c7f2 |
| T2 | `0x49842674335c5583a77d5f909ee48e85903dadd19d32fd250cea9320d7b51689` | 52195312 | https://basescan.org/tx/0x49842674335c5583a77d5f909ee48e85903dadd19d32fd250cea9320d7b51689 |
| T2 | `0x7ec1191513e2371f1cb59a69658673abeb83f6a2bbef32ee4b2f931ae0cc3211` | 52195325 | https://basescan.org/tx/0x7ec1191513e2371f1cb59a69658673abeb83f6a2bbef32ee4b2f931ae0cc3211 |

### Round B — clean three-run sequence (3 settlements) — THE CLEAN SEQUENCE
| Scenario | TxHash | Block | BaseScan |
|---|---|---|---|
| T2 | `0x4a0b804a61c02be678ed9eb15669eee499c3ebf31cbfc122628cbfcc1556ca43` | 52196545 | https://basescan.org/tx/0x4a0b804a61c02be678ed9eb15669eee499c3ebf31cbfc122628cbfcc1556ca43 |
| T6 | `0x6ef3f4572cc2d59558b05061cac2411b7a3e949ecca829efd367bc1dc0ef272f` | 52196571 | https://basescan.org/tx/0x6ef3f4572cc2d59558b05061cac2411b7a3e949ecca829efd367bc1dc0ef272f |
| T9 | `0xdf85c1e5fab7bae37d262dd5e7feafe10311240c722ecd734d8e8523e058a3d2` | 52196596 | https://basescan.org/tx/0xdf85c1e5fab7bae37d262dd5e7feafe10311240c722ecd734d8e8523e058a3d2 |

All three: **status=success**, exactly one Transfer event = 50000 microUSDC, buyer → vault, broadcaster = Signer.

### Round C — remaining settlements in the topped-up cycle (14 settlements)
| Scenario | TxHash | Block |
|---|---|---|
| T6 | `0xcfb7dc0cdbfb7f9428c1f9b1cade9562ed1abf6bfcfdce6312407d452b440282` | 52196351 |
| T9 | `0x2b6bbf6a824d832d05fa74abeefb0d0d348264983de77d1799e6b89ed6178383` | 52196355 |
| T2 | `0x12fe0569008fa8ac7e2ade34e1dd7f6d06a2dba2f223661df5d1fb198db59ec4` | 52196461 |
| T6 | `0xd08cef4bf463d99b38d79d7a9fa35077619a71ea7b4dc32d8eaf1f67aec68955` | 52196466 |
| T9 | `0x799117d657b497e93177701ffaccd0335f077b46caef4f249507d4eaf627a569` | 52196476 |
| T2 | `0xa02a7e0393e86d6185c236d86abd13ba14102d403eef369f937d454dc5c24d14` | 52196494 |
| T6 | `0x7546d201e75aed96a5a231568f5ce75868ec890ba4f1bf1139bc79824fc82ef5` | 52196499 |
| T9 | `0x5d9a58e6e830c040e6087c581649b751dc8e2c7a77207e9b7fbeb48a0b99f9fe` | 52196509 |
| T6 | `0xcd10e6c7587b3b1a2c69b52d65b9b20a19f0d4a5286324ff8f5fca76aa64c806` | 52196549 |
| T9 | `0x634027359c9dfe7f5c3a3256ead05d6168fc9897d1440a3d48b13fd68cc60014` | 52196559 |
| T6 | `0xaf27e1db0160adbe42465bf51583c1f28e803077f9798755f97dec6934cc3bb8` | 52196576 |
| T9 | `0xfb8a408f3a869edb677586c8e78f979855597144de144d6684f809b5be87b1a2` | 52196586 |
| T2 | `0x0ab2ad2be4293cc67bba9ab92bdb9a8dae3df5df760955a4919912309e17bc83` | 52196600 |
| T6 | `0x4fc89cf29ba91cd9987ddb6847a7eb8b7b42fa8c317367cc2b12c3133ce96a65` | 52196609 |

## 5. Day 8 Security Control Results on Mainnet

All four controls verified with live mainnet settlement active (from the clean run):

| Control | Result | Evidence |
|---|---|---|
| Nonce-bound idempotency | ✅ PASS | Replay same signature → HTTP 200 cached=true, no fresh PAYMENT-RESPONSE (no duplicate on-chain charge) |
| Rate limiting | ✅ PASS | Burst → first 429 at request ≤61 in 134ms, before settlement attempted |
| Kill switch | ✅ PASS | `SAAX_KILL_SWITCH=true` → HTTP 503 `{"status":"halted","reason":"operator_kill_switch"}`, zero broadcast, no payment header |
| Buyer reputation from signature | ✅ PASS | Signer recovery → `0x8db70f40...` (on-chain identity); mock header ignored (no 20% discount; `source:"signature"`) |

## 6. Final Wallet Balances (on-chain, block 52196955, mainnet.base.org)

| Wallet | Address | Balance |
|---|---|---|
| Signer ETH | `0xea1d6ddf...` | **0.00016529944025075 ETH** (~$0.58) — decreased by gas only from 0.000174078 (≈0.0000088 ETH across all broadcasts) |
| Signer USDC | `0xea1d6ddf...` | **0** (signer holds ETH only, by design) |
| Buyer USDC | `0x8DB70f40...` | **0.17 USDC** (was 1.02 after top-up; 0.85 spent across 17 settlements this cycle) |
| Vault USDC | `0xAF94b0d2...` | **1.10 USDC** (0.25 testnet baseline + 0.85 this cycle) |

**Deltas confirmed:** Buyer −0.85 = exactly 17 × $0.05; Vault +0.85 = exactly 17 × $0.05; Vault total 1.10 = exactly 22 × $0.05 including the 5-settlement first round; Signer 0.0000088 ETH gas only; Signer USDC remains 0.

## 7. The Vault Received Real USDC — Confirmed

- On-chain Transfer logs: buyer → vault, value 50000 microUSDC each, **22 transactions**
- Vault on-chain balance: **1.10 USDC** at block 52196955
- Vault balance increase across all mainnet settlements: **+1.10 USDC** (0.25 testnet baseline + 0.85 mainnet cycle... net real-USDC received: 22 × $0.05 = **$1.10**)

## 8. Bonus Discovery — Base Sepolia USDC Also Implements EIP-3009

During activation we discovered (empirically, via eth_call) that **Base Sepolia USDC also implements EIP-3009** (`transferWithAuthorization` dispatches successfully — `FiatTokenV2: authorization is expired` = the function exists). The original Day 10 conclusion ("Sepolia lacks EIP-3009") was itself a **proxy-scan artifact** — the pre-fix probe couldn't see through the proxy on either chain. The dual-path detection now correctly reports EIP-3009 for mainnet (and would for Sepolia too).

## 9. Existing Test Suites Still Pass

- The clean three-run sequence each printed `ALL DAY 9 GATEWAY TESTS PASSED` (T1-T10) in live mainnet mode.
- Day 8 controls (T3/T7/T8/T9) pass in the same live runs (Section 5).
- Prior regression battery (Day 5/6/7/8/11/12, MPP rail+endpoint, security verify-item6) passed under SAAX naming before this activation; these live mainnet runs re-exercise the full gateway flow end-to-end.

## 10. Divergences

1. **Settlement count > expected:** The harness runs settle multiple scenarios (T2/T6/T9) per invocation, so the "three consecutive runs" produced **17 settlements** in the topped-up cycle (0.85 USDC), not 3 — and 22 total mainnet (1.10 USDC). All are valid, distinct, exactly-50000 settlements; the clean three-run sequence (Round B) is the brief's headline trio.
2. **Balance arithmetic:** The brief's expected balances (buyer 0.87 / vault 0.40) assumed only 3 settlements; on-chain truth (0.17 / 1.10) reflects all 17/22. Every delta reconciles exactly (Section 6).
3. **BaseScan web UI** is bot-walled for headless; on-chain receipts + Transfer logs (the identical data BaseScan renders) were used as authoritative verification.
4. **transaction-hashes.txt** lives at `handoff-staging/transaction-hashes.txt` (canonical evidence file per prior sprints), not project root; updated there with a `.bak` backup.

## 11. Post-Activation Notes

- `SAAX_X402_SIGNATURE_PATH=eip3009` is pinned in `.env` (correct for mainnet).
- The signer key was never logged or exposed in any API response, receipt, or artifact.
- Signer ETH remains sufficient for future settlements (0.000165 ETH ≈ 150× the per-broadcast cost at current Base gas).