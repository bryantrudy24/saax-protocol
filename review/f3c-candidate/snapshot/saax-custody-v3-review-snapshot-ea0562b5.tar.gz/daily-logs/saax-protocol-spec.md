# SAAX Protocol Specification and Conformance Suite

## Conformance Suite

- Directory: conformance/
- Runner: conformance/runner/run-conformance.mjs
- Vectors: conformance/vectors/ (commitments, signatures, hashes, lifecycle, evidence, authority, settlement, errors)
- Counts: 10 commitment, 5 signature, 5 hash, 10 lifecycle, 5 evidence, 5 authority, 5 settlement, 10 error = 55 vectors
- Runner behavior: reads every JSON vector, invokes the corresponding implementation function, compares against expected; per-vector pass/fail, summary, exit 0 all-pass / 1 any-fail. Implementation target: local reference modules (endpoint/requirement.js, endpoint/evidence.js, endpoint/authority.js) or SAAX_IMPL_MODULE override.
- Fixtures: conformance/fixtures/keys/ (test-only keys, clearly marked)

## Evidence Vector Debugging (2026-10-06)

- Symptom: 53/55 vectors passing; two evidence vectors (evidence-satisfied-001, evidence-not-satisfied-002) returned insufficient_evidence instead of satisfied / not_satisfied.
- Diagnosis: direct invocation of evaluateCriterion returned invalid policy: requiredEvidenceType is required. The implementation validateVerificationPolicy mandates requiredEvidenceType, but all five evidence vectors criteria omitted it. Every evidence vector failed at the policy gate; the three vectors that expected insufficient_evidence passed by coincidence, the two expecting satisfied/not_satisfied failed.
- Additional defects found: (1) the stale vector expected insufficient_evidence but the shipped implementation returns not_satisfied for age failure; (2) the fresh vectors used a fixed wall-clock timestamp (2026-10-06T12:00:00Z) against the implementation real Date.now(), making them time-dependent and destined to go stale.
- Fix (vector-side, per the brief rule that the implementation is the shipped behavior): added requiredEvidenceType temperature-reading to the evidence vector criteria; corrected the stale vector expected outcome to not_satisfied; made the fresh vectors time-relative via a #NOW_MINUS_60S# placeholder resolved by the runner new resolvePlaceholders() function.
- Result: 55/55 passing, deterministic across runs. No implementation changes. No diagnostic instrumentation was ever added to the runner (diagnosis was done via direct invocation); the runner only change is the permanent placeholder-resolution feature.

## Implementation Changes

- conformance/runner/run-conformance.mjs: added resolvePlaceholders() (resolves #NOW# / #NOW_MINUS_60S# to run-time ISO timestamps) and wired it into loadVectors.
- No changes to endpoint/evidence.js, endpoint/authority.js, or any shipped protocol module.

## Landing Page Integration

- /spec serves spec/README.md; /spec/:path* serves individual spec files (vercel.json rewrite).
