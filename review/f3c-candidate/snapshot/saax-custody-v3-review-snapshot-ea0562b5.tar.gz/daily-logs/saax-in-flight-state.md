# SAAX In-Flight Commitment State — Sprint Record

Date: 2026-10-07
Commit: 9fe8d9f5 (+ 34ac0bf0 spec.html regeneration) — pushed to main
Deploy: Ready in 28s, aliased to https://saax-protocol.com

## The gap this state closes

When an agent's first attempt leaves the agent's machine and never returns a response, the agent cannot distinguish "the merchant never got it" from "the merchant is processing it right now." A naive retry with the same commitment ID races the merchant's accept path.

The rule added by this sprint: **an unknown outcome is a status check, not another POST.**

## The state machine addition

`in_flight` is now an explicit lifecycle state between `accepted` and `executing`:

- **Before:** `issued, authority_validated, accepted, executing, evidence_pending, ...`
- **After:** `issued, authority_validated, accepted, in_flight, executing, evidence_pending, ...`

Meaning: the merchant has received the commitment and is processing it, but the outcome is not yet known to the calling agent. Distinct from `executing` (merchant has begun fulfillment) — `in_flight` is specifically the window where the agent does not yet know whether the merchant accepted.

**Valid transitions:**
- `accepted → in_flight` — merchant receives the commitment creation request; the in_flight write is the durable lock
- `in_flight → executing` — merchant begins fulfillment
- `in_flight → failed` — merchant's processing fails
- `in_flight → expired` — merchant's processing window closes without resolution

## Agent-side rule (status check before retry)

`get_commitment_status` now returns a `next_action` field derived from the state:

| State | next_action | Meaning |
|---|---|---|
| not_found | `retry_safe` | The merchant never received it. The agent may retry the POST. |
| in_flight | `poll` | The merchant has it and is processing. Do not retry. Poll with exponential backoff. |
| executing | `poll` | The merchant is fulfilling. Do not retry. |
| fulfilled / settled / finalized | `stop` | Terminal success. Do not retry. |
| failed / expired / cancelled | `retry_with_new_id` | Terminal without fulfillment. Retry with a fresh commitment ID. |
| all other states | `poll` | Transitional. Continue polling. |

The tool description now states this rule explicitly: "Call this before retrying any commitment that timed out — an unknown outcome is a status check, not another POST."

## Merchant-side rule (specification)

Added to the commitment lifecycle specification (landing/spec.md section 5 and spec/lifecycle.md):

> A merchant that receives a commitment creation request **must write `in_flight` to durable storage before processing the request. The write is the lock.** A second request with the same commitment ID must return `in_flight` — not be processed again. The merchant is the authority on whether the commitment has entered the execution path. **If the merchant cannot durably track `in_flight`, it cannot participate in the commitment lifecycle.**

## Conformance vectors added (conformance/vectors/lifecycle/)

1. `lifecycle-accepted-in-flight-011` — accepted → in_flight is valid
2. `lifecycle-in-flight-executing-012` — in_flight → executing is valid
3. `lifecycle-in-flight-failed-013` — in_flight → failed is valid
4. `lifecycle-in-flight-expired-014` — in_flight → expired is valid
5. `lifecycle-status-in-flight-015` — get_commitment_status(in_flight) → next_action: poll
6. `lifecycle-status-not-found-016` — get_commitment_status(not_found) → next_action: retry_safe

The conformance runner's `transition` fn was extended: `accepted` gains `in_flight` in its valid-transition list; `in_flight` is a new key; status-lookup vectors dispatch to a next_action mapping.

## Verification results

1. **get_commitment_status with non-existent ID (live):** `{ status: "not_found", commitmentId: "0xab...", next_action: "retry_safe" }` ✅
2. **get_commitment_status with existing ID:** the local MCP smoke test seeds a record and asserts `{ commitmentId, state: "issued", next_action: "poll" }` — passing (24/24). The live endpoint's not_found path proves the same handler; a live existing-ID case requires a commitment-creation flow which the MCP surface intentionally does not expose (no create_commitment tool per constraints). ✅
3. **https://saax-protocol.com/spec:** renders "In-Flight Commitment Handling" (h2) with all subsections 5.1-5.5. ✅ (Page is served from pre-rendered landing/spec.html; regenerated from spec.md — see divergence 1.)
4. **Conformance suite:** 61 passed, 0 failed (55 existing + 6 new). ✅

## Changes by file

- `api/mcp.mjs` — LIFECYCLE_STATES + `in_flight`; `nextActionFor(state)` helper; get_commitment_status returns `next_action` (not_found/cached/row branches); tool description updated.
- `conformance/runner/run-conformance.mjs` — transition fn: status-lookup dispatch + in_flight transitions.
- `conformance/vectors/lifecycle/` — 6 new vectors.
- `landing/spec.md` — new section 5 "In-Flight Commitment Handling".
- `landing/spec.html` — regenerated from spec.md (the /spec route serves this pre-rendered file).
- `spec/lifecycle.md` — state table row, transitions, mermaid diagram.
- `scripts/test-mcp-tools.mjs` — **one assertion updated**: the success-path check previously required response keys to be exactly `{commitmentId,state}`; the sprint's protocol change adds `next_action`, so the assertion now requires `{commitmentId,state,next_action}` with `next_action === "poll"` for `issued`. This is a contract update to the new spec, not a test weakening (see divergence 2).

## Divergences

1. **`/spec` serves pre-rendered `landing/spec.html`, not `spec.md`.** The rewrite target is `/landing/spec.html` (a generated static page from an earlier sprint). Editing only spec.md did not change the live page. Resolved: regenerated spec.html from spec.md with the same template shell (head/CSS/footer preserved), committed as 34ac0bf0, redeployed. Verified live.
2. **One test assertion required updating** (`scripts/test-mcp-tools.mjs`): the get_commitment_status success check asserted the OLD response shape (exactly `{commitmentId,state}`). The brief's protocol change mandates `next_action` in the response, so the assertion was updated to the new contract (keys `{commitmentId,next_action,state}`, `next_action === "poll"` for issued). All other tests untouched; 24/24 pass.
3. **State vocabulary lives in `api/mcp.mjs` (`LIFECYCLE_STATES`), not in `endpoint/commitment.js`.** The brief's Step 1 said "Read endpoint/commitment.js and the store adapter. Add in_flight to the list of valid states." endpoint/commitment.js is the manifest-schema module and contains no state list; the lifecycle-state vocabulary is defined in api/mcp.mjs LIFECYCLE_STATES. The change was applied there. The commitment store schema is unchanged (state is a text column).
4. **Pre-existing dirty files excluded from this commit:** `daily-logs/day9-live-server.log`, `daily-logs/day9-settle-stderr.log` (tracked, modified in a prior sprint), and untracked `_NOTE.b64`/`saax-append.b64` (leftover base64 doc-append blobs). None were part of this sprint's changes. The staged commit contains only the intended files. The two .b64 files remain untracked and should be cleaned up separately.
5. Sandbox path workaround used per standing instruction (fs writes land in the sandbox; copied into the project via shell; sandbox copies deleted). Patch scripts removed after use.