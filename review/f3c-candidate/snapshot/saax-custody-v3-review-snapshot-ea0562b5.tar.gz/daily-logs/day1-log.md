> This log was written under the previous project name AX Router; the project is now SAAX Protocol.

SAAX Protocol — SPRINT 1 DAILY LOG
DAY 1 · Registry Query Foundation
Date: 2026-10-01 (run 485cad48)

WHAT WAS BUILT
- ethers.js query layer (Node v26, ethers v6) at saax-protocol/scripts/query-registry.js
  - Reads ERC-8004 IdentityRegistry at 0x8004A169FB4a3325136EB29fA0ceB6D2e539a432 on Base mainnet (chain 0x2105 / 8453)
  - Uses tokenURI(uint256) + ownerOf(uint256) per the canonical ABI (abis/IdentityRegistry.json from erc-8004/erc-8004-contracts@b9e466c)
  - Also enumerates the full registry via Registered(uint256 agentId, string agentURI, address owner) log events (eth_getLogs, 4k-block chunks to respect the 413 cap)
  - Resolves registration files: https://, ipfs://, data:application/json;base64 URIs (incl. Olas marketplace files)
- Supabase schema (project bryantrudy24's Project / codboejrwohkjidrrcgl):
  schema saax_router, table agents — agent_id PK, name, description, services jsonb,
  supported_trust jsonb, active bool, owner, token_uri, block_number, last_indexed
- Indexer pipeline: enumerate-registrations.js → enrich-agents.js → curate-agents.js → gen-compact-sql.js

WHAT WAS TESTED
- Base mainnet RPC reachable; chainId 0x2105 verified
- tokenURI/ownerOf calls return live URIs and owners (probe-registry.js)
- Full log scan 50,505,471..52,046,988 found 15,694 registrations (10,000+ agents)
- 308 enriched, deduped to 263 named, curated to 119 quality agents (distinct names + descriptions)

WHAT WAS STORED
- 119 real agents in saax_router.agents (Supabase), all named, all with services:
  - 86 Olas marketplace agents (LST services, A2A/MCP/agentWallet endpoints, reputation trust)
  - 14 Virtuals ACP agents (SYBIL security auditor, NuSHA, Apex Leviathan, aiworker-data, RunOnProof, etc.)
  - 8 Termix platform agents
  - 6+ independent (truthbear-gauge, Million Dollar Agent, NexusEval Worker, ...)
- 18 unique owner addresses; all active=true
- Proof: SELECT counts — total 119, unique owners 18, olas 86, termix 8, acp 14

WHAT IS MOCKED
- Reputation fields (reputation_score, feedback_count, last_feedback_timestamp) — Day 2 deliverable, unfilled
- Wallet/payment — placeholder by design (operator wires after Day 7)

WHAT BROKE / ROUTED AROUND
- eth_getLogs 413 Payload Too Large → chunked to 4k blocks w/ adaptive split
- Windows cmd shell quirks (no tail/head, && truncation) → separate calls, node files for generators
- Supabase payload size → compact 30-row SQL batches

WHAT IS NEXT
- Day 2: ReputationRegistry getSummary(uint256, address[], string, string) enrichment of all 119 agents
- Schema already has reputation_score, feedback_count, last_feedback_timestamp columns ready