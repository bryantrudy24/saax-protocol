# SAAX Public Endpoint — Vercel (MCP) + Railway (Settlement)

Date: 2026-10-05
Status: LIVE (settlement endpoint public; MCP endpoint public)

## 1. Vercel Deployment — MCP Discovery Endpoint

- **URL:** https://ax-router.vercel.app/mcp
- **Purpose:** MCP discovery (read-only protocol info, routing, commitments). No settlement.
- **Tools exposed (6):** get_protocol_info, get_routing_fee, ping, route_request, get_commitment, list_capabilities
- **serverInfo version:** 1.0.3 (read from package.json at runtime — single source of truth)
- **Status:** live, aliased to ax-router.vercel.app (production)

## 2. Railway Deployment — Settlement Endpoint

- **Project:** saax-route-server (id 8c23a8f5-e8f9-450b-bfe0-f3f391c7ae06)
- **Service:** saax-route-server (id 276e1929-e4c3-4682-8c9a-51448ec16898)
- **Public domain:** https://saax-route-server-production.up.railway.app
- **Start command:** `node endpoint/route-server.js` (Procfile)
- **Port binding:** `process.env.PORT || process.env.SAAX_PORT || 8080`, host `0.0.0.0` (the only permitted server code change; committed 5fa2ce6c)
- **Mode:** MOCK (SAAX_X402_MODE unset → default mock). No real settlement while in mock mode.

### Endpoints
- `GET /health` → 200 `{ok, mode, verifyMode, x402Mode, seller, killSwitch, store, rateLimitStore, rails, port}`
- `POST /route` → 402 x402 challenge (no payment header) or routed/resolved response (with valid payment)

## 3. Environment Variables (Railway)

Set via `railway variable set` (values from local .env, never committed):

| Variable | Value |
|---|---|
| SAAX_SIGNER_PRIVATE_KEY | (sealed secret — write-only) |
| SAAX_SIGNER_ADDRESS | 0x1FF7959FFD1fB97dd423986A470fbD65687be35a |
| SAAX_VAULT_ADDRESS | 0xAF94b0d2a936C0683c870aB146979F7ebA46A49f |
| SAAX_RPC_URL | https://mainnet.base.org |
| SAAX_CHAIN_ID | 8453 |
| SAAX_X402_ASSET | 0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913 |
| SAAX_X402_SIGNATURE_PATH | eip3009 |
| SAAX_SELLER_PRIVATE_KEY | (sealed secret) |
| SAAX_SELLER_ADDRESS | 0x983040F7D8Cd31807C0D5c00c0aD591B8Fc98271 |
| SAAX_TEST_BUYER_KEY | (sealed secret) |
| SAAX_BATCH_SETTLEMENT_ENABLED | false |
| SAAX_KILL_SWITCH | false |
| SAAX_TRUST_PROXY | true (required for rate limiting behind Railway's edge) |

**PORT:** NOT set — Railway provides it (the service binds 8080 by default when PORT absent).

## 4. Security Controls Verified on the Public Endpoint (2026-10-05)

All four Day 8 controls verified against https://saax-route-server-production.up.railway.app:

1. **Kill switch** — set SAAX_KILL_SWITCH=true + SAAX_X402_MODE=self → `POST /route` returned **503** `{"status":"halted","reason":"operator_kill_switch"}`. Verified in the live lane (self mode) — no settlement path executes while halted. Reverted immediately after the test (kill switch false, mode deleted → mock).
2. **Rate limiting** — SAAX_TRUST_PROXY=true (real client IP via X-Forwarded-For). 62 rapid requests: requests 1–60 → 402, **request 61 → 429** (`first429@61`), 62 → 429. Per-IP sliding window 60/min, in-memory store.
3. **Sanitization** — empty capability → **422** `{"error":"capability field empty after sanitization"}`.
4. **Idempotency** — 4 identical requests with same Idempotency-Key: all returned the **byte-identical cached response** (5609 bytes, same commitment 0xfac6013a, same railReference) — no re-processing, no duplicate settlement.

## 5. Hot-Wallet Exposure Trade-Off

- The **Signer private key** is now stored in Railway's environment (sealed). The Signer is a **hot wallet** holding ~0.00037 ETH (~$1.00, gas) on Base mainnet and signs live settlement broadcasts. Exposure surface: anyone with Railway dashboard access to this project can read the sealed env (with the right permission) — but the key is never in code, never in Git, and never in logs.
- The **Vault** (cold) receives settlement funds: 0xAF94b0d2a936C0683c870aB146979F7ebA46A49f. The vault key is NOT in Railway (it is not needed server-side; the signer only pays gas and moves buyer USDC to the vault).
- While SAAX_X402_MODE is unset (mock), no real money can move regardless of the env keys.
- Rotation procedure: scripts/signer-rotate.mjs (operator-approved flow).

## 6. Rollback Procedure (how to disable the public endpoint)

**Immediate halt (seconds):**
```
railway variable set SAAX_KILL_SWITCH=true   # 503 on every /route
```
**Full disable (no further requests served):**
```
railway service delete --service saax-route-server --yes
railway domain delete saax-route-server-production.up.railway.app --yes   # (or use the dashboard)
```
**Revert to local-only (remove public exposure, keep server):**
```
railway domain delete --service saax-route-server --yes
```
**For the Vercel MCP endpoint:**
```
vercel rm ax-router --yes   # from the project dir (removes the deployment)
```
Note: disabling Railway does not disable Vercel (they are independent); the MCP endpoint only reads, so the main money-movement surface is Railway /route.

## Divergences

1. **Infra env vars removed:** POSTGRES_PASSWORD, POSTGREST_JWT_SECRET, POSTGREST_URL, SAAX_POSTGREST_KEY were initially copied from .env (they point at a localhost Docker PostgREST) — they are NOT valid on Railway and caused the rate-limit/idempotency stores to fail-open (fetch failed). Deleted them; the server now uses its documented in-memory fallback (health shows store:in-memory, rateLimitStore:memory), making the gates enforceable. A real Supabase/PostgREST URL + service key can be added later for cross-instance enforcement.
2. **SAAX_TRUST_PROXY=true required** — without it, Railway's edge IP varies per request and the per-IP limiter never trips (proxy-hiding). The code's documented toggle fixes it.
3. **`railway variable delete` does not always auto-redeploy** — forced a `railway redeploy` to apply the env change.
4. **Secrets in transcript:** `railway variable list --json` returned raw secret values into the chat log (Railway CLI behavior). They are stored only in Railway's sealed env; nothing was written to files/code. Flagging for the record.
5. **Port shows 8080** on /health — Railway did not set PORT (or the service exposed 8080); the binding change added PORT support but the default path is serving fine.
6. **Mock vs live posture:** the public settlement endpoint runs in mock mode by design (SAAX_X402_MODE unset). Flip to self/live ONLY when the operator authorizes live demand; the kill-switch test above proves the halt path works in live mode first.## 7. Domain Migration — saax-protocol.com (2026-10-06)

### Custom domain
- **Domain:** saax-protocol.com (purchased on Namecheap; DNS managed by Namecheap default nameservers)
- **DNS records added** (Namecheap Advanced DNS; deleted the two defaults — CNAME www→parkingpage.namecheap.com and URL Redirect @→http://www.saax-protocol.com — first):

| Type | Host | Value | Purpose |
|---|---|---|---|
| A | @ | 76.76.21.21 | Vercel apex (https://saax-protocol.com) |
| A | www | 76.76.21.21 | Vercel www (https://www.saax-protocol.com) |
| CNAME | settlement | ouzkmbhv.up.railway.app | Railway settlement subdomain |
| TXT | _railway-verify.settlement | railway-verify=4235ec7e708b8490284901d7b4a350efb62c40246cf9177749b0fa85f5707254 | Railway ownership verification |

- **No TXT required by Vercel** (domain added via CLI; verification via A record).

### Verified domains and roles (all three resolving, operator-confirmed)
- `https://www.saax-protocol.com/mcp` — MCP discovery endpoint (Vercel, saax-protocol 1.0.3)
- `https://saax-protocol.com/mcp` — apex, **308 redirect** → www (Vercel)
- `https://settlement.saax-protocol.com/health` — settlement endpoint (Railway, mode self/live)

### server.json URL update
- Remote URL: `https://ax-router.vercel.app/mcp` → **`https://www.saax-protocol.com/mcp`**
- Version: **1.0.3** (server.json + package.json; npm publish completed; MCP registry re-published)

### Registry listing verification (2026-10-06T00:52:48Z)
- `io.github.bryantrudy24/saax-protocol` version **1.0.3** — **isLatest: true**, status **active**, remote **`https://www.saax-protocol.com/mcp`**
- 4 versions listed: 1.0.0 (placeholder, historical), 1.0.1 (vercel URL), 1.0.2 (vercel URL), 1.0.3 (branded URL, latest)

### Endpoint verification (this sprint)
- `POST https://www.saax-protocol.com/mcp` initialize → **200**, `serverInfo: {name: saax-protocol, version: 1.0.3}`
- `curl -I https://saax-protocol.com/mcp` → **308** → www.saax-protocol.com
- `GET https://settlement.saax-protocol.com/health` → **200** `{ok:true, mode:self, x402Mode:self, killSwitch:false, store:in-memory}`

### Railway variables
- **Operator checked the Railway web dashboard (no CLI list — standing constraint):** no variables reference `saax-route-server-production.up.railway.app`. **No updates needed.** The service's public domain is now `settlement.saax-protocol.com` (custom domain added; TXT verification completed).

### Divergences
- The `railway domain` CLI reported the settlement domain creation; the route change is applied via the custom-domain attachment, not via a variable.
- Vercel apex redirect: `saax-protocol.com` → `www.saax-protocol.com` (308) — the canonical MCP URL is the www form, matching the registry entry.