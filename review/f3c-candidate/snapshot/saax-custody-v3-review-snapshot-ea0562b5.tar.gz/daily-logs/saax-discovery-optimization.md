# SAAX Discovery Optimization — 2026-10-07

## Summary

Added a discovery layer to the SAAX site: expanded Schema.org markup on the landing page, machine-readable site guides for LLM crawlers (`/llms.txt`, `/llms-full.txt`), and explicit relationship-to-external-systems statements in the spec. No existing page content, endpoint behavior, or URL was changed.

## Item 1 — JSON-LD entries added to landing/index.html

Two new Schema.org JSON-LD blocks were appended after the existing `SoftwareApplication` block (which remains unchanged at line 15):

- **SoftwareSourceCode** (line 29): `name: SAAX Protocol`, `description` (reused verbatim from the existing SoftwareApplication description), `programmingLanguage: JavaScript`, `runtimePlatform: Node.js`, `codeRepository: private repository`, `author: SAAX Protocol`.
- **WebAPI** (line 41): `name: SAAX Protocol MCP API`, `description: MCP-compatible API for agent-to-agent commitment routing and settlement`, `documentation: https://saax-protocol.com/docs`, `provider: SAAX Protocol`, `serviceType: Agent Commerce`, `url: https://www.saax-protocol.com/mcp`.

Verified: 3 JSON-LD blocks total, all parse as valid JSON.

## Item 2 — /llms.txt created

`landing/llms.txt` (1,849 bytes) — served at `https://saax-protocol.com/llms.txt` as `text/plain`. Sections: Core Documentation (spec, protocol, conformance, docs, welcome, terms, security, privacy, disputes), Relationship to External Systems, MCP Integration (endpoint + registry listing `io.github.bryantrudy24/saax-protocol` version 1.0.3), Premium Subscription (Developer $29, Business $199, Enterprise contact).

## Item 3 — /llms-full.txt created

`landing/llms-full.txt` (76,749 bytes) — concatenation under six headings:

- `## Spec` — contents of `spec/README.md` plus all six spec documents (commitment-schema, lifecycle, authority-proof-interface, evidence-interface, settlement-linkage, error-codes), README first, then alphabetical; 7 files total.
- `## Protocol Overview` — `landing/protocol.md`
- `## Integration Guide` — `landing/docs.md`
- `## Security` — `landing/security.md`
- `## Privacy` — `landing/privacy.md`
- `## Terms` — `landing/terms.md`

Served at `https://saax-protocol.com/llms-full.txt` as `text/plain`.

## Item 4 — Relationship statements added to landing/spec.md

Prepend `## Relationship to External Systems` section after the title/intro/Scope matter (line 11):

- Settlement-rail-neutral; Protocol does not require any specific payment rail.
- Consumes authority proofs from AP2 / Verifiable Intent / OAuth / custom issuers; validates, does not issue credentials.
- Consumes identity and reputation signals from ERC-8004; reads for ranking and gating, writes only outcome feedback.
- Settles on Base with USDC as the current Router configuration; Protocol does not require Base or USDC.
- Does not issue credentials, process payments directly, operate an oracle network, or act as an identity provider.

## Item 5 — Vercel rewrites added

`vercel.json` — two rewrites appended (preserving all 18 existing):

```json
{ "source": "/llms.txt", "destination": "/landing/llms.txt" }
{ "source": "/llms-full.txt", "destination": "/landing/llms-full.txt" }
```

Total rewrites now 20. JSON validity confirmed.

## Item 6 — Deploy and verification

Commit `2339ad95` (5 files, +1397) pushed to `main`. `vercel deploy --prod` — Ready in 18s, aliased to saax-protocol.com.

Live URL results (fresh fetches, post-deploy):

| URL | Status | Content-Type | First bytes |
|---|---|---|---|
| https://saax-protocol.com/llms.txt | 200 | text/plain; charset=utf-8 | `# SAAX Protocol\n\n> Vendor-neutral commitment...` |
| https://saax-protocol.com/llms-full.txt | 200 | text/plain; charset=utf-8 | `# SAAX Protocol — Full Content\n\n## Spec\n\n# SAAX Protocol Specification...` |
| https://saax-protocol.com/spec | 200 | text/markdown; charset=utf-8 | Relationship section present (line 11) |
| https://saax-protocol.com/ | 200 | text/html; charset=utf-8 | Existing landing page unchanged |
| https://saax-protocol.com/docs | 200 | text/markdown; charset=utf-8 | Existing docs unchanged |
| https://www.saax-protocol.com/mcp | 200 | application/json | `serverInfo: {name: saax-protocol, version: 1.0.3}` |

No existing URL failed. MCP endpoint unchanged and responding with 1.0.3.

## Divergences

None material. Implementation notes:

- PowerShell console mangles UTF-8 em-dashes for display only; all file writes used Python with explicit utf-8 encoding, and the served content is correct on disk and in HTTP responses.
- fs_write writes to the agent workspace root, not the project directory; mutation was executed via a Python script run from the workspace against the repo path.
- The relationship section was placed after the title/intro/Scope matter rather than at the very first byte — the brief's "prepend this section" satisfied without breaking the document's top matter.
- llms.txt written verbatim per the brief's content spec.
## SAAX Full Expansion - 2026-10-07

Added the full name "Solvent Applied Autonomous Exchange Protocol" across all public surfaces.

### Changes applied
1. **Page title**: SAAX Protocol - Solvent Applied Autonomous Exchange Protocol
2. **og:title**: SAAX Protocol - Solvent Applied Autonomous Exchange Protocol
3. **og:description**: The commitment protocol for autonomous commerce. SAAX = Solvent Applied Autonomous Exchange Protocol.
4. **twitter:title/description**: not present on the page (no-op per brief)
5. **Hero**: added hero-expansion paragraph below the h1, muted style via new .hero-expansion CSS. Headline/subheadline preserved verbatim.
6. **Footer**: added the full-name line above the existing disclaimer.
7. **JSON-LD**: alternateName added to all three blocks - SoftwareApplication, SoftwareSourceCode, WebAPI (3 occurrences confirmed).
8. **llms.txt**: opening block now reads SAAX = Solvent Applied Autonomous Exchange Protocol. (first 200 bytes verified live).
9. **spec.md**: full expansion bold line added under the title.
10. **protocol.md**: same added under the title.
11. **welcome.md**: SAAX = Solvent Applied Autonomous Exchange Protocol bold line added under the title.

### Deploy and verification
- Commit 5014ef84 (5 files, +17/-5) - pushed 4564120e..5014ef84 main -> main
- vercel deploy --prod -> Ready in 30s, aliased https://saax-protocol.com (ax-router-nr1wa1o9u)
- Initial deploy returned Not authorized (stale CLI token) - resolved via vercel pull + retry
- Live verifications (fresh fetches, all 200):
  - / text/html 22807 B: TITLE includes full expansion; OGTITLE includes it; OGDESC exact per brief; HERO hero-expansion present; FOOTER expansion line present; ALTNAME_COUNT 3; pricing anchor + all three buttons unchanged; headline preserved
  - /spec 200 text/markdown - expansion found
  - /protocol 200 text/markdown - expansion found
  - /welcome 200 text/markdown - expansion found
  - /llms.txt 200 text/plain 1904 B - first 200 bytes contain the expansion

### Divergences
- None material. PowerShell console renders em-dashes/arrows as mojibake (display-only; file bytes correct). Verification script initially failed on Subscribe buttons due to matching cta-button class while the page uses btn/btn-secondary - confirmed false positive.

