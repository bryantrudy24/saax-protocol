> This log was written under the previous project name AX Router; the project is now SAAX Protocol.

# Day 12 — MPP Settlement Rail Integration

Date: 2026-10-04
Sprint: MPP integration as the second registered settlement rail in the rail-agnostic commitment lifecycle.
Scope: MPP integration ONLY. No mainnet activation. No demand generation.

## Summary

The Machine Payments Protocol (MPP) is now a fully operational second settlement rail in SAAX Protocol,
implemented against the REAL `mppx` package (wevm/mppx **0.13.1**, installed exact-pinned alongside
the existing viem 2.57.2). The rail-agnostic commitment lifecycle from Day 11 now settles the same
commitment via either x402 or MPP — proven end-to-end at both the unit (rail) and HTTP (gateway) level.

## Item-by-item

### Item 1 — Install and Configure MPP SDK — DONE
- `npm install mppx viem --save-exact` → added `mppx@0.13.1` (viem deduped to existing 2.57.2).
- `npm audit`: **0 vulnerabilities** (32 packages audited).
- MPP server configured in `endpoint/rails/mpp.js` via `mppx/server`:
  - `evm.charge({ currency: USDC Base Sepolia, chainId: 84532, decimals: 6, recipient: seller, authorization: { name: 'USDC', version: '2' }, settle: <custom settler> })`
  - `Mppx.create({ methods: [evmCharge], secretKey })` — secretKey from `MPP_SECRET_KEY` env, else
    deterministic dev derivation (documented in .env.example).
- Wire format: `WWW-Authenticate: Payment` (challenge), `Authorization: Payment` (credential),
  `Payment-Receipt` (receipt) — all base64url JSON per the mpp.dev protocol.

### Item 2 — endpoint/rails/mpp.js — DONE (full interface)
- `realise(R): Credential` — emits an MPP `evm/charge` challenge for the neutral requirement R
  (amount converted raw→display, recipient = R.payee, externalId = commitmentId). Stashes the
  challenge for validate() continuity.
- `validate(Credential, R): boolean` — parses the credential, re-derives the challenge-hash nonce
  (`keccak256([id, realm])`), re-checks recipient == R.payee, amount == R.amt, validAfter/Before
  window, and runs **mppx `validateCredential`** (pure crypto EIP-712 recovery, no RPC). Returns
  false on verification failure, throws on structural malformation.
- `settle(Credential): TransactionReference` — runs mppx `broadcastCredential` → our custom
  settler, which re-validates every claimed value (recipient/amount/window/nonce binding) and
  dispatches to the Day 10 gateway's dual-path settlement (`gateway.settleAuthorization`:
  EIP-3009 transferWithAuthorization when the token supports it, EIP-2612 permit+transferFrom
  otherwise). Returns the rail reference (txHash).
- The mppx evm charge method's own validate() already enforces: recipient mismatch, amount
  mismatch, challenge-hash nonce binding, validity window, EIP-712 signer recovery, source match.
- `emitChallengeHeader` / `parseCredentialHeader` / `buildReceiptHeader` — header (de)serialization.
- `rawToDisplay` / `displayToRaw` — amount unit conversion (raw atomic ↔ display).

### Item 3 — Dual-Challenge Gateway — DONE
- `endpoint/route-server.js`:
  - Registers the MPP rail at boot (graceful degradation to x402-only if mppx fails to load).
  - 402 response now emits BOTH headers when MPP is registered:
    - `PAYMENT-REQUIRED` (x402, unchanged)
    - `WWW-Authenticate: Payment <base64url challenge>` (MPP, via realise(R))
  - Credential detection: `Authorization: Payment` → parsed → routed to `mpp.validate(cred, R)`.
    x402 `PAYMENT-SIGNATURE` and legacy `x-x402-mock` remain fully intact (guarded so MPP
    attempts never shadow them).
  - Settlement: `paymentMode === 'mpp'` → `mpp.settle(cred)` → `Payment-Receipt` header
    `{ method: 'mpp', status: 'success', reference, chainId }`. x402 keeps `PAYMENT-RESPONSE`.
- Proven over HTTP (scripts/test-mpp-endpoint.js, 17/17 PASS): 402 with both headers → MPP retry →
  200 + Payment-Receipt + spend receipt (rail=mpp, railReference set) → repeatable with fresh challenge.

### Item 4 — Commitment Lifecycle Integration — DONE
- The 402 challenge references the commitment (commitmentId, manifestHash) + neutral requirement R
  (amt/cur/payee/eta/scheme/t_exp) — unchanged from Day 11.
- Buyer selects the rail by credential format on retry (x402 PAYMENT-SIGNATURE or MPP Authorization:
  Payment). The gate validates the rail-specific credential against the SAME R, settles via the
  selected rail, and the Spend Receipt binds commitmentId → railReference for either rail.
- Spend Receipt rail field: `'mpp'` (with MPP railReference) or `'x402'` (with txHash). Credential
  never appears in the receipt (assertNoCredentialLeakage PASS for both rails).

### Item 5 — Test Harness — DONE
- `scripts/test-mpp-rail.js` (26/26 PASS, dry-run): issues a commitment + R, simulates an MPP
  client (signs the challenge → Authorization: Payment), confirms validate/settle/railReference,
  confirms the Spend Receipt binds commitment → MPP reference, runs the SAME commitment through
  the x402 rail, and proves both rails produce valid receipts for the same commitment
  (rail-agnosticism) — plus R nonce single-use (replay rejected).
- `scripts/test-mpp-endpoint.js` (17/17 PASS): full HTTP dual-challenge proof over a real server.

### Item 6 — MPP Session Support (stretch) — DEFERRED, integration path documented
- The mppx package natively supports sessions (`tempo.session`, `settle`, `settleBatch` server
  entrypoints) but the tempo method is pathUSD/TIP-20 based — NOT the same asset model as AX
  Router's USDC EIP-3009/EIP-2612 rail. Wiring tempo sessions would introduce a second payment
  method (pathUSD) with its own currency, escrow trust, and settlement semantics.
- Integration path for a follow-up sprint: add `tempo.charge` as a third registered rail with a
  session store (Store.AtomicStore), map R to display-unit amount, reuse the commitment lifecycle
  unchanged. Not implemented now — out of scope per the brief's stretch allowance.

## Files changed
- `package.json` / `package-lock.json` — added `mppx@0.13.1` (exact pin).
- `endpoint/rails/mpp.js` — NEW: full MPP rail (was NOT_IMPLEMENTED stub).
- `endpoint/route-server.js` — MPP registration, dual-challenge emission, MPP credential
  detection, MPP settlement + Payment-Receipt header, spend-receipt rail binding.
- `scripts/test-mpp-rail.js` — NEW: rail-agnosticism harness.
- `scripts/test-mpp-endpoint.js` — NEW: HTTP dual-challenge harness.

## Fixes made (divergences reported)
1. **Latent bug exposed + fixed**: `challenge.accepts.push` crashed in SELF_MODE once MPP was
   registered (the Day 11 commitment-binding block assumed `accepts` existed; SELF_MODE's
   buildChallenge produces no accepts array). Fixed by initializing `challenge.accepts` before push.
   This bug was previously unreachable (MPP stub was never registered).
2. **mppx package.json subpath**: `require('mppx/package.json')` is blocked by mppx's exports map —
   registration now catches and reports version as '?' without crashing.
3. **Amount units**: mppx charge routes take DISPLAY units ("0.05"); R.amt is raw atomic (50000).
   The rail converts raw→display at realise() and back at validate/settle.
4. **x402 rail settle() returns an object** `{ railReference, ... }` while MPP returns a plain
   reference string — the harness normalizes both to the railReference string (registry contract).
   Both rails' interface is unchanged; documented in the harness.

## Regression battery (all green after the sprint)
| Suite | Result |
|---|---|
| Day 9 gateway harness (T1-T10, dry-run, MPP registered) | ALL PASS |
| Day 8 Item 1 (idempotency/nonce) | ALL PASS |
| Day 8 Item 2 (rate limit) | ALL PASS |
| Day 8 Item 3 (kill switch, zero RPC) | ALL PASS |
| Day 8 Item 4 (reputation from signature) | ALL PASS |
| Day 11 gateway (G1-G6 commitment flow) | ALL PASS |
| Day 11 smoke | ALL PASS |
| Day 5 / Day 5-E2E / Day 6 / Day 7-E2E | ALL PASS |
| Security verify-item6 (ERC-8004 feedback) | ALL PASS |
| test-mpp-rail (rail-agnosticism, new) | 26/26 PASS |
| test-mpp-endpoint (dual challenge, new) | 17/17 PASS |

## Divergences from the brief
- Item 6 (sessions) deferred with a documented integration path — the tempo session method is a
  different payment method (pathUSD/TIP-20) than the USDC rail; implementing it inside this
  sprint would break the "MPP integration only" constraint. Per the brief's stretch clause.
- No live on-chain MPP settlement was executed (no real funds; dry-run only) — consistent with
  constraints. The Day 9 gateway's on-chain settlement is unchanged and still testnet-proven;
  MPP's custom settler routes through that same broadcast path when dry-run is off.

## Next steps (post-verification)
- Operator verification of this sprint.
- Follow-up sprint: MPP sessions (tempo) as a third rail, or mainnet activation per operator.