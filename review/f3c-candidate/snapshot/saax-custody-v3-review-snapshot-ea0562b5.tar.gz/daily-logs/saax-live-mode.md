# SAAX Protocol — Live Mode Activation (Day 14/15)

Date: 2026-10-05
Endpoint: https://saax-route-server-production.up.railway.app
Chain: Base mainnet (eip155:8453)
Status: LIVE (self mode, verified)

---

## 1. The Flip to Live Mode

- Environment variable change: `SAAX_X402_MODE`: `mock` → `self` (set via Railway CLI `variable set ... --stdin` — **never `--json`**, standing constraint from the prior rotation leak).
- Railway auto-redeployed on the variable set; a second forced redeploy was not required for the flip itself.
- /health verification after redeploy:

```json
{"ok":true,"mode":"self","verifyMode":"mock","x402Mode":"self","seller":"0xAF94b0d2a936C0683c870aB146979F7ebA46A49f","killSwitch":false,"store":"in-memory","rateLimitStore":"memory","rails":["x402","mpp"],"port":8080}
```

- Confirmed `mode=self` and `x402Mode=self` (not `mock`). The `seller` field in health carries the vault address (legacy display); the actual broadcaster is the signer.

Other variables confirmed correct (set in Railway since the deploy sprint):
- `SAAX_X402_SIGNATURE_PATH=eip3009`
- `SAAX_RPC_URL=https://mainnet.base.org`
- `SAAX_CHAIN_ID=8453`
- `SAAX_X402_ASSET=0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913`
- `SAAX_TRUST_PROXY=true`
- `SAAX_SIGNER_ADDRESS=0x1FF7959FFD1fB97dd423986A470fbD65687be35a`
- `SAAX_VAULT_ADDRESS=0xAF94b0d2a936C0683c870aB146979F7ebA46A49f`

---

## 2. First Live Settlement

Exactly one $0.05 settlement was run from the test buyer to the vault (operator decision: one tx only; buyer funded $0.19).

- **Transaction hash:** `0x3880ac8522155b5a75691c00fa84285a86ff3fddbaedbfc88135b6b9ada07efd`
- **Block number:** 52224381
- **BaseScan URL:** https://basescan.org/tx/0x3880ac8522155b5a75691c00fa84285a86ff3fddbaedbfc88135b6b9ada07efd
- **Status:** success
- **Transfer event:** exactly **50000 microUSDC ($0.05)** — decoded from the on-chain Transfer log (`value: "50000"`, `valueUSD: "0.05"`, logIndex 351)
- **Direction:** test buyer `0xFec898A99e35d2E3a06bCfb54c4A8886DA19cA13` → vault `0xAF94b0d2a936C0683c870aB146979F7ebA46A49f`
- **Broadcaster:** new signer `0x1FF7959FFD1fB97dd423986A470fbD65687be35a` (tx `from` = signer; confirmed on-chain)
- **Signature path:** EIP-3009 (transferWithAuthorization), domain name resolved on-chain as "USD Coin", version 2

The settlement was driven through the PUBLIC endpoint in self mode: challenge (402, amount 50000, payTo=vault) → buyer signs EIP-3009 → POST with PAYMENT-SIGNATURE → HTTP 200, `payment.mode=self verified=true`, PAYMENT-RESPONSE receipt `{"transactionHash":"0x3880ac85...","status":"settled"}`.

---

## 3. Balance Deltas

| Wallet | Before | After | Delta |
|---|---|---|---|
| Test buyer USDC | 0.19 | **0.14** | −0.05 ✅ |
| Vault USDC | 1.10 | **1.15** | +0.05 ✅ |
| Signer ETH (gas) | 0.00036867 | **0.000368147** | −0.00000052 (gas only) ✅ |

All deltas verified on-chain (block 52224405). No other USDC movement.

---

## 4. Day 8 Security Controls — Re-Verified on the Live Endpoint

All four controls re-run against the PUBLIC URL in self mode. Actual results:

1. **Nonce-bound idempotency — PASS.**
   The settled tx's EIP-3009 calldata was decoded on-chain (nonce `0x55b7b0ce...`, value 50000, buyer→vault), the byte-identical PAYMENT-SIGNATURE header was rebuilt (EIP-712 signature is deterministic), and replayed twice against the live endpoint. Both replays returned **HTTP 200 with a byte-identical cached body, NO fresh PAYMENT-RESPONSE header, no new tx hash, no on-chain charge.** This is the exact "same settlement signature twice → cached, no duplicate charge" contract.

2. **Rate limiting — PASS.**
   62 no-payment POSTs fired in rapid succession; the **first 429 arrived at request 59** in 1816ms (within the 60s / 60 req window). 429 + Retry-After enforced.

3. **Kill switch — PASS.**
   `SAAX_KILL_SWITCH=true` set in Railway → redeployed → `/route` returned **HTTP 503** `{"status":"halted","reason":"operator_kill_switch"}` with zero RPC calls (the kill-switch gate runs before body parse / rate limit / idempotency / settlement). Variable then deleted + forced redeploy → `/health` back to `killSwitch=false`, `/route` returning 402 again. Reverted cleanly.

4. **Buyer reputation — PASS.**
   Reputation resolves from the **signature** in self mode: the live settlement's cached response (and the settlement itself) carries `reputation: {"walletAddress":"0xfec898a9...","reputationScore":0,"discountApplied":0,"source":"signature"}` — resolved from signer recovery, **not** from a header. The mock `x-mock-buyer-rep` header is ignored in self mode (no discount applied: fee 0.05, discountPct 0 — the Day 9 harness T9 contract). Re-verified via the replay's cached body.

---

## 5. Divergences

- The brief's named harnesses (`scripts/test-gateway.js` / `test-mpp-endpoint.js`) spawn a LOCAL server; for a public-endpoint live settlement I built a one-shot client (`scripts/_one-shot-live-settlement.js`) that drives the REAL Railway URL in self mode. The harness conventions (EIP-3009 wire shape, on-chain domain resolution, header format) were followed exactly.
- Health's `seller` field displays the vault address (legacy field); the real broadcaster is the signer — verified on-chain (tx from = signer).
- `verifyMode` in health still reports `mock` (that's the legacy x402 verify-mode label; the gateway is in `self` mode and performs real EIP-712 + broadcast). The settlement itself is real (on-chain confirmed).
- Buyer was funded $0.19 (operator decision) rather than the recommended $1.00 — sufficient for the one $0.05 test, not for retries. No retry was needed; the single settlement succeeded.
- Kill-switch revert required an explicit `railway redeploy --yes` after `variable delete` (delete alone did not auto-redeploy).

---

## 6. Standing Notes

- **Vault address:** `0xAF94b0d2a936C0683c870aB146979F7ebA46A49f` — the operator's Ledger (cold). No key ever exists server-side for the vault.
- **Signer (hot):** `0x1FF7959FFD1fB97dd423986A470fbD65687be35a` — holds gas only (~0.000368 ETH ≈ $1.00), broadcasts settlements.
- **Accepted loss:** old signer `0x247499C7FffE583D78BeD64EAA2ccAb917282b6C` (~$1.00) — documented in saax-git-hygiene.md; the leaked key may drain it; accepted.
- **Never use `railway variable list --json`** — leaks sealed values into terminal output (standing constraint; caused the second key rotation).
- For the next live settlement, the same one-shot client can be re-run; operator authorization required (the brief's one-settlement constraint was honored; no second settlement was run).