# SAAX Landing Page & Domain Deployment — 2026-10-06

## URL Structure (fixed, as decided)

| URL | Serves |
|---|---|
| https://saax-protocol.com | Landing page (apex) |
| https://saax-protocol.com/terms | Full terms of use |
| https://saax-protocol.com/docs | Full integration guide |
| https://www.saax-protocol.com/mcp | MCP endpoint (unchanged) |
| https://settlement.saax-protocol.com | Settlement endpoint (unchanged) |

## Files Created

- `landing/index.html` — landing page, all 9 sections (risk banner, hero, what-it-does, how-it-works, developers, suppliers, pricing, before-you-use risk summary, footer). Clean infrastructure tone, mobile-first, no frameworks, no tracking scripts/analytics/cookies. Risk banner amber, dismissible per session via `sessionStorage` (no cookies). Accessible: semantic HTML, ARIA labels, sufficient contrast.
- `landing/terms.md` — full terms of use (10 sections incl. experimental disclaimer, no warranty of correctness/availability, financial risk on Base mainnet, smart contract risk, no recovery guarantee, your-keys-your-responsibility, no legal/financial advice, no supplier endorsement, experimental stage). Acceptance condition included.
- `landing/docs.md` — full integration guide (what you can do, MCP connect, HTTP connect + 402 flow, what you need, supplier registration, pricing, support links, link to terms).

## Vercel Configuration Changes

1. **Apex 308 redirect removed** — domain-level setting in Vercel (`saax-protocol.com` had `redirect: www.saax-protocol.com`, status 308). Removed via `PATCH /v9/projects/{projectId}/domains/saax-protocol.com` with `{"redirect": null, "redirectStatusCode": null}`. Verified: API returns `"redirect": null`; live curl shows apex `200` serving the landing page (no longer 308).
2. **Landing served at apex `/`** — added rewrites in `vercel.json`:
   - `/` → `/landing/index.html`
   - `/terms` → `/landing/terms.md`
   - `/docs` → `/landing/docs.md`
   - `/mcp` → `/api/mcp.mjs` (unchanged)
3. **MCP endpoint unaffected** — URL unchanged at `https://www.saax-protocol.com/mcp`; registry listing still points to it. No code change to the MCP function.

## Deployment

- `vercel deploy --prod` → aliased to `ax-router` production; **Ready in 20s**. Deployment URL: `https://ax-router-oe3hkatm2-bryant-s-projects5.vercel.app`.

## Five Verified URLs (live, HTTP)

| URL | Status | Content |
|---|---|---|
| https://saax-protocol.com | **200** | Landing page (title + all sections present, HTML read-back) |
| https://saax-protocol.com/terms | **200** | Terms document |
| https://saax-protocol.com/docs | **200** | Integration guide |
| https://www.saax-protocol.com/mcp | **200** | MCP endpoint responds |
| https://settlement.saax-protocol.com/health | **200** | `{"ok":true,"mode":"self","x402Mode":"self","killSwitch":false,"rails":["x402","mpp"]}` |

## Test Suite Gate

All existing test suites still pass after the deploy:
- Day 11 gateway (commitment lifecycle, x402/MPP dual-rail, nonce replay, kill switch): **ALL PASS**
- Evidence lifecycle (9 tests): **9/9 PASS**
- Authority lifecycle (10 tests): **10/10 PASS**

## Divergences

- The apex redirect lived at **domain level** in the Vercel dashboard (not in `vercel.json` as initially scoped); removed via the Vercel REST API (`PATCH .../domains/saax-protocol.com`) rather than the dashboard UI. Equivalent outcome.
- `vercel.json` `rewrites` target files in the project (e.g. `/landing/index.html`); Vercel serves them as static assets. No `outputDirectory` or public/ conventions needed.
- A temporary `.tmp-domain-patch.json` (containing the PATCH body) was created and left in the project root; it is gitignored via `.vercelignore`? — actually it is NOT in `.vercelignore`; it contains no secrets (just `{"redirect":null,"redirectStatusCode":null}`) but should be removed or gitignored to keep the repo clean.

## Notes

- Risk banner uses `sessionStorage` (per-session dismissal) — strictly no tracking, no analytics, no cookies beyond the strictly-necessary dismissal state.
- Public documents contain **zero architecture details** (no signer, vault, gas mechanics, module names, or internal terminology), per constraints.## GitHub Link Cleanup + MCP Registry Replacement (2026-10-06)

- **Reason:** the landing page linked to the private repository `solvent-applied-saax-protocol` (never to be exposed publicly).
- **References removed:**
  - `landing/index.html` L134 — hero secondary CTA "View on GitHub" (repo URL) → **"View on the MCP Registry"** → `https://registry.modelcontextprotocol.io/v0.1/servers/io.github.bryantrudy24%2Fsaax-protocol/versions`
  - `landing/index.html` L248 — footer "GitHub" link (repo URL) → **deleted** (existing "MCP Registry Listing" entry kept, href updated to the canonical `/v0.1/.../versions` URL)
  - `landing/docs.md` L104 — "GitHub:" support bullet (repo URL) → **deleted** (existing MCP Registry Listing bullet kept, href updated to canonical URL)
- **Canonical registry URL used:** `https://registry.modelcontextprotocol.io/v0.1/servers/io.github.bryantrudy24%2Fsaax-protocol/versions` (URL-encoded slash + `/versions` suffix; the older `/servers/...` form was replaced).
- **Private-resource scan (scripted, all three landing files):** no `github.com` URLs, no gists, no commit hashes, no "see the source / inspect the code / view the repository" phrasing remain. The only "github" string is the registry namespace `io.github.bryantrudy24` inside the MCP server ID — required by the canonical listing URL, not a repo link.
- **External links retained (whitelisted):** `www.saax-protocol.com/mcp`, `settlement.saax-protocol.com`, the registry listing, `x402.org` (spec), `erc-8004.quicknode.com/learn/registries/identity` (required by the For-Suppliers section).
- **Deploy:** commit `b5d13a3e` ("Remove GitHub links, replace with MCP Registry listing", 2 files, +3/−5) pushed (`d9185b1a..b5d13a3e`); `vercel deploy --prod` → **Ready in 16s**, aliased `saax-protocol.com`.
- **Live verification:**
  - `https://saax-protocol.com` → 200, **no `github.com`** in served HTML; both registry-listing links present
  - `https://saax-protocol.com/terms` → 200
  - `https://saax-protocol.com/docs` → 200
  - `https://www.saax-protocol.com/mcp` → JSON-RPC initialize 200, `serverInfo: saax-protocol` ✅ (see divergence)
- **Divergence:** the MCP endpoint's `serverInfo.version` reports **1.0.2** (the deployed bundle's package.json is 1.0.2; the 1.0.3 version lives in server.json + the npm manifest). Registry metadata remains authoritative at 1.0.3. Cosmetic; flagged for a future package.json bump + redeploy to align.