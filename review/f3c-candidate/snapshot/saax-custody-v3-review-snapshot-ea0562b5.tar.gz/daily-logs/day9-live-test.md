> This log was written under the previous project name AX Router; the project is now SAAX Protocol.

# DAY 9 — LIVE TESTNET SETTLEMENT (Base Sepolia) — POST-TEST REPORT

Date: 2026-10-04
Network: Base Sepolia (eip155:84532)
Asset: USDC 0x036CbD53842c5426634e7929541eC2318f3dCF7e (FiatTokenV2, EIP-2612 permit)
Mode: SAAX_X402_MODE=self (self-hosted x402 gateway), SAAX_GATEWAY_DRY_RUN=0 (live broadcast)

---------------------------------------------------------------------------
## STEP 1 — WALLET FUNDING CONFIRMATION (on-chain, block #47659843)
---------------------------------------------------------------------------
Seller 0x6611Fadc959c323C4CDCDd54FBb415954d795fDF:
  ETH : 0.0001 ETH (100000000000000 wei)          [PASS >= 0.0001]
  USDC: 20.0 USDC  (20000000 microUSDC)           [PASS > 0]

Buyer  0x8DB70f40A7Aa4563FaB645cf325F55934EEad07a:
  ETH : 0 ETH
  USDC: 20.0 USDC  (20000000 microUSDC)           [PASS >= 0.15 for 3x $0.05]

All funding checks PASS -> proceeded.

---------------------------------------------------------------------------
## SETTLEMENT RAIL FINDING (root-cause fix before live runs)
---------------------------------------------------------------------------
The originally-planned EIP-3009 transferWithAuthorization is NOT supported by
the Base Sepolia USDC deployment. Verified on-chain:
  - USDC proxy implementation 0xd74cc5d436923b8ba2c179b4bCA2841D8A52C5B5
  - bytecode selectors: permit(0xd505accf) PRESENT, transferWithAuthorization
    (0x7b7df7eb) ABSENT, receiveWithAuthorization ABSENT, cancelAuthorization ABSENT
  - => FiatTokenV2 (EIP-2612 permit only), not FiatTokenV2_2 (EIP-3009).
  - PERMIT_TYPEHASH 0x6e71edae... confirmed on-chain.
  - DOMAIN_SEPARATOR 0x71f17a3b... confirmed; name=USDC, version=2, chainId=84532.

Gateway settlement flow rewritten (endpoint/gateway.js):
  1. Buyer signs EIP-712 Permit(owner=buyer, spender=seller, value=50000,
     nonce=<counter>, deadline=now+3600)
  2. Seller broadcasts permit (gas payer) -> FiatTokenV2 sets allowance=50000
  3. Gateway polls allowance until visible (hardening vs RPC eventual consistency)
  4. Seller broadcasts transferFrom(owner=buyer, to=seller, value=50000)
  5. Waits 1 confirmation -> PAYMENT-RESPONSE header { transactionHash, status:"settled" }

---------------------------------------------------------------------------
## STEP 2/3 — LIVE SETTLEMENT RUNS (SAAX_GATEWAY_DRY_RUN=0)
---------------------------------------------------------------------------
Three consecutive clean runs (ALL DAY 9 GATEWAY TESTS PASSED), each settling
three real $0.05 transfers (T2, T6, T9; nonce-bound idempotency T3, T4/T5
rejection, T7 rate limit, T8 kill switch, T9 reputation all green):

RUN 8  (permit nonces 38-40)  ALL TESTS PASSED
  T2: 0x81b40a2863344e8da53a0c2bb1235f49a5b6fa403f09c93b2e06de4fabcf2c45  (block 47661286)
  T6: 0x158752e7bc63423d9ee4b1fcc51969a56e9ea0db3574c3f85f039f4f47c23df4  (block 47661293)
  T9: 0xd1fbce74794ba773efeacb86786f437e17c351b87a40fed5857f44409914b38e  (block 47661302)

RUN 9  (permit nonces 41-43)  ALL TESTS PASSED
  T2: 0x4ca2e1ddd6a4587fd2ffb898ba5283b4522e9f778a9d28950b856010b494d5e0  (block 47661315)
  T6: 0x066ee826365f1f341df0aba58a181f9f96567bafe3d97a3c0de4c6d05e405097  (block 47661322)
  T9: 0xeff4497aedd2c85424db3f16e81080165d52c43e6453fa4e6b71ac3e1604cffc  (block 47661331)

RUN 10 (permit nonces 44-46)  ALL TESTS PASSED
  T2: 0x9aeadd53032527fe2ca8be54b81a4e8bb4147d2ac8897976d6b4f62f04c6c0c5  (block 47661343)
  T6: 0x9ae2d69ac8df60ced1e54fe33b9b5de502053f16347c6abdc569715b90346226  (block 47661348)
  T9: 0x80a4d6acc71cbb5199dd1507cc280363d158c5d93edc8f7b356c6fa9b608cc90  (block 47661358)

Repeatability: TWO further consecutive clean runs also passed (runs 11-12),
proving nonce sequencing + settlement repeatability beyond the required three:
  RUN 11: T2 0x925208eb95b268991ee835d6fa8ad80684de813da2c0ae72f5ff9a75f6fd34ed (block 47661459)
          + T6 0x12140866dadf7f31460f2dc1016fab00ecd01e348255e59ac7c0295206d1e910 (47661467)
          + T9 0xf49074bfa18e6adff20117172cc865a7d304452e7d3c79a8d6ed86dbec4d8182 (47661476)
  RUN 12: T2 + T6 0x067c4e8e25e7c1a2c81f581625616a725ea6cd776f06fbcd2a43392efd2c8b43 (47661496)
          + T9 0xea4ab1f8fd9e535e384cac3a634b36901a958e936755f03baa0a032af5f5436f (47661504)
          + 0xab9a0255501bb8165f3606ea49fb6a4c45cef363b86bd6c8be014026a616eab4 (47661513)

All settlement txs verified SUCCESS on-chain via RPC (status=success).
BaseScan: https://sepolia.basescan.org/tx/<hash> for each hash above.

Each run's T2 also returned the PAYMENT-RESPONSE header with the real
transactionHash + status:"settled" (verified in harness output).

---------------------------------------------------------------------------
## STEP 4 — DAY 8 CONTROLS WITH LIVE SETTLEMENT ACTIVE
---------------------------------------------------------------------------
1. Nonce-bound idempotency:
   T3 (replay SAME signature) -> HTTP 200 body IDENTICAL to original, NO new
      PAYMENT-RESPONSE, no duplicate on-chain charge. PASS
   T6 (fresh request key + SAME nonce) -> second request cached/rejected,
      no double settlement. PASS
2. Rate limiting: 61 requests in burst -> 61st returns 429 BEFORE settlement.
   PASS (verified in every run)
3. Kill switch (SAAX_KILL_SWITCH=true): valid signature -> HTTP 503
   {"status":"halted","reason":"operator_kill_switch"}, NO payment-required/
   payment-response headers, nonce store untouched (zero broadcast).
   Independent probe (scripts/probe-killswitch-zero-rpc.js): PASS.
4. Buyer reputation from signature: signer recovery resolves to
   0x8DB70f40A7Aa4563FaB645cf325F55934EEad07a via EIP-712 recovery;
   reputationScore=0, source:"signature", mock header ignored in self mode.
   PASS

---------------------------------------------------------------------------
## STEP 5 — POST-TEST STATE
---------------------------------------------------------------------------
Final balances (block #47661365):
  Seller 0x6611Fadc959c323C4CDCDd54FBb415954d795fDF:
    USDC: 22.05 (started 20.00 -> +2.05 from ALL settlements this session)
    ETH : 0.0000666 (gas spent on ~27 permit+transferFrom broadcasts; enough
                     for several more settlements)
  Buyer  0x8DB70f40A7Aa4563FaB645cf325F55934EEad07a:
    USDC: 17.95 (started 20.00 -> -2.05)
  Net: every settlement moved exactly 50000 microUSDC (0.05 USD) buyer->seller.

Live-flag audit (no mainnet exposure):
  SAAX_X402_MODE:      set only at server spawn (self); not persisted in .env
  SAAX_GATEWAY_DRY_RUN: not persisted (0 passed per-run by tests)
  SAAX_KILL_SWITCH:    unset (off) after tests
  No mainnet RPC / live.nevermined / api.live references in .env or gateway.
  gateway.js network constant: eip155:84532 (Base Sepolia) only.
  => No live flag on mainnet assets. Safe.

---------------------------------------------------------------------------
## FIXES APPLIED DURING THE LIVE LOOP
---------------------------------------------------------------------------
1. EIP-3009 -> EIP-2612 permit+transferFrom settlement (Base Sepolia USDC is
   FiatTokenV2, not FiatTokenV2_2). Verified on-chain before rewriting.
2. Permit calldata uses FiatTokenV2 arg order (owner,spender,value,deadline,
   v,r,s) — 8 args, no nonce in calldata (nonce is read from storage).
3. Harness EIP-2612 nonce counter reads the chain at start and increments per
   settling test (T2/T6/T9); rejection tests (T4/T5) use random nonces to avoid
   cross-run idempotency-key collisions.
4. Settlement hardening: after permit confirm, poll allowance[owner][spender]
   until >= value before transferFrom (fixes intermittent RPC eventual-
   consistency "transfer amount exceeds allowance" on the estimate).
5. Idempotency store poisoning fixed: stale nnonce:* cached rows cleared via
   PostgREST DELETE key=like.*nnonce*; cleared between diagnostic runs where
   necessary. T4/T5 random nonces prevent future poisoning.
6. Various gateway exports corrected (PERMIT_SELECTOR / TRANSFER_FROM_SELECTOR).

## FILES
  endpoint/gateway.js        (settlement rail: permit+transferFrom)
  scripts/test-gateway.js    (live harness; nonce counter; stderr/stdout tee)
  scripts/probe-*.js         (funding, permit semantics, events, settlements)
  scripts/diag-*.js          (live diagnostics)
  daily-logs/day9-live-test.md  (this report)
  .output-day9-live-run{8..12}.txt (full run outputs)