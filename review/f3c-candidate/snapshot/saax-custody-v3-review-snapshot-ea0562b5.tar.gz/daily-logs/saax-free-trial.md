# SAAX Free Trial Tier — Log

## Trial Tier Creation (2026-10-07)

### Trial Price
- **Price ID:** price_1UPAwUAWggRLQc7ccy6lUONc
- Product: SAAX Premium (prod_VOcHfktDJhugs3)
- Amount: $0.00 USD, monthly recurring
- Nickname: 14-Day Free Trial
- Active: true (live)

### Radar Free Trial Abuse Control
- Status: Dashboard-only — operator action required (Radar → Risk controls → Free trial abuse control → enable)
- No public API exists for Radar; cannot be enabled programmatically.
- Checkout Session path (used by /checkout) makes Radar trial-start detection work automatically.

### Gating Logic — trialing status
- lookup_subscription RPC: status check updated from `status = 'active'` to `status IN ('active','trialing)`
- Applied via Supabase migration (SECURITY DEFINER)
- Webhook writes whatever status Stripe sends (no hardcoded active) — trialing records as trialing
- subscriptions table has NO status CHECK constraint — trialing never blocked

### Landing Page
- 14-Day Free Trial tier card added to pricing section
- CTA: Start Free Trial → /checkout?plan=trial (Checkout Session, not Payment Link — Payment Links cannot carry trial_period_days)

### /welcome
- Trial access sentence added

## Checkout Function Fix (2026-10-10)

### Error received
{"error":"checkout_failed","message":"Received unknown parameter: subscription_data[payment_settings]"}

### Cause
api/checkout.mjs was passing payment_settings (with save_default_payment_method: on_subscription) inside subscription_data. Stripe Checkout Session API does not accept payment_settings in subscription_data — it exists only on the Subscription resource.

### Fix applied
- Removed the payment_settings block from subscription_data in api/checkout.mjs
- payment_method_collection: 'always' was already at the top level (card required at trial signup)
- Kept trial_period_days: 14 inside subscription_data (trial plan)
- Kept trial_settings.end_behavior.missing_payment_method: 'cancel' (valid Checkout Session param — prevents zombie subs)
- No other parameters removed; no Stripe API version adjustment required (stripe SDK 23.0.0 supports the retained params)

### Commit & Deploy
- Commit 6256f976: "Fix checkout function: remove invalid subscription_data[payment_settings] parameter"
- 1 file changed, 1 deletion(exactly the payment_settings line)
- Pushed: 4c579e94..6256f976 main
- vercel deploy --prod: Ready in 21s, aliased saax-protocol.com

### Verification
- GET /checkout?plan=trial → **HTTP 303** with Location: https://checkout.stripe.com/c/pay/cs_live_a1IFtjnrTYf06AJCGjt5NZT9ltlCVBA6ygjgQ8PZAF5CpfkuBATDW9x11 (correct — the subscription_data[payment_settings] error is gone)
- Checkout page loads (live session recognized by Stripe app)

### End-to-end trial test — pending operator action
The following require completing a real card checkout (operator action — cannot be done by the agent):
1. Complete the checkout with a real card
2. Confirm redirect lands at https://saax-protocol.com/welcome
3. Confirm checkout.session.completed webhook fired with 200
4. Query Supabase subscriptions → row with status trialing
5. Call get_evidence_verification with trial email → premium response (not payment_required)

### Divergences
- fs tools resolve to the sandbox — real file edit done via Python (proven quoting-safe route)
- The prior sprint reported daily-logs/saax-free-trial.md as written, but the file did not exist on disk— created in full here
- Browser attach failed this run — checkout page rendering verified via HTTP fetch (JS-rendered app; session recognized), not visual
