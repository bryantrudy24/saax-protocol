> This log was written under the previous project name AX Router; the project is now SAAX Protocol.

# SAAX Protocol — Day 10 Custody Setup (Mainnet Seller Wallet)

Status: DOCUMENTED ONLY — Safe is not deployed. Deployment waits for operator hardware wallet procurement (per sprint decision).
Scope: Base mainnet seller wallet custody. Testnet path is unchanged (single viem key).

Current addresses (testnet):
- Seller wallet (single-key testnet, active): 0xAd57875a7fdf2cA6F6b3B43D5226790c4A4468fb
- Archived testnet seller (pre-rotation, TESTNET-ONLY): 0x6611Fadc959c323C4CDCDd54FBb415954d795fDF
- Test buyer wallet: 0x8DB70f40A7Aa4563FaB645cf325F55934EEad07a

---

## 1. Safe Multi-Sig Creation (3-of-5 on Base mainnet)

### Step 1 — Open the Safe web app
1. Go to **app.safe.global** in a browser.
2. Click **Connect Wallet** and connect a wallet that holds Base mainnet ETH for the one-time deployment gas (the deployer wallet — this can be the fee-payer wallet once created; it only pays the Safe creation fee).
3. Select **Base** as the network (Base mainnet, chainId 8453; NOT Base Sepolia).
   - Verify the network badge shows "Base" and the chain selector confirms chainId 8453 before continuing.

### Step 2 — Create the Safe
1. Click **Create new Safe** (from the dashboard).
2. Name the Safe (recommended: `SAAX Protocol Seller — Mainnet`).
3. **Signer addresses: 5 required.** Each signer's address is derived from its own hardware wallet seed (see Section 2). The operator provisions these during hardware wallet setup; record each address below as they are generated.
   - Signer 1 (admin): `<SIGNER_1_ADDRESS — from hardware wallet #1>`
   - Signer 2: `<SIGNER_2_ADDRESS — from hardware wallet #2>`
   - Signer 3: `<SIGNER_3_ADDRESS — from hardware wallet #3>`
   - Signer 4: `<SIGNER_4_ADDRESS — from hardware wallet #4>`
   - Signer 5: `<SIGNER_5_ADDRESS — from hardware wallet #5>`
4. **Threshold: 3 of 5.** Set the required confirmation threshold to 3. Any 3 of the 5 signers can execute a transaction; the other 2 are redundancy/escrow against loss.
5. Review the summary, confirm the network is Base (8453), and submit the creation transaction. Pay the creation gas from the connected deployer wallet.

### Step 3 — Record the Safe
- **Safe address (Base mainnet):** `<SAFE_ADDRESS — written here after creation>`
- Chain: Base (eip155:8453)
- Threshold: 3
- Signers: the 5 addresses above

### Step 4 — Fund the Safe with USDC (seller becomes the Safe)
1. After creation, the **seller wallet is the Safe address** — it is what receives settlement USDC.
2. Fund the Safe with USDC (Base mainnet USDC, 0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913) from Circle faucet or exchange withdrawal, in test-sized amounts first.
3. Update environment: `SAAX_SELLER_ADDRESS=<SAFE_ADDRESS>` (the Safe address, NOT a key — the gateway signs nothing for it; see Section 4).

---

## 2. Hardware Wallet Procurement (per OOT framework)

Order and initialize **Trezor** (Model T or Safe 3) or **Ledger** (Nano X / Stax) as follows:

### Procurement
1. **Order directly from the manufacturer** — trezor.io or shop.ledger.com. Never Amazon, never third-party resellers (tamper risk / supply-chain compromise).
2. Verify the package seals on arrival: hologram, box integrity, no signs of opening.
3. Acquire **one device per signer role** (minimum: 3 devices for a 3-of-5 to be executable; 5 if each of the 5 signers has its own). Each device holds one signer key.

### Initialization (offline)
1. **Never connect the device to an internet-connected computer during setup.** Initialize on an air-gapped machine or, for Trezor, using the device's own on-device display flow with the desktop app in offline mode.
2. Generate a fresh seed — never use a pre-printed or pre-generated seed.
3. **Write the seed phrase on paper** using the manufacturer's backup card. Store the paper in a fire-safe / safe-deposit box. No photos, no digital copies, no typing it into any computer.
4. **Set a strong PIN** (6+ digits, not sequential, not a date).
5. **Optionally enable a BIP-39 passphrase for the admin signer** (signer 1): the passphrase creates a hidden wallet — the seed alone is insufficient to access funds. Store the passphrase separately from the seed (different fire-safe or memorized).
6. Derive the signer address from each device (Ethereum app, first account) and record it in Section 1 Step 3. Do not share the device's seed or passphrase with anyone, including the SAAX Protocol software.

---

## 3. Fee-Payer Wallet (separate from seller)

### Purpose
Gas-only wallet. Pays Ethereum transaction fees for gateway operations. Holds only enough ETH for settlement gas. It is NOT a Safe signer and NOT the seller wallet.

### Creation
1. Generate a fresh hot wallet (viem privateKeyToAccount — the same method used for the testnet seller key):
   - `node scripts/gen-seller-wallet.js` (or equivalent) → new private key.
2. Store it in `.env` as `SAAX_FEE_PAYER_PRIVATE_KEY` (new variable — see Section 5 rollback table).
3. Derive and record the address: **Fee-payer address: `<FEE_PAYER_ADDRESS — filled after generation>`**
4. Fund it with a small amount of Base mainnet ETH (enough for ~10-20 settlement transactions; each settlement permit+transferFrom pair is a few hundred thousand gas — fractions of a cent at current Base prices).

### Separation rules (enforced)
- The fee-payer key is NOT one of the 5 Safe signers.
- The fee-payer key is NOT the seller key.
- The fee-payer holds ETH only — it never holds USDC and never receives routing fees.
- On testnet today: the seller wallet itself pays gas (current behavior). The fee-payer split is a mainnet-activation requirement.

---

## 4. Gateway Integration for Safe Custody

### What changes
When the seller wallet is a Safe, the gateway CANNOT sign and broadcast a single transferFrom. The seller Safe holds the USDC; a Safe transaction must be proposed, signed by 3-of-5 signers, and submitted by any executor. The gateway's settlement path changes from:
- **Single-key (current/testnet):** buyer signs transferWithAuthorization or permit; gateway (seller key) signs + broadcasts `permit` → `transferFrom` (EIP-2612) or `transferWithAuthorization` (EIP-3009); seller account receives USDC directly.
- **Safe (mainnet):** buyer signature is still verified by the gateway, but the actual USDC movement is a **Safe transaction from the Safe address**, executed only after 3-of-5 confirmation.

### Exact flow: build proposal → collect signatures → submit → confirm
1. **Build proposal** — the gateway (or operator tooling) constructs a Safe transaction with:
   - `to` = USDC contract (Base mainnet 0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913)
   - `value` = 0
   - `data` = transferFrom calldata (Safe has allowance) OR permit + transferFrom, moving the verified routing fee `amount` from the buyer to the Safe... (or, for the legacy transfer path, the buyer's signed authorization is presented)
   - The proposal is stored (Safe Transaction Service API or local file) with `nonce` = next Safe nonce.
2. **Collect signatures** — the proposal is passed to the signers' hardware wallets (Safe web app / Safe CLI). Each of 3 (or more) of the 5 signers reviews and signs it on their own device. Signatures are collected and attached.
3. **Submit** — any executor (the fee-payer wallet, gas-only) submits the signed transaction on Base mainnet. Gas is paid by the fee-payer, NOT the Safe and NOT the seller key.
4. **Confirm** — wait for 1 confirmation (same policy as testnet). Verify the on-chain state change (USDC balance delta on the Safe) on BaseScan.

### Gateway code impact (mainnet build, not yet implemented)
- `endpoint/gateway.js` `settleAuthorization()` — add a `safeMode` branch that returns the built Safe transaction + signature-collection state instead of broadcasting from the seller key directly.
- New module (future): Safe transaction builder + signature collector (Safe Core SDK, `@safe-global/safe-core-sdk`), invoked when `SAAX_CUSTODY=safe`.
- `SAAX_X402_MODE=self` + `SAAX_CUSTODY=safe` → verify buyer signature as today, then emit Safe proposal; do NOT broadcast from `SAAX_SELLER_PRIVATE_KEY`.
- Settlement receipt becomes: proposal created → `{ status: "proposed", safeTxHash, requiredSignatures: 3 }` → updates to `{ status: "settled", transactionHash }` after execution.

---

## 5. Rollback Procedure (revert to single-key testnet wallet)

If the Safe setup fails or is not ready at mainnet activation, revert to the current single-key testnet custody model. No code change is required — only environment variables.

### Environment variable changes
| Variable | Safe mode (mainnet) | Single-key (rollback / testnet) |
|---|---|---|
| `SAAX_CUSTODY` | `safe` (future) | unset / `key` |
| `SAAX_SELLER_PRIVATE_KEY` | unset (Safe has no key) | the single testnet/seller key |
| `SAAX_SELLER_ADDRESS` | `<SAFE_ADDRESS>` | seller wallet address |
| `SAAX_FEE_PAYER_PRIVATE_KEY` | set (gas) | unset (seller key pays gas) |
| `SAAX_X402_MODE` | `self` | `self` (unchanged) |
| `SAAX_X402_SIGNATURE_PATH` | `auto` | `auto` (unchanged) |

### Code paths affected
- `endpoint/gateway.js` — `settleAuthorization()`: single-key path is the current default; Safe branch is additive and gated on `SAAX_CUSTODY=safe`. Rolling back = unset `SAAX_CUSTODY`, restore `SAAX_SELLER_PRIVATE_KEY` + `SAAX_SELLER_ADDRESS`.
- `endpoint/route-server.js` — no settlement-path change for rollback; it reads the gateway's settlement result.
- `.env` — restore the previous seller key/address (the archived key 0x6611F... is available in `daily-logs/archived-keys/` if the current rotated key must be reverted — TESTNET-ONLY, do not use on mainnet).

### Decision rule
- If Safe deployment is incomplete at mainnet go-live, activate mainnet on the single key ONLY for a bounded, small-value test window (three $0.01 transactions per Section 4 of the readiness checklist), then pause until the Safe is live. Do not run sustained mainnet volume on a single key.