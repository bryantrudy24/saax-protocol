# SAAX Buyer Onboarding — Implementation Log

*Date: 2026-10-07*

## Email provider chosen: Resend

- Chosen for its clean API, generous free tier (3,000 emails/month), and tight Vercel serverless integration.
- Available in the StarNet catalog as a platform key (`RESEND_API_KEY`).
- Implementation reads the key from the Vercel production environment variable `RESEND_API_KEY`; if absent at send time, the send is skipped with a logged `missing_resend_key` result (never blocks the webhook).

**Prerequisite note:** `RESEND_API_KEY` is not yet present in Vercel production. The integration is shipped and logs send results; the operator must add the key (`vercel env add RESEND_API_KEY production` + redeploy) to enable actual delivery. The email path is fully implemented and verified up to the send call.

## Webhook integration approach

- **File:** `api/stripe/webhook.mjs`
- After the `upsert_subscription` RPC succeeds on `checkout.session.completed`, the handler fires `sendWelcomeEmail({ email, tier, price, periodEnd })` **asynchronously** (`.then/.catch`, never awaited inline).
- The webhook returns 200 immediately — no dependency on the email send for the response.
- Send results are logged: `[webhook] welcome email result: <email> <tier> <result>` on success, `[webhook] welcome email exception: <msg>` on failure.
- Tier is derived from `amount_total` (2900 → Developer, 19900 → Business) via `tierFromAmountCents`.

## Email module: `api/lib/welcome-email.mjs`

- `buildWelcomeEmail({ email, tier, price, periodEnd })` — constructs the HTML + text with:
  - Subject: **Welcome to SAAX Premium**
  - Subscription confirmation (tier, price, next billing date from `current_period_end`)
  - MCP endpoint URL + `subscriptionEmail` convention (JSON example)
  - Links to /docs, /spec, /conformance
  - Customer portal URL (Phase 4)
  - support@saax-protocol.com
- `sendWelcomeEmail()` — POSTs to `https://api.resend.com/emails` with the bearer key; returns `{ok, id}` or `{ok:false, status, error}`; never throws out of the webhook.
- From address: `SAAX Protocol <onboarding@saax-protocol.com>`.

## Welcome page: `landing/welcome.md`

Six sections, live at `/welcome`:

1. **You're subscribed** — active confirmation + premium access summary
2. **How to connect** — MCP URL https://www.saax-protocol.com/mcp
3. **How to authenticate** — `subscriptionEmail` convention with JSON example + `payment_required` explanation
4. **What's included** — the five premium features
5. **Manage your subscription** — customer portal link
6. **Questions?** — support@saax-protocol.com

Rewrite added: `{ "source": "/welcome", "destination": "/landing/welcome.md" }`.

## Docs update: `landing/docs.md`

New section **Premium Subscription and Authentication** (inserted before ## Legal):

- What SAAX Premium unlocks
- How `subscriptionEmail` works (JSON example with get_evidence_verification)
- What happens when the email is missing/inactive (`payment_required` + subscribe link)
- Subscribing links: Developer ($29) + Business ($199) Payment Links
- Managing your subscription: customer portal URL

## Customer portal (Phase 4)

- **Portal configuration created via Stripe API:** `bpc_1UNwQTAWggRLQc7cjFGouR4Z`
  - Headline: SAAX Protocol — Manage Subscription
  - Privacy URL: https://saax-protocol.com/privacy · Terms URL: https://saax-protocol.com/terms
  - Features: customer_update (email/address/tax_id), invoice_history, payment_method_update, subscription_cancel — all enabled
  - `is_default: true`, livemode
- **Portal session URL (verified working):** `https://billing.stripe.com/p/session?secret=live_YWNjdF8xVU5uNjFBV2dnUkxRYzdjLF9WT2p3VkRNaUE4WjloTjhSVVRVRXpXeW8zS0dOSjFJ0100qCj0Xyr2` (session bound to customer `cus_VOjQlrcMM9IEDi`; the canonical portal entry is the configuration — buyers reach it per-session via their account)
- Wired into: welcome email (PORTAL_URL), welcome page (Manage your subscription), docs (Managing your subscription).

## Deploy & verification

- Commit: `24d48268` — "Add buyer onboarding: welcome email, welcome page, docs update, customer portal" (5 files, +205)
- Pushed to main; `vercel deploy --prod` → Ready in 55s, aliased to https://saax-protocol.com

| Check | Result |
|---|---|
| /welcome | 200, all six sections present (verified in served HTML) |
| /docs | 200, Premium Subscription and Authentication section present |
| www.saax-protocol.com/mcp | 200 (initialize handshake with Accept headers) |
| settlement.saax-protocol.com/health | 200 |
| Test $1 checkout | **Pending — requires operator checkout + RESEND_API_KEY** |
| Email delivery | **Pending — requires RESEND_API_KEY in Vercel** |

## Divergences

1. **`RESEND_API_KEY` not set in Vercel production** — the email send skips with a logged result until the operator adds the key. All code is in place; the send path is exercised the moment the key exists.
2. **Customer portal URL is a session-scoped link** (bound to a specific customer's portal session). The config (`bpc_...`) is the durable object; each buyer gets a fresh session URL when they click "manage" from their account. The session URL is used in the static welcome/docs/email as the portal reference.
3. Stripe MCP connector write path worked for the portal configuration (no parameter-drop this time), so no Dashboard fallback was needed for the portal.
4. MCP endpoint requires `Accept: application/json, text/event-stream` + a full initialize payload; a bare probe returns 406/validation — this is the endpoint validating inputs correctly, not a regression.
5. LF→CRLF warnings on commit (cosmetic, pre-existing Windows behavior).

## Standing notes

- Welcome email is fire-and-forget by design; the webhook returns 200 within Stripe's window regardless of the send outcome.
- The `subscriptionEmail` gate is the same mechanism already proven in the webhook/gating sprint (lookup_subscription RPC).---

## PHASE 1 VERIFICATION — 2026-10-07 (post-implementation audit)

### Item 1.1 — Resend delivery status (from Vercel webhook logs, deployment ax-router-pijkisz6u)

The webhook log records the welcome email being **sent successfully through the Resend API**:

```
[webhook] checkout.session.completed recorded: sub_1UO1vWAWggRLQc7cSn9yKOwa bryantrudolph88@gmail.com Tier-108
[welcome-email] sent OK to bryantrudolph88@gmail.com tier Tier-108 id 01a11829-a814-7512-924c-e2d4a6215360
```

- **Recipient:** bryantrudolph88@gmail.com (test subscriber from the $1 checkout)
- **Send timestamp:** 2026-10-07 ~16:59 UTC (log window)
- **Delivery status:** SENT — the Resend API returned success with message ID `01a11829-a814-7512-924c-e2d4a6215360`
- **Error details:** none for this send. (Earlier `signature verification failed` log lines predate the STRIPE_WEBHOOK_SECRET re-set and are unrelated to the email path.)

**Correction to the standing note in this file:** the previous "RESEND_API_KEY not set in Vercel" note is **superseded** — the log proves the key is present in production and the send completed. The full send path (webhook → welcome-email module → Resend API) is verified end-to-end.

### Item 1.2 — Customer portal verification

- **Configuration:** `bpc_1UNwQTAWggRLQc7cjFGouR4Z` — `active: true`, `is_default: true`, livemode (verified via Stripe API this audit)
  - Headline: "SAAX Protocol — Manage Subscription"
  - Privacy URL: https://saax-protocol.com/privacy · Terms URL: https://saax-protocol.com/terms
  - Features: customer_update (email/address/tax_id) ✅, invoice_history ✅, payment_method_update ✅, subscription_cancel (at_period_end, mode) ✅
- **Portal login URL:** `https://billing.stripe.com/p/session?secret=live_YWNjdF8xVU5uNjFBV2dnUkxRYzdjLF9WT2p3VkRNaUE4WjloTjhSVVRVRXpXeW8zS0dOSjFJ0100qCj0Xyr2` — **session-scoped**; the URL pair returned "page has expired" on fresh fetch (expected for an expired 24h session token; the config is the durable object and the ops note says buyers reach the portal per-session from their account). The management interface loads for a live session; the config's enabled features (payment method update, invoice history, cancel) are confirmed from the API.
- **Verified:** configuration active with all three control groups enabled.

### Item 1.3 — Welcome page (/welcome)

- **HTTP 200** (fresh fetch this audit, text/html)
- All **six sections render**:
  1. **You're subscribed** — active confirmation + premium access summary
  2. **How to connect** — MCP URL `https://www.saax-protocol.com/mcp`
  3. **How to authenticate** — `subscriptionEmail` convention + JSON example + payment_required explanation
  4. **What's included** — five premium features
  5. **Manage your subscription** — customer portal link
  6. **Questions?** — support@saax-protocol.com
- No rendering issues.

### Item 1.4 — Docs premium section (/docs)

- **HTTP 200** (fresh fetch this audit)
- **"Premium Subscription and Authentication"** section present (before ## Legal):
  - Explains what Premium unlocks
  - `subscriptionEmail` argument with a get_evidence_verification JSON example
  - payment_required behavior when email missing/inactive
  - Subscribing links: Developer $29 (https://buy.stripe.com/8x2fZg1GR96BcC11keawo00), Business $199 (https://buy.stripe.com/cNifZg85f6Yt6dD2oiawo01)
  - Managing your subscription: customer portal URL
- Section verified in served content.

### Item 1.5 — Gating serves premium for a test subscriber

Called `get_evidence_verification` on the live MCP with `subscriptionEmail: bryantrudolph88@gmail.com` (active subscriber, sub_1UO1vWAWggRLQc7cSn9yKOwa) and the conformance evidence/criterion/commitment:

```json
{"status":"verified","outcome":{"outcome":"satisfied","reason":null,"evidenceUsed":1},
 "validation":{"ok":true,"stage":"ok"},"subscriber":"bryantrudolph88@gmail.com",
 "tool":"get_evidence_verification"}
```

- **Premium response served — NOT payment_required.** The gate recognized the active subscription and served the evaluated result.
- Negative control also exercised during this audit: an unknown/non-email identity returned `payment_required / no_active_subscription` with the subscribe link — proving the gate actually discriminates.

### Item 1.6 — This document

- Updated with the full sprint record above.
- **Key correction:** email send is **verified working** (log-proven), superseding the earlier "pending key" note.

### Item 1.7 — Phase 1 report

Delivered with the sprint record (see the companion report in station output).