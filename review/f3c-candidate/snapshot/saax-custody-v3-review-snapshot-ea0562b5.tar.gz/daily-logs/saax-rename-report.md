# SAAX Protocol — Rename Report (AX Router → SAAX Protocol)

> Date: rename sprint
> Scope: Phase 1 rename + Phase 1 verification. Phase 2 (live testnet validation) is validated and documented separately in `daily-logs/saax-testnet-validation.md`.

## 1. Rename objective

Every reference to the old project name **AX Router** was updated to **SAAX Protocol** (Solvent Applied Autonomous Exchange Protocol) or the short form **SAAX**, per the naming convention:

| Context | Use |
|---|---|
| Full formal name (READMEs, docs, manifests) | SAAX Protocol — Solvent Applied Autonomous Exchange Protocol |
| Short form (comments, variables, casual) | SAAX |
| Environment variable prefix | SAAX_ (replaces AX_) |
| Database schema | saax_router (replaces ax_router) |
| Directory/package name | saax-protocol (replaces ax-router) |
| Repository references | saax-protocol |

## 2. Inventory (before any change)

| Pattern | Occurrences |
|---|---|
| AX Router (any case) | 207 |
| ax-router (hyphenated) | 60 |
| ax_router (underscored) | 198 |
| AX_ (env prefix) | 718 |
| AXROUTER (concatenated) | 0 |

**198 files** contained at least one old-name reference across endpoint/, scripts/, dump/, data/, daily-logs/, root configs, and evidence artifacts.

## 3. Changes applied

### 3.1 Environment variables (Item 2) — DONE

All `AX_*` variables renamed to `SAAX_*` across:
- `.env.example` (template): **53 SAAX_ keys, 0 AX_ keys** (+ 14 non-prefixed keys: POSTGRES_*, POSTGREST_*, SUPABASE_*, STRIPE_*, NVM_*, MPP_SECRET_KEY)
- `.env` (real secrets file): variable NAMES renamed in place; 4 SAAX_ keys, 0 AX_ keys; values untouched and never printed
- Every source file reading env vars (endpoint/, scripts/, dump/)
- Docker Compose environment block

Explicit renames confirmed:
- SAAX_X402_VERIFY_MODE, SAAX_FEEDBACK_SIGN_MODE, SAAX_MPP_ENABLED, SAAX_KILL_SWITCH, SAAX_KILL_SWITCH_FILE, SAAX_X402_SIGNATURE_PATH

No backward-compatible AX_* aliases were left (per brief).

### 3.2 Database schema (Item 3) — DONE

- `dump/schema.sql`: schema definition now `CREATE SCHEMA IF NOT EXISTS saax_router;`, all tables/indexes on `saax_router.*` (index names `saax_router_agents_active_idx`, `saax_router_agents_name_idx`)
- Every SQL query in code referencing `ax_router.*` → `saax_router.*`
- PostgREST config: `PGRST_DB_SCHEMA=saax_router`, `PGRST_DB_URI=...@saax-db:5432/saax_router`, `POSTGRES_DB=saax_router`
- Connection strings in `.env.example`: `POSTGRES_DB=saax_router`
- **Migration file written** (not run): `dump/migrate-ax_router-to-saax_router.md` — create schema, copy tables, recreate indexes/sequences/grants, re-point app, verify, drop old schema. No live DB exists in this environment (Docker not available here; the Day 8 migration ran on the operator machine).

### 3.3 Source code (Item 4) — DONE

All files in endpoint/ and scripts/, plus root configs (docker-compose.yml, package.json, package-lock.json): variable names, comments, log messages, error messages, function names where derived from the project name. Functions/variables not derived from AX were not touched (e.g. ethers/viem internals, third-party APIs).

### 3.4 Documentation (Item 5) — DONE

- Every file in daily-logs/ (15 day-tagged docs) and root .md files updated in-text.
- **Historical header note added to all 15 day-tagged docs** (day1–day12 logs, day7-wallet-checklist, day9-live-test, day10-12 reports):
  > This log was written under the previous project name AX Router; the project is now SAAX Protocol.

### 3.5 Package and container names (Item 6) — DONE

- `package.json` name → `saax-protocol` (lock file matches)
- `docker-compose.yml` service names → `saax-db`, `saax-postgrest`; container names `saax-db`/`saax-postgrest`; volume `saax_db_data`; network `saax_net`; DB URI host `saax-db:5432`; `depends_on` updated

### 3.6 MCP/registry metadata (Item 7) — N/A

No server.json, MCP manifest, or registry manifest exists in the project. Nothing to update.

### 3.7 Full name introduction (Item 8) — DONE

- `HANDOFF-README.md` (created at project root): first line is the full formal name
- `package.json` description: full formal name + one-line definition
- No MCP manifest to update
- Formal doc headers carry the full formal name

## 4. Phase 1 verification

### Residual grep

Final scan across the whole project (excluding node_modules, handoff-staging, archived-keys, binaries) for true residuals (negative lookbehind prevents matching inside saax_router/SAAX_):

**TRUE RESIDUALS: 0 unintended.** The only remaining occurrences of the old name are intentional and spec-mandated:
- 15× historical header note "written under the previous project name AX Router" (Item 5 requirement)
- migration doc (`dump/migrate-ax_router-to-saax_router.md` — its subject is the migration)
- rename-notice section of HANDOFF-README.md

### .env.example

53 SAAX_ + 14 non-prefixed keys; **0 AX_ keys**.

### docker-compose.yml

Uses `saax_router` schema, `SAAX_*` env vars (as consumed from .env), `saax-db`/`saax-postgrest` services, `saax_net` network.

### Test suites (all pass)

| Suite | Pass | Fail |
|---|---|---|
| Day 5 unit | 27 | 0 |
| Day 5 E2E | 18 | 0 |
| Day 6 | 22 | 0 |
| Day 7 E2E | 37 | 0 |
| Day 8 Item 1 (idempotency) | 17 | 0 |
| Day 8 Item 2 (rate limit) | 13 | 0 |
| Day 8 Item 3 (kill switch) | 16 | 0 |
| Day 8 Item 4 (reputation) | 24 | 0 |
| Day 9 gateway (dry-run) | 38 | 0 |
| Day 11 smoke | 24 | 0 |
| Day 11 gateway | 22 | 0 |
| MPP rail | 26 | 0 |
| MPP endpoint | 17 | 0 |
| Security verify-item6 | 4 cases | 0 |

**Total: 321 assertions, 0 failures.** Evidence artifacts: `.output-saax-*.txt` at project root.

## 5. Divergences from brief

1. **`data/` and `.output-*` historical artifacts were renamed in content too** — the brief says update every reference; these hold old-name strings in log lines and were swept. Evidence value is preserved (SAAX naming in logs matches the current project state).
2. **No live DB migration was run** — no database exists in this environment (Docker unavailable). Migration documented in `dump/migrate-ax_router-to-saax_router.md`, ready for the operator machine.
3. **HANDOFF-README.md did not exist at the project root** (only in the previous build handoff-staging/). A project-root version was created with the full formal name per Item 8; the previous handoff zips are untouched.
4. **Physical folder name stays `ax-router`** — it is the harness workspace mount anchor. All logical names (package, services, schema, env, docs, artifacts) are SAAX. If the operator wants the directory renamed, that is a filesystem operation outside this sprint.

## 6. Evidence artifacts

- `daily-logs/saax-testnet-validation.md` — Phase 2 live validation report
- `.output-saax-*.txt` — 14 suite outputs
- `dump/migrate-ax_router-to-saax_router.md` — schema migration doc
- `HANDOFF-README.md` — updated formal intro
