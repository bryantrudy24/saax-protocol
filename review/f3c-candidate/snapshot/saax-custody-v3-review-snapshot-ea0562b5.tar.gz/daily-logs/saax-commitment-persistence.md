# SAAX Commitment Persistence — Production Migration

Date: 2026-10-09

## Summary

The commitment lifecycle is now operationally live: commitments are persisted to
Supabase on issuance, the MCP commitment tools read from Supabase (the
in-process Map reduced to a cache-only fallback), and `/route` is deployed as a
Vercel function serving the 402 challenge from saax-protocol.com.

## Part 1 — Commitments table + RPCs (Supabase, ax_router schema)

Migration `create_commitments_table_and_rpcs` applied to project
`codboejrwohkjidrrcgl`.

Table `ax_router.commitments`:

| column | type | notes |
|---|---|---|
| commitment_id | text PK | unique commitment identifier |
| state | text NOT NULL DEFAULT 'issued' | lifecycle state |
| capability | text | the capability |
| buyer_email | text | subscription email that created it (NULL for /route demand today) |
| terms | jsonb | price/deliverable/deadline/acceptance criteria |
| authority_ref | text NULL | authority proof reference |
| evidence_refs | jsonb DEFAULT '[]' | evidence references |
| settlement_ref | text NULL | settlement reference |
| manifest_hash | text | sha256 of the manifest |
| created_at / updated_at | timestamptz DEFAULT now() | |

Indexes: `commitments_buyer_email_idx` (buyer_email), `commitments_state_idx` (state).

RPCs (all SECURITY DEFINER, EXECUTE granted to anon + authenticated):

- `ax_router.upsert_commitment(p_commitment_id text, p_state text, p_capability text, p_buyer_email text, p_terms jsonb, p_authority_ref text, p_evidence_refs jsonb, p_settlement_ref text, p_manifest_hash text) RETURNS ax_router.commitments`
  — ON CONFLICT (commitment_id) DO UPDATE (re-issuance updates the row).
- `ax_router.lookup_commitment_by_id(p_commitment_id text) RETURNS SETOF ax_router.commitments`
- `ax_router.lookup_commitments_by_email(p_email text) RETURNS SETOF ax_router.commitments` (newest first)

Verified: test insert → both lookups return it → re-insert same id updates (no duplicate).

## Part 2 — Store migration

- `endpoint/commitment-store.js` (new, CJS): schema-scoped PostgREST client
  (Accept-Profile/Content-Profile: ax_router) calling `upsert_commitment`. Uses
  SUPABASE_URL + SUPABASE_ANON_KEY. Env URL is trimmed (Vercel env had trailing
  whitespace — fixed).
- `endpoint/gateway.js` `issueFromPayload`: after the manifest + requirement R
  are built (logic UNCHANGED), fires `commitmentStore.persistCommitment(...)` —
  additive, non-blocking, tracked in `_commitmentPersistPending`. Exports
  `awaitCommitmentPersistence()`.
- `endpoint/route-server.js`: after issuance, `await gateway.awaitCommitmentPersistence()`
  before responding — durable on serverless (a fire-and-forget write was killed
  by function teardown; now the write completes before the 402 is returned).
- `api/mcp.mjs`: `get_commitment`, `list_commitments`, `get_commitment_status`
  now read from Supabase via `lookupCommitmentById` / `lookupCommitmentsByEmail`
  (schema-scoped client `supabaseAxRouter` in `api/lib/supabase.mjs`, added with
  `commitmentRowToRecord` mapper). The in-process `commitmentStore` Map is kept
  as a cache-only read-through (used when the DB is unreachable; Supabase is the
  source of truth).

## Part 3 — /route as a Vercel function

- `api/route.mjs` (new): adapts Vercel req/res to `handleRoute` from
  route-server.js; POST /route only; OPTIONS handled; errors → 500 JSON.
- `endpoint/route-server.js`: the HTTP listener is wrapped in `startServer()`,
  started only when `require.main === module` OR `process.env.VERCEL !== "1"`
  (local tests keep the legacy start-on-import; Vercel functions don't open a
  socket).
- Ranking data: `data/*.json` are excluded from Vercel deploys (`.vercelignore`),
  so loadLocal now falls back through (1) data/, (2) endpoint/ mirrors,
  (3) `endpoint/mcp-supplier-index.json` (proven to ship) for AGENTS only.
  Reputation/leaderboard default to `[]` when absent (buildRanker tolerates
  score 0). 
- `vercel.json`: added `{ "source": "/route", "destination": "/api/route.mjs" }`
  (23 rewrites total).

Deployment issues found & fixed (each verified from Vercel function logs):
1. ENOENT `/var/task/data/agents-day1-named.json` — data/ not deployed → fallback chain.
2. `leaderboard is not iterable` — reputation/leaderboard fell through to the
   supplier index object → per-file candidate lists, `[]` default.
3. `Failed to parse URL ... supabase.co /rest/v1/...` — trailing whitespace in
   the Vercel SUPABASE_URL env → env/base trim in commitment-store.js.

## Part 4 — End-to-end verification (live, all functions on saax-protocol.com)

1. POST /route → 402 with commitmentId `0xa5a3b22eac6c2412abf108a881b25303e8e1171d5cf11a8365f6abcb35ed69c8`
   (X-Vercel-Id served from Vercel, not local).
2. get_commitment (live MCP) → `{"status":"found", manifest:{commitmentId: 0xa5a3b22e..., manifestHash: sha256:86689d36..., capability: "security scan", price: {...}, ...}}` — the SAME commitment minted by /route is readable by the MCP function. Cross-function sharing via Supabase proven.
3. get_commitment_status → `{"commitmentId":"0xa5a3...","state":"issued"}` — only state returned.
4. list_commitments (unknown email) → `payment_required` / `no_active_subscription` — gating intact.
5. Supabase direct query → row exists (state issued, created 18:28:20 UTC).
6. Cold start: prior rows persisted earlier still present (0xb2fed5e1..., 0xf6625adb...).

## Divergences / notes

- `buyer_email` is NULL for /route-issued commitments (the HTTP endpoint carries
  no email today). `list_commitments` therefore returns [] for real subscribers
  until a flow binds authz email to the demand. Documented, not blocking: the
  store, the tools, and the gating all operate correctly; the email binding is a
  future flow decision.
- MPP rail `require('mppx/server')` fails on Vercel Node (ESM-in-CJS) — caught,
  x402-only mode on Vercel (matches response `accepts:[x402]`). Local Railway-style
  runs keep dual-rail. Documented, cosmetic for this sprint (MPP still works locally).
- Pre-existing uncommitted working-tree change: `scripts/test-mcp-tools.mjs` (10-tool
  version) was already modified before this sprint; left untracked-changes-only.
- The endpoint/ JSON mirrors (agents-day1-named.json etc.) are now tracked for the
  fallback; they duplicate data/ content (~99KB) so Vercel functions can rank.
- No existing URLs changed; /mcp, /health, landing, pricing, Stripe, gating all
  regression-tested green (see below).

## Regression gate (all pass)

- Day 11 smoke: ALL PASSED · Day 11 gateway: ALL PASSED · MCP tools: 24/24
- Day 8 items 1-4: ALL PASSED (16/14/18/20)
- MPP rail 26/26 · MPP endpoint 17/17 · evidence 9/9 · authority 10/10
- Day 9 gateway (dry-run): ALL PASSED · verify-item6: PASS