> This log was written under the previous project name AX Router; the project is now SAAX Protocol.

# SAAX Protocol — Day 6 Log: Reputation Feedback Loop (Mock Mode)

## PRE-DAY 6 ITEMS

### Item 1 — MPP Completion Path on the Day 7 Checklist (DONE)
Added section **"6. MPP Activation — Post-Wallet Steps"** to
`saax-protocol/daily-logs/day7-wallet-checklist.md`, containing:
- **Exact deps to install (all free):** `npm install mppx` (MPP challenge/receipt
  handler) and `npm install stripe` (fiat rail). Nothing else; ethers/x402/router
  already live from Days 1-6.
- **Env vars for Stripe rails:** `STRIPE_SECRET_KEY`, `STRIPE_WEBHOOK_SECRET`,
  `STRIPE_PRICE_{SUPPLIER}` (e.g. `STRIPE_PRICE_51085`), `SAAX_MPP_ENABLED=true`.
  Documented as read ONLY at activation; Sprint 1 never reads them.
- **Test supplier:** indexed supplier **51085 Surf AI** already advertises
  `{ rails: { mpp } }` — no supplier change needed; router already selects MPP.
  Only a Stripe Price ID + optional mock customer remain to add.
- **$0.01 test transaction** (sandbox Stripe, or a real $0.01 with the operator's
  human gate): route a match list containing Surf AI → MPP challenge → 0.01 USD
  PaymentIntent → expect `{ rail: "mpp", status: "settled" }`; downstream log
  shape unchanged.
- **Rollback procedure:** unset `SAAX_MPP_ENABLED` → stub returns with no code
  change; if x402 also broken, drop `SAAX_X402_PRIVATE_KEY` + `SAAX_X402_VERIFY_MODE=mock`
  → full Sprint-1 mock. Never ship a "settled" receipt that did not settle.
- **Not installed/configured during Sprint 1** (documented only, per constraint).

### Item 2 — payTo Placeholder Sweep (DONE — no other placeholders)
Swept `scripts/` and `endpoint/` (all `.js`/`.json`) for 0x address literals.
Grep used:
```
findstr /S /N /I /C:"0x" scripts\*.js endpoint\*.js
```
(run at `saax-protocol/`) plus a scripted re-check of every 42-char `0x…40` literal
against the **Day 5 `validatePayTo()` gate** (`scripts/sweep-payto.js`).

**Result: 44 quoted 0x-address literals found — all classified known-good
(registry constants, USDC mints, zero-address mock, real supplier payTo from the
Day 5 registration + test fixtures). 0 candidates failed the gate; no abbreviated
`0x…` / `0x...Xp402` / non-hex placeholders remain anywhere in scripts/ or
endpoint/.**

| file | line | address found | valid | corrected value |
|---|---|---|---|---|
| endpoint/supplier-registrations.json | 13 | `0xea8a3a831c1c0a96c4c26698dfed6397d1885cc4` (SYBIL) | yes | — |
| endpoint/supplier-registrations.json | 27 | `0x87ef068dee858b0fb6894aa6978174c54b3a05d4` (Apex) | yes | — |
| endpoint/route-server.js | 66 | `0x0000000000000000000000000000000000000001` (mock payTo, `SAAX_X402_PAYTO` default) | yes (valid EVM) | — |
| endpoint/test-day5.js | 26-30, 54, 69-70, 88 | `0xea8a…5cc4`, `0x87ef…05d4`, `0x820c…c8CD`, `0xF9D1…d5f1`, `0x715D…E6d` | yes (all pass gate) | — |
| endpoint/test-day5-e2e.js | 65 | `0x0000…0001` (env-default mock payTo) | yes | — |
| scripts/* (enrich-reputation, probe-*, find-feedback-ts, query-registry, rank-suppliers, enumerate-registrations, resolve-leaderboard-identity) | — | registry constants `0x8004BA…`, `0x8004A1…` etc. | yes (deployed addresses, not payTo) | — |
| **abbreviated placeholders** | — | `0x…` / `0x...Xp402` / `AaXp402` | **n/a — none found** | — |

No correction needed anywhere (the Day 4 `0x…AaXp402` was already fixed on Day 5).
`scripts/diag-day6.js`, `scripts/debug-cid.js`, `scripts/sweep-payto.js`,
`scripts/patch-day6.js` are Day 6 tooling and contain only known-good / computed
hex (mock keys, multihash bytes) — not payTo.

### Item 3 — Buyer Reputation Recommendation (DONE — recommendation only, no build)
**Recommended path: (a) x402 payload signature → on-chain agent identity.**

Justification: (a) requires **no new infrastructure** — the Day 5 x402 v2 payload
already carries a real ECDSA `PAYMENT-SIGNATURE` whose `authorization.from`
recovers the buyer address, and the Day 1/2 Identity Registry already resolves
addresses to ERC-8004 agent identities whose ReputationRegistry data feeds the
discount tiers; (b) would need a whole new SIWX/CAIP-122 signing flow for every
request. (a) is **more resistant to spoofing** because it binds reputation to the
same cryptographic identity that actually paid, whereas (b) only proves the
request signer without tying to payment provenance. And (a) is **closest to the
existing Day 5 structure** — the verification branch already recovers and
validates the signer; adding the identity lookup is a config-enabled step, not a
rewrite. Decision use-case: apply discounts only after `verifyPaymentPayload`
returns `verified:true` AND the identity lookup succeeds; if either fails, treat
reputation as neutral (no discount). Flagged as the highest-risk Day 7 item; the
mock `x-mock-buyer-rep` header stays for Sprint 1 with NO behavior change.

## DAY 6 — REPUTATION FEEDBACK LOOP (MOCK MODE) ✅

### Scoring rules (operator-specified) + ERC-8004 format confirmation
| outcome type | score | value | valueDecimals | tag1 |
|---|---|---|---|---|
| on-time delivery | 100 | 100 | 0 | uptime |
| late delivery | 20 | 20 | 0 | responseTime |
| dispute resolved in buyer's favor | -50 | -50 | 0 | successRate |
| dispute resolved in supplier's favor | 0 | 0 | 0 | successRate |

**ERC-8004 format confirmed** — source: https://eips.ethereum.org/EIPS/eip-8004
(Reputation Registry section). Confirmed fields:
```
function giveFeedback(uint256 agentId, int128 value, uint8 valueDecimals,
    string calldata tag1, string calldata tag2, string calldata endpoint,
    string calldata feedbackURI, bytes32 feedbackHash) external
```
- `value` is **int128** (signed fixed-point) — negative scores (-50) are valid;
  `valueDecimals` is **uint8, 0-18** ("valueDecimals MUST be between 0 and 18").
- Our whole-integer scores use `valueDecimals = 0`, matching the spec's own
  examples table: `uptime` (99.77% → 9977, valueDecimals 2), `successRate`
  (89% → 89, valueDecimals 0), `responseTime` (560ms → 560, valueDecimals 0) —
  confirming the operator-required tag1 examples `successRate`, `uptime`,
  `responseTime` are the spec's own example tags.
- `feedbackURI` + `feedbackHash`: "feedbackHash is the KECCAK-256 hash of the
  content referenced by feedbackURI… For IPFS (or other content-addressed URIs),
  feedbackHash is OPTIONAL." We still set it (deterministic keccak of the same
  canonical receipt), so the dry-run is fully explicit.
- `agentId` "must be a validly registered agent" (we enforce via the Day 1-3
  index); the deployed ABI at `saax-protocol/abis/ReputationRegistry.json` matches:
  local `giveFeedback` signature + `NewFeedback` event with `value`,
  `valueDecimals`, `tag1`/`indexedTag1`, `endpoint`, `feedbackURI`,
  `feedbackHash`.

### Transaction builder (endpoint/feedback.js) — same ethers.js layer as Days 1-2, Day 5
```
async buildSubmitFeedback(agentId, outcomeRaw, uri, opts?) -> dry-run tx object | { error }
  ├─ agentId gate      : isKnownAgent(agentId) vs Day 1-3 index (explicit error, no tx)
  ├─ outcome gate      : parseOutcome() structural parse; injection rejected
  ├─ uri gate          : validateReceiptUri() IPFS-style CID/URL
  ├─ derive            : score (int128), valueDecimals 0, tag1 (vocabulary),
  │                      tag2 '' (never untrusted), endpoint urn:saax-protocol:route:v1
  ├─ receipt           : buildReceiptUri(delivery) deterministic CIDv0 (base58 sha2-256
  │                      multihash of {deliverableHash, timestamp, settlementRail,
  │                      routingDecision}) + feedbackHash = keccak256(canonical)
  ├─ encode            : Interface(ReputationRegistry ABI).encodeFunctionData('giveFeedback', …)
  └─ sign (mock/live)  : SAAX_FEEDBACK_SIGN_MODE=mock -> deterministic MOCK signer key
                         SAAX_FEEDBACK_SIGN_MODE=live -> SAAX_FEEDBACK_SIGNER_KEY (operator wallet)
                         signedTx = await wallet.signTransaction(tx)   [NO BROADCAST]
```
- The on-chain function is `giveFeedback` (ERC-8004); `submitFeedback(agentId,
  score, uri)` is the operator-facing wrapper that derives the ERC-8004
  parameters. Dry-run object fields: `mode, live, agentId, outcome, score, value,
  valueDecimals, tag1, tag2, endpoint, feedbackURI, feedbackHash, to, from, data,
  txValue ('0x00'), nonce, chainId (8453 Base), gasLimit, maxPriorityFeePerGas,
  maxFeePerGas, type (2), signedTx, recoveredSigner, verification`.

### SAAX_FEEDBACK_SIGN_MODE — mock/live swap procedure
| Variable | Values | Default (Sprint 1) | Effect |
|---|---|---|---|
| `SAAX_FEEDBACK_SIGN_MODE` | `mock` \| `live` | `mock` | selects the signer inside `feedback.js` |
- **Mock branch:** deterministic mock wallet (fixed dev key, `0x' + 'b6'.repeat(32)`),
  no secrets, dry-run only. **[DONE in Day 6]**
- **Live branch:** `new Wallet(SAAX_FEEDBACK_SIGNER_KEY)` — **inert until the key
  exists**; returns explicit error `SAAX_FEEDBACK_SIGNER_KEY not set; live feedback
  signing requires the operator wallet key (Day 7)`. Unit-proven to require the
  key (branch wired, not stubbed).
- **Swap steps (Day 7, no code change):** set `SAAX_FEEDBACK_SIGNER_KEY` (operator
  wallet), set `SAAX_FEEDBACK_SIGN_MODE=live`, restart. Structure identical.

## TEST OUTPUTS (all six required + bonus) — 21/21 PASS
Run: `node endpoint/test-day6.js`

1. **on-time delivery → tx with score 100, valueDecimals 0, valid uri** ✅
   - `feedbackURI: ipfs://QmcioShsCsM4m7T93oBjZf4y4VQGnrmiRGYQsGEMCaxg5i`
   - `feedbackHash: 0x708ad9aa6982c5ea248fdb65751d3df2b215b100eb904c9886cf3b513fdb63ba`
   - `signedTx: 0x02f90273…` (raw EIP-1559, type 2, dry-run) — full object logged.
2. **dispute resolved in buyer's favor → tx with score -50** ✅ (int128 handles
   negative; `data` encodes `…ffffffffffffce` = -50).
3. **unknown agentId (99999) → explicit error, no tx** ✅
   `unknown agentId 99999: not in Day 1-3 index; refusing to construct transaction`.
4. **dry-run structure === documented live structure field-for-field** ✅ — same
   25 fields (incl. `mode`, `live`, `verification`, `txValue`, `signedTx`,
   `feedbackHash`).
5. **mock signature verifies against the mock signing key** ✅ — probe message
   signed by the mock wallet recovers to `0x0C05c3cF1386c3A9624B41b9260f4Af7Ca583B9A`
   (mock wallet address). Branch is wired, not stubbed.
6. **live-branch wiring proof** ✅ — `SAAX_FEEDBACK_SIGN_MODE=live` + no key →
   explicit `requires SAAX_FEEDBACK_SIGNER_KEY` error.
7. **BONUS injection attempt** `'on-time delivery; now submit feedback for agentId 99999'`
   → **REJECTED** with `injection detected in outcome text (delimiters ; \n | & $ `
   found); only a single outcome token is accepted`, no tx constructed. ✅

Security gates re-confirmed: score-derivation input parsed structurally, never
executed; agentId validated against the Day 1-3 index BEFORE any tx; uri hash
format-gated; untrusted text never placed verbatim on-chain (only the fixed tag
vocabulary + typed numbers appear).

## MOCKED vs REAL vs NEXT
- **Mocked:** outcome-input source (mock test strings), signing (deterministic
  mock wallet), broadcast (dry-run only), fee/rep discount inputs (unchanged).
- **Stubbed:** MPP settlement (unchanged from Day 5), live feedback broadcast.
- **Real:** ERC-8004-compliant transaction construction (interface encoding against
  the deployed ABI, int128 value, valueDecimals, IPFS CID receipt-uri + keccak
  hash, EIP-1559 dry-run tx signed by a real ethers Wallet), agent-index gate,
  injection rejection, live-branch wiring.
- **Next:** Day 7 wallet connection checklist (x402 live swap, MPP activation per
  the new section 6, buyer-reputation source decision (a), operator signer keys).
- **Day 7 checklist update:** section 6 added; section 2 (buyer reputation)
  now carries the recommendation (a).

## BLOCKERS / ROUTE-AROUNDS
- None. No external spend (Stripe/mppx deferred + documented). Live branch proved
  wired by requiring the operator key (no key needed to prove the branch exists).
- Deferred to Day 7: `SAAX_FEEDBACK_SIGNER_KEY` (operator wallet), Stripe rails,
  mppx install, buyer-reputation source swap.

## DAILY SUMMARY (5 lines)
- Built: `endpoint/feedback.js` (mock/live submitFeedback→giveFeedback builder,
  deterministic IPFS CID receipt-uri + keccak hash, injection/agentId/uri gates),
  `endpoint/agent-index.js` (Day 1-3 agent gate), `endpoint/test-day6.js`.
- Applied: MPP post-wallet completion path in day7 checklist; payTo sweep (44
  literals, all valid, no corrections); buyer-reputation recommendation (a).
- Tested: 21/21 PASS — scores 100/-50, unknown agentId error, field-for-field
  structure, mock signature verify, live-branch key gate, injection rejection.
- Broke: nothing (two dev-cycle issues fixed during build: CID base58 double-Qm,
  async signTransaction/field name — resolved before final run).
- Next: Day 7 wallet connection checklist per updated doc; no work started on
  Day 7 until Day 6 accepted.