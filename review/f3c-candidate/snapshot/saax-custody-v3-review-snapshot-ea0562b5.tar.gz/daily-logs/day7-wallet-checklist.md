> This log was written under the previous project name AX Router; the project is now SAAX Protocol.

# SAAX Protocol — Day 7 Wallet Connection Checklist

> Scope: this checklist exists so the x402/MPP wiring stays a **config change,
> not a rewrite**, and so buyer reputation, MPP completion, ABI divergences and
> live broadcast are explicit at wallet connection time. It is the operator's
> handoff document. **Sprint 1 does NOT broadcast, does NOT flip any mode flag,
> and does NOT touch the wallet** — everything below is documentation until the
> operator explicitly authorizes live mode.
>
> Section map (Deliverable B, Day 7): 1 Env vars · 2 Swap procedure · 3 Test
> transaction sequence · 4 Block explorer verification · 5 Rollback · 6 Known
> divergences from briefing (permanent) · 7 Live broadcast activation · 8 MPP
> activation post-wallet · 9 Buyer reputation decision · 10 Security gate
> confirmation · 11 Data integrity confirmation · 12 Open items.

---

## 1. Environment Variables — exact names, format, current mock values

| Variable | Sprint 1 value (current) | Live value (post-wallet) | Purpose |
|---|---|---|---|
| `SAAX_ROUTER_WALLET_ADDRESS` | unset (mock payTo used: `0x0000…0001`) | operator wallet address (0x + 40 hex) | the router's fee address / submitting identity |
| `SAAX_ROUTER_PRIVATE_KEY` | unset | operator private key **OR** Coinbase Agentic Wallet MCP path (if MCP used, no key env var — the MCP signs; skip key vars) | signs router transactions |
| `X402_NETWORK` | `base` | `base` (Base mainnet) | settle network |
| `X402_ASSET` | `USDC` | USDC contract address on Base: `0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913` | settle asset |
| `SAAX_X402_VERIFY_MODE` | `mock` | `live` | payment verification branch (see §2) |
| `SAAX_FEEDBACK_SIGN_MODE` | `mock` | `live` | feedback signer + broadcast enable (see §2) |
| `SAAX_FEEDBACK_SIGNER_KEY` | unset | operator wallet key (0x + 64 hex) or MCP signing path | signs the giveFeedback tx |
| `SAAX_MPP_ENABLED` | unset (= stub) | `true` (after §8) | flips MPP stub to real Stripe flow |
| `SAAX_X402_PAYTO` | `0x0000000000000000000000000000000000000001` (valid-EVM mock) | operator fee address | payTo in challenges/settlements |
| `SAAX_RPC_URL` | `https://base-rpc.publicnode.com` | same (or preferred Base RPC) | read + broadcast RPC |
| `SAAX_ETH_USD` | unset (constant 2703.68; overridable) | current spot price at activation | gas cost reporting only |
| `SAAX_REPUTATION_REGISTRY` | `0x8004BAa17C55a88189AE136b182e5fdA19dE9b63` | unchanged | ReputationRegistry address |
| `SAAX_SUPPLIER_REGISTRATIONS` | unset (defaults to `endpoint/supplier-registrations.json`) | unchanged | rail registration source |
| `SAAX_KILL_SWITCH` | unset (= `false`, normal operation) | `true` = halt ALL live payment processing instantly (503 `{halted}`), **before any RPC** | Day 8 Item 3 — emergency brake |
| `SAAX_KILL_SWITCH_FILE` | unset (no file = switch off) | path to a flag file; **file exists = switch ON** (touch to halt, rm to resume, no restart) | Day 8 Item 3 — runtime toggle |
| `SAAX_RATE_LIMIT_IP` | `60` (default) | raise if legitimate traffic exceeds; **never exempt** | Day 8 Item 2 — per-IP /min |
| `SAAX_RATE_LIMIT_WALLET` | `30` (default) | raise if legitimate traffic exceeds; **never exempt** | Day 8 Item 2 — per-wallet /min |
| `SAAX_RATE_LIMIT_IP_WINDOW` / `SAAX_RATE_LIMIT_WALLET_WINDOW` | `60` (seconds) | window for the sliding bucket | Day 8 Item 2 |
| `SUPABASE_URL` (alias `SAAX_SUPABASE_URL`) | unset (in-memory store fallback) | set to `https://<ref>.supabase.co` for Supabase-backed idempotency + rate-limit stores | Day 8 Items 1-2 |
| `SUPABASE_SERVICE_ROLE_KEY` (alias `SAAX_SUPABASE_KEY`) | unset | service key that drives the `saax_router` tables + `acquire_idempotency` RPC | Day 8 Items 1-2 |

Day 8 defaults: idempotency **TTL = 24h**, hourly cleanup job; rate-limit
limits are configured via the `SAAX_RATE_LIMIT_*` vars above.
| Stripe rails (only after §8): `STRIPE_SECRET_KEY`, `STRIPE_WEBHOOK_SECRET`, `STRIPE_PRICE_51085` | unset | test-mode Stripe keys + Surf AI Price | MPP fiat rail |

Format rule: Ethereum addresses are `0x` + 40 hex; private keys are `0x` + 64
hex; keys are NEVER committed to the repo or printed to logs.

---

## 2. Swap Procedure — exact config flags, in order, with expected effect

Order matters (verify each step before flipping the next):

| # | Flag | Flip to | Expected effect (verified by) |
|---|---|---|---|
| 1 | `SAAX_ROUTER_WALLET_ADDRESS` / `SAAX_ROUTER_PRIVATE_KEY` (or MCP) | set | wallet exists; `eth_getBalance` succeeds |
| 2 | `SAAX_X402_VERIFY_MODE=live` | set | PAYMENT-SIGNATURE now requires a REAL ECDSA signature; mock payloads are REJECTED (run `node endpoint/test-day5.js` — live-branch isolate test must now ACCEPT a genuine signature, not fail) |
| 3 | `SAAX_FEEDBACK_SIGN_MODE=live` + `SAAX_FEEDBACK_SIGNER_KEY` | set | `buildSubmitFeedback` signs with the OPERATOR wallet; `broadcastSignedTx` becomes live-capable (mock mode threw) |
| 4 | `SAAX_X402_PAYTO` | set | challenges/accepts carry the operator fee address |
| 5 | `SAAX_MPP_ENABLED=true` (ONLY after §8 install + Stripe keys) | set | MPP branch stops stubbing and calls the real helper |
| 6 | `SAAX_ETH_USD` | set to spot | gas cost reporting is current |

After each flip: restart the endpoint server, run the corresponding test
(`test-day5-e2e.js` for #1-2, `test-day6.js` for #3, MPP test in §8 for #5).
Any flip that fails → halt, run §5 rollback, log, do not proceed.

---

## 3. Test Transaction Sequence — first three live transactions

Run in this exact order, smallest risk first. All three are $0.01 USDC on Base.

1. **$0.01 USDC payment to self** — prove the wallet connection and signing
   path. Transfer $0.01 USDC from the operator wallet to the operator wallet
   (or to a second address the operator controls). Success = on-chain tx,
   status Success, confirms the key/MCP path and RPC work end-to-end.
2. **$0.01 USDC routing fee to own wallet** — verify x402 settlement. Issue a
   real `PAYMENT-SIGNATURE` challenge for the $0.01 fee and settle it to the
   operator's `SAAX_X402_PAYTO`; the x402 live verification branch must ACCEPT
   the genuinely-signed payload and the settlement receipt must be the
   documented shape with a REAL txHash (not `mock_…`).
3. **$0.01 USDC feedback broadcast** — verify the reputation write. Build the
   `giveFeedback` tx via `buildSubmitFeedback` (score, ERC-8004 fields),
   broadcast with `broadcastSignedTx`, confirm on BaseScan (§4) and via
   `readFeedback` if available.

Each passes only when the block explorer shows the tx landed (§4) — never trust
a client-side "settled".

### 3.x Day 8 live control tests (verify the Day 8 security controls in live mode)

Run after tests 1-3 pass, same strictness (block-explorer-verified):

4. **Duplicate idempotency-key replay** — issue the same paid `/route`
   request twice with the same `Idempotency-Key`. Expect: 2nd returns the
   CACHED response with the SAME settlement txHash — **no double charge**.
   (Verifies Item 1 end-to-end with the real store.)
5. **Rate-limit boundary hit** — fire 31 paid requests from one wallet within
   60s (or 61 from one IP). Expect the 31st (61st) → **429** with
   `Retry-After` and `limitType: wallet` (`ip`); confirm NO verification ran
   on the limited request (no settlement artifact). (Verifies Item 2.)
6. **Kill-switch toggle** — with the server RUNNING, touch the
   `SAAX_KILL_SWITCH_FILE` path (or set `SAAX_KILL_SWITCH=true`), fire a valid
   live `/route` request → expect **503** `{"status":"halted",
   "reason":"operator_kill_switch"}` with NO on-chain activity; remove the
   file → the same request resumes normal processing **without restart**.
   (Verifies Item 3 runtime toggle.)
7. **Buyer reputation from signature** — send a live signed payload from a
   wallet with a real registered agent + feedback (avgX100 ≥ 95). Expect the
   discount tier to derive from the ON-CHAIN score (`source: signature`),
   NOT from any `x-mock-buyer-rep` header (send a fake header too — it must
   be ignored). (Verifies Item 4.)

---

## 4. Block Explorer Verification — exact URL patterns

BaseScan mainnet:
- **Any tx:** `https://basescan.org/tx/0x<txhash>` — verify Status **Success**.
- **USDC payments (tests 1-2):** also view the From/To balances; USDC transfers
  on Base settle natively.
- **Feedback write (test 3):** `https://basescan.org/address/0x8004BAa17C55a88189AE136b182e5fdA19dE9b63`
  shows the inbound `giveFeedback` calls; open the tx to confirm To =
  ReputationRegistry, value 0 ETH (gas-only write), From = operator wallet.
- Confirmations: see §7.4 (default 1; optionally wait 2 on the first live test).

---

## 5. Rollback Procedure — single flag flip per mode variable

| Mode | Flags to flip back | Effect |
|---|---|---|
| Feedback/mock signing | `SAAX_FEEDBACK_SIGN_MODE=mock` ; unset `SAAX_FEEDBACK_SIGNER_KEY` | dry-run mock wallet, broadcast inert |
| Payment/mock verify | `SAAX_X402_VERIFY_MODE=mock` ; unset `SAAX_X402_PRIVATE_KEY` | mock signatures accepted again; live branch inert |
| MPP | unset `SAAX_MPP_ENABLED` | MPP branch returns to `{ rail:"mpp", status:"stubbed" }` |
| Full Sprint-1 mock | all of the above | identical to the Day 5-7 test environment |
| **Kill switch (Day 8) — emergency halt, SEPARATE from mode-flip** | set `SAAX_KILL_SWITCH=true` OR `touch SAAX_KILL_SWITCH_FILE` | ALL live payment verification halts **instantly at the first gate** — 503 `{halted}` on every live request, ZERO RPC calls, no mode change. Mock testing lane unaffected. `rm` the flag file (or set `false`) to resume **without restart**. This is the emergency brake: use it FIRST for any exploit/key-compromise/on-chain anomaly, THEN do the slower mode-flip rollbacks above. Verify with one live-mode request → 503 `{status:"halted","reason":"operator_kill_switch"}`. |

Verify every rollback with `node endpoint/test-day5-e2e.js` and
`node endpoint/test-day6.js` — both must pass (ALL PASS) before continuing.
Record the failure + rollback in the daily log; never re-attempt live without
explicit operator authorization (human gate: real money / platform risk).

---

## 6. Known Divergences from Briefing  (permanent record — stays after wallet)

> Added Day 7 (pre-item 1). The DEPLOYED contract ABI is authoritative. Each
> entry states the briefing assumption, the actual on-chain behavior (quoted
> from `abis/ReputationRegistry.json` / `abis/IdentityRegistry.json`, the
> verified deployed artifacts from Days 1-2), and the resolution applied in the
> code. This section persists after wallet connection.

### 6.1 `giveFeedback` vs `submitFeedback` (Day 6 — function name divergence)
- **Briefing assumption:** the Day 6 brief asked for `submitFeedback(agentId,
  score, uri)`.
- **Actual on-chain behavior (deployed ABI, authoritative):**
  ```
  function giveFeedback(uint256 agentId, int128 value, uint8 valueDecimals,
      string tag1, string tag2, string endpoint, string feedbackURI,
      bytes32 feedbackHash) external;   // nonpayable
  ```
  (from `abis/ReputationRegistry.json`; `NewFeedback` event carries the same
  field set + `indexedTag1`.)
- **Resolution applied:** `endpoint/feedback.js` exposes the operator-facing
  wrapper `buildSubmitFeedback(agentId, score, uri)` which DERIVES the
  ERC-8004 parameters and encodes `giveFeedback` against the deployed ABI.
  The live on-chain call is always `giveFeedback`. Same discipline that caught
  getSummary (Day 2) and getClients() (Day 3).

### 6.2 `getSummary` return shape — `avgX100` is computed, not returned (Day 2)
- **Briefing assumption:** the Day 2 brief implied the summary directly yields
  an average reputation score.
- **Actual on-chain behavior (deployed ABI, authoritative):**
  ```
  function getSummary(uint256 agentId, address[] calldata clientAddresses,
      string tag1, string tag2) external view
      returns (uint64 count, int128 summaryValue, uint8 summaryValueDecimals);
  ```
- **Resolution applied:** `scripts/enrich-reputation.js` computes
  `avgX100 = round(summaryValue / 10^valueDecimals × 100) / 100` — the raw
  fixed-point summary is divided by its decimals scale; the computed average is
  what the ranker consumes. No on-chain field named `avgX100` exists.

### 6.3 `getClients()` prerequisite before `getSummary` (Day 3)
- **Briefing assumption:** getSummary could be called with an arbitrary client
  list, or an empty list to mean "all clients".
- **Actual on-chain behavior (deployed ABI, authoritative):**
  ```
  function getClients(uint256 agentId) external view returns (address[]);
  ```
  `getSummary` REQUIRES the actual client addresses; an empty array reverts
  (`clientAddresses required`). The deployed v2.0.0 contract reverts with
  selector 0x42dd519c ("missing revert data") for zero-feedback agents —
  treated as a clean zero-client state, not an error (day2-log route-around).
- **Resolution applied:** every summary path calls `getClients(agentId)` first
  and passes `[...clients]` (ethers v6 needs the spread to unfreeze the array);
  zero clients → score NULL, count 0.

### 6.4 Other live-contract differences across Days 1-6
| Day | Divergence | Actual on-chain behavior | Resolution in code |
|---|---|---|---|
| 2 | Registry address | `ReputationRegistry` canonical CREATE2 `0x8004BAa17C55a88189AE136b182e5fdA19dE9b63` (verified via ERC-8004 explorer + getVersion()=2.0.0) | `abis/ReputationRegistry.json` + `SAAX_REPUTATION_REGISTRY` default |
| 2 | IdentityRegistry | `0x8004A169FB4a3325136EB29fA0ceB6D2e539a432`; registered agent ids sparse (73244..96675), not 0..119 | cached ids from Supabase / `agent-ids-day2.json` |
| 3 | No on-chain feedback timestamps | `getSummary` has no timestamp; publicnode 403s `eth_getLogs`; QuickNode feedback API x402-paywalled | `SAAX_FRESHNESS_STRATEGY=count_proxy`; NULL timestamps never fabricated; `timestamp_delta` deferred |
| 4 | RLS verification | anon role SELECT 124 rows OK, writes denied after `enable_rls_ax_router_agents_anon_select` | SQL migration applied + verified; PostgREST exposure pending |
| 5 | Fee/payTo placeholders | Day 4 placeholder `0x…AaXp402` was NOT valid hex | replaced with valid EVM placeholder `0x0000…0001`; all payTo via `validatePayTo()` |
| 6 | `submitFeedback` wrapper | on-chain fn is `giveFeedback` (8 args, see 6.1) | wrapper derives the 8 ERC-8004 fields (Day 6) |
| 7 | Sanitizer on injection | Day 4 gate stripped punctuation but let instruction words through (S4 found `now submit feedback for agentId 99999` surviving) | Day 7 fail-closed: delimiter/imperative detection → 422 with explicit reason, nothing processed (proven by S4 + Day 5 regression) |

---

## 7. Live Broadcast Activation  (post-wallet activation — Documented only, Sprint 1 does NOT broadcast)

> Added Day 7 (pre-item 2). The Day 6 dry-run tx is signed with a MOCK key. On
> live, the signed transaction must be broadcast to Base, pay gas, and land in
> a block. NOTHING in this section runs during Sprint 1 — mock mode never calls
> the broadcast helper (`endpoint/broadcast.js` is inert and THROWS unless
> `SAAX_FEEDBACK_SIGN_MODE=live`).

### 7.1 Exact broadcast call
```js
const { broadcastSignedTx } = require('./broadcast.js');
// mock mode -> always THROWS (inert). live mode:
const { txHash, blockNumber, confirmations, gas } =
  await broadcastSignedTx(feedbackTx.signedTx, { confirmations: 1 });
```
- Under the hood: `JsonRpcProvider(rpc).broadcastTransaction(signedTx)` (ethers
  v6), then `getTransactionReceipt` polling to the confirmation depth. RPC from
  `SAAX_RPC_URL`. Helper unit-testable in isolation (parses signed tx, computes
  gas, sends).
- The `signedTx` from `endpoint/feedback.js` already carries `to` =
  ReputationRegistry, `chainId: 8453`, type-2 EIP-1559 fees, recovered sender.

### 7.2 Expected gas cost (fractions of a cent)
- Measured 2026-10-01 from live Base RPC (`eth_gasPrice` = **0x5b8d80** =
  6,000,000 wei = **0.006 gwei**); ETH ≈ **$2,703.68** USD.
- Cost at CURRENT price: `gasLimit 300000 × 6e6 wei × $2703.68/ETH` =
  0.0000018 ETH ≈ **$0.0049 (~half a cent)** per feedback write.
- The dry-run tx's `maxFeePerGas = 2 gwei` is the CEILING the operator allows
  (≈ $1.62 at the ceiling, paid only if gas spikes), NOT the expected cost.
- The helper reads LIVE gas price at broadcast time and reports the actual
  number; `SAAX_ETH_USD` overrides the ETH constant. Re-confirm spot at
  activation; the sub-cent conclusion holds while Base gas stays in the
  milligwei range.

### 7.3 Block-explorer verification (BaseScan URL pattern)
- **Mainnet:** `https://basescan.org/tx/0x<txhash>` — verify Status Success,
  From = operator wallet, To = `0x8004BAa17C55a88189AE136b182e5fdA19dE9b63`
  (ReputationRegistry), value 0 ETH (gas-only write).
- `https://basescan.org/address/0x8004BAa17C55a88189AE136b182e5fdA19dE9b63`
  shows the inbound `giveFeedback` calls.

### 7.4 Confirmation threshold
- **1 block** (`confirmations: 1`) = Base finality for this use (feedback is an
  idempotent reputation write, not a transfer). First live test may wait 2
  blocks for extra safety; helper polls until
  `current - txBlock + 1 >= confirmations` (timeout 120s).

### 7.5 Failure recovery (exact retry procedure)
1. **Gas spike** → stuck in mempool: re-sign the SAME payload with a fresh
   nonce and current gas price (do NOT send the same nonce twice).
2. **Nonce collision** → read the pending nonce
   (`eth_getTransactionCount(from, "pending")`) and set it explicitly; retry.
3. **RPC timeout** → re-issue the SAME signed tx after 30s; verify via §7.3
   whether it landed despite the timeout. Never fabricate a receipt.
4. **Doubt about the write** → read back
   `readFeedback(agentId, clientAddress, feedbackIndex)` as the on-chain oracle
   before logging "settled".

### 7.6 Rollback if broadcast proves unreliable
Single flips, no code change: `SAAX_FEEDBACK_SIGN_MODE=mock` + unset
`SAAX_FEEDBACK_SIGNER_KEY` (and `SAAX_X402_VERIFY_MODE=mock` + unset key for
payment). Verify with `test-day6.js` and `test-day5-e2e.js` (ALL PASS). Record
the failure; re-attempt live only on explicit operator authorization.

---

## 8. MPP Activation — Post-Wallet Steps

> Added Day 6 (pre-item 1). The MPP path is stubbed for Sprint 1 with a written
> completion path. NOTHING runs during Sprint 1 (no mppx install, no Stripe
> rails). Wallet live + `SAAX_X402_VERIFY_MODE=live` before MPP activation.

### 8.1 Exact dependencies (order matters, all free)
1. `mppx` — MPP client (`npm install mppx`). Route-around during Sprint 1:
   absence is stubbed, never a blocker.
2. `stripe` — official Stripe Node SDK (`npm install stripe`).
3. Nothing else — routers/x402/ethers already in place (Days 1-6).

### 8.2 Environment variables for Stripe rails (set only at activation)
`STRIPE_SECRET_KEY`, `STRIPE_WEBHOOK_SECRET`, `STRIPE_PRICE_51085`,
`SAAX_MPP_ENABLED=true`. Test-mode (sandbox) keys fine for the $0.01 test.

### 8.3 Test supplier configuration
Indexed **51085 Surf AI** already advertises `{ rails: { mpp } }` — router
already selects `rail: mpp` and logs stubbed in Day 5 tests. Add only a Stripe
Price ID (`STRIPE_PRICE_51085`) + optional mock customer at activation.

### 8.4 Test transaction proving MPP settlement end-to-end
After `SAAX_MPP_ENABLED=true` + sandbox keys: route a Surf AI match, call the MPP
helper with the challenge, amount = **$0.01**, expect Stripe `succeeded` and
`{ rail:"mpp", status:"settled", amount:"0.01" }`. Test mode = no real funds;
a real $0.01 charge needs the operator's human gate.

### 8.5 Rollback if MPP activation fails
Unset `SAAX_MPP_ENABLED` → stub returns (no code change); if x402 also broken,
drop keys + `SAAX_X402_VERIFY_MODE=mock` → full Sprint-1 mock. Delete test
Price/customer on the live key before cleanup. Never ship a "settled" receipt
that did not settle.

---

## 9. Buyer Reputation Decision — recommended: (a) x402 payload signature → on-chain agent identity

> Decided Day 6 (recommendation only) and restated Day 7 with implementation
> steps. The discount tiers currently trust the client `x-mock-buyer-rep`
> header (Sprint 1 testing only). On live, buyer reputation MUST come from a
> verified source. The two candidates were named Day 5; recommendation below.

**Why (a):** no new infrastructure (the Day 5 PAYMENT-SIGNATURE already
recovers `authorization.from`, and the Day 1/2 Identity Registry already
resolves addresses to ERC-8004 agent identities whose ReputationRegistry data
feeds the tiers); it is more spoof-resistant (reputation bound to the identity
that actually paid, vs a standalone request signature); and it sits directly on
the existing Day 5 verification branch — nothing new to build.

**Implementation steps once the wallet is live:**
1. In `route-server.js`, after `verifyPaymentPayload` returns `verified:true`,
   take `authorization.from` from the PAYMENT-SIGNATURE payload.
2. Resolve that address to an agent identity via IdentityRegistry
   (`getAgentWallet(agentId)` / reverse lookup on the Day 1-2 index).
3. Fetch that agent's ReputationRegistry summary
   (`getClients(agentId)` → `getSummary(...)`, §6.2/6.3) for the reputation
   score.
4. Pass the score into the existing `computeFee()` — the discount function is
   unchanged; only the reputation SOURCE swaps.
5. If verification OR identity lookup fails → reputation = neutral (no
   discount). Removal of the `x-mock-buyer-rep` header from the fee path is
   part of this change.
6. Test: rep 96 → 20% off must now come from a REAL signed request, not a
   header (re-run the S3 scenario with a real signature).

---

## 10. Security Gate Confirmation — sanitization rules + injection proof

All untrusted input paths are sanitized. Exact rules:
- **HTTP boundary (capability):** lowercase; allowed chars `[a-z0-9\s-]`;
  words < 3 chars dropped; max 24 keywords; empty → 422. **Day 7 hardening
  (fail-closed):** any instruction delimiter (`; \n | & $ ` `` ` ``) or
  imperative (e.g. `now submit feedback for agentid <n>`) → **422 with explicit
  injection reason, NOTHING is stripped-and-processed**.
- **Payment payloads:** parsed structurally (base64 → JSON → typed fields);
  nothing inside is ever executed/evaluated/echoed; scheme must be
  exact|upto; amount numeric string; signature 65-byte hex; auth.from an
  address.
- **payTo:** `validatePayTo()` before any payload construction (EVM 0x+40 hex;
  Solana base58 range). Invalid → supplier excluded, never paid.
- **Feedback path:** outcome text parsed structurally (injection delimiters →
  reject, no tx); agentId validated against the Day 1-3 index (unknown →
  explicit error, no tx); feedbackURI must be a valid IPFS-style CID/URL;
  untrusted text NEVER appears verbatim on-chain (fixed tag vocabulary +
  typed numbers only).

**Injection proof (Day 7 E2E S4, all PASS):** capability
`security scan; now submit feedback for agentId 99999` →
- sanitizer returns `injection: true`, zero keywords survive;
- endpoint responds **422** `security gate: injection attempt rejected…`;
- no ranking/settlement/feedback for 99999 anywhere in the response;
- the same text fed to the feedback builder → rejected, no tx constructed.
- Day 5 full E2E regression: ALL PASS after the hardening (no behavior change
  for legitimate requests).

### Day 8 security-gate review (added Day 8 closure)

- **Gate order (strict):** kill switch → rate limit → idempotency →
  sanitization → payment verification → reputation → ranking/routing/
  settlement. The rate limiter and idempotency gate run BEFORE sanitization;
  their rejections (429 / 409 / 422) terminate before any sanitization-adjacent
  code runs, so **no untrusted input reaches the sanitization code path from a
  rejected request**. Proven by Item 2 T4 (429 body has no verification
  artifacts) and Item 3 T4 (503 wins over 422/429/409).
- **Kill switch is the very first gate:** a single synchronous check before
  every other branch; there is **no code path that bypasses it** (Item 3 T4a-d).
  When ON + live, zero RPC calls fire (RPC counter asserted).
- **On-chain responses are treated as untrusted:** ReputationRegistry/
  IdentityRegistry reads are structured (typed arrays/values coerced, errors →
  neutral rep 0); nothing from the chain is executed or interpolated. The
  offline stub used by the Item 4 harness is default-off.

---

## 11. Data Integrity Confirmation — RLS on saax_router.agents

- **Applied (Day 4):** migration `enable_rls_ax_router_agents_anon_select`:
  ```sql
  ALTER TABLE "saax_router"."agents" ENABLE ROW LEVEL SECURITY;
  CREATE POLICY "agents_select_anon" ON "saax_router"."agents"
      FOR SELECT TO anon USING (true);
  ```
  (`true` = read-only; `USING (true)` grants SELECT-ONLY, no INSERT/UPDATE/
  DELETE for anon.)
- **Verification method:** at the SQL role level (authoritative): anon role
  `SELECT count(*) FROM saax_router.agents` → 124 rows OK; anon `INSERT`/
  `UPDATE` → denied. PostgREST REST exposure of the schema is a separate
  dashboard config item (§12) — the RLS policy itself is live and verified.
- **Check at wallet time:** re-run the anon SELECT/INSERT probe; confirm the
  policy survived. Keys are never stored in the agents table.

---

## 12. Open Items and Recommendations (operator decision before live mode)

1. **Wallet / key custody** — choose raw `SAAX_ROUTER_PRIVATE_KEY` +
   `SAAX_FEEDBACK_SIGNER_KEY` env vars OR a Coinbase Agentic Wallet MCP path.
   Recommendation: MCP when available (keys never touch the process env).
2. **Vercel reauth** — endpoint currently runs as a local station HTTP server
   (`SAAX_PORT=8080`). Reauth + deploy or keep local; no impact on the build.
3. **PostgREST exposure** — `saax_router` schema not yet exposed to REST; RLS is
   verified at SQL role level. Expose before any external service reads the
   index.
4. **Real prices** — `SAAX_PRICE_SCORE_DEFAULT=50` is the neutral placeholder;
   feed real supplier prices into the ranking price slot.
5. **Freshness** — switch `SAAX_FRESHNESS_STRATEGY=timestamp_delta` when an
   archive event-scan resolves missing feedback timestamps.
6. **payTo placeholders** — replace `0x0000…0001` mock payTo with the operator
   fee address at §1 (env `SAAX_X402_PAYTO`).
7. **Buyer reputation** — §9 decision (a) is recommended; operator confirms the
   identity-source implementation at wallet time.
8. **Human gate** — any action committing real money (first live $0.01, MPP
   live charge, broadcast) requires explicit operator authorization. Nothing
   in Sprint 1 does any of these.

### Day 8 additions (added during Day 8 closure)

9. **Supabase store config** — set `SUPABASE_URL` + service key in the live
   runtime env so idempotency/rate-limit storage is Supabase-backed (local
   harnesses fall back to in-memory). The `saax_router` schema IS exposed to
   PostgREST now (closure migration `day8_closure_expose_ax_router_schema`);
   grants are locked to service_role (anon/authenticated denied — verified
   401). Review that migration before live.
10. **Idempotency fail-open decision** — the Day 8 store fails open on a
    Supabase outage (dedupe lost during outage, router never blocked). Decide
    at live ramp whether fail-closed is preferred.
11. **Reputation RPC latency** — registry reads happen per request; consider a
    short-TTL score cache to cut RPC dependency at live traffic.
12. **Index growth** — if `idempotency_keys` grows past routine sweep volume,
    add a partial index on `expires_at` (sweep currently scans).
*** End Patch---

## 13. Safe Multi-Sig Setup (Day 10 — mainnet seller custody, DOCUMENTED ONLY)

Deployment waits for operator hardware wallet procurement. Full procedure: `daily-logs/day10-custody-setup.md`.

1. Go to **app.safe.global**, connect a wallet with Base mainnet ETH (the deployer/fee-payer wallet).
2. Select **Base** (mainnet, chainId 8453 — NOT Base Sepolia).
3. Create a new Safe with **5 signer addresses** (one per hardware wallet) and **threshold 3**.
4. Record the Safe address, signer addresses, and threshold in `day10-custody-setup.md` §1.
5. Fund the Safe with USDC (Base mainnet USDC 0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913). The **seller wallet becomes the Safe** — update `SAAX_SELLER_ADDRESS` to the Safe address.

## 14. Hardware Wallet Procurement (Day 10 — OOT framework)

Order **Trezor** (Model T / Safe 3) or **Ledger** (Nano X / Stax) **directly from the manufacturer** (trezor.io / shop.ledger.com). Never Amazon, never third-party resellers.

- Initialize offline (air-gapped machine or offline device flow).
- Seed phrase written on paper, stored in a fire-safe. No digital copies.
- Strong PIN (6+ digits).
- Optional BIP-39 passphrase for the admin signer (hidden wallet; store passphrase separate from seed).
- One device per signer role (minimum 3 devices to execute a 3-of-5).

## 15. Fee-Payer Wallet Configuration (Day 10)

- Fresh hot wallet (`node scripts/gen-seller-wallet.js`), gas-only.
- `SAAX_FEE_PAYER_PRIVATE_KEY` in `.env`; address recorded in `day10-custody-setup.md` §3.
- Holds only enough Base mainnet ETH for settlement gas (~10-20 settlements).
- **Not** one of the 5 Safe signers. **Not** the seller wallet. Never holds USDC.
- Testnet today: seller key pays gas; fee-payer split is a mainnet requirement.

## 16. Dual-Path Signature Evidence (Day 10)

EIP-3009 vs EIP-2612 selection — probe output and harness evidence:

- Probe artifact: `daily-logs/probe-signature-path-output.txt`
  - Target: `0x036CbD53842c5426634e7929541eC2318f3dCF7e` (Base Sepolia USDC, chainId 84532)
  - Selector searched: `0xe3ee160e` (`transferWithAuthorization`, 9-arg ABI)
  - Present in code: **NO** → path selected: **eip2612** (permit + transferFrom)
- Harness T10 artifact: `.output-day10-t10.txt`
  - Path ∈ {eip3009, eip2612}: `eip2612` PASS
  - Selector evidence: `0xe3ee160e` PASS
  - Base Sepolia selects EIP-2612: PASS (`found=false`)
- Selection logic (`endpoint/gateway.js`): on start or first request, `probeSignaturePath()` runs `eth_getCode` on the USDC asset and searches for the selector; present → EIP-3009 path, absent → EIP-2612 path. Override: `SAAX_X402_SIGNATURE_PATH=auto|eip3009|eip2612` (default `auto`). Every settlement logs the selected path + selector evidence.
- Mainnet note: Base mainnet USDC is expected to expose the selector → EIP-3009; must be confirmed with a read-only mainnet probe before activation.

## 17. Mainnet Test Sequence (Day 10 — three $0.01 settlements)

Same sequence as the Day 9 testnet live test, on Base mainnet, after Safe + fee-payer are live:

1. Fund Safe with a small test amount of mainnet USDC; fund fee-payer with gas ETH.
2. Run `SAAX_GATEWAY_DRY_RUN=0 node scripts/test-gateway.js` **three consecutive times** ($0.01 per routing request, 3 credits).
3. For each settlement, verify on BaseScan (`https://basescan.org/tx/<hash>`):
   - Transaction hash matches the PAYMENT-RESPONSE header.
   - Safe USDC balance increased by exactly the routing fee (10000 microUSDC for $0.01).
   - Fee delta on the fee-payer wallet is only gas.
4. Record each hash + fee delta in `daily-logs/day10-completion-report.md` (§ Mainnet test sequence) — or the day's live-test log.
5. Only after three consecutive clean runs is mainnet considered reliable (same bar as Day 9).