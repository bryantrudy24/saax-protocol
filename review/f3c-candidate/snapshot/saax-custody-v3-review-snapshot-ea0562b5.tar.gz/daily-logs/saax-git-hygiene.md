# SAAX GIT HYGIENE — INCIDENT LOG

## HISTORY REWRITE INCIDENT — COMPLETE (2026-10-06)

### Background
The initial commit (`4854caef`) contained a live `.env` and a raw archived seller key. The repo is and remains **private since creation**, which limited exposure, but the credentials were live and present in history. Rotation neutralized the active threat; this rewrite removed the record.

### Leaked files (initial commit `4854caef`, now purged)
- `.env`
- `daily-logs/archived-keys/seller-wallet-ARCHIVED-2026-10-04T07-41-49-751Z.txt`

### Credential inventory (key names only — values never printed)
- `POSTGRES_PASSWORD` — Postgres database authentication
- `POSTGREST_JWT_SECRET` — JWT signing secret for the PostgREST API layer
- `SAAX_POSTGREST_KEY` — PostgREST API key
- `SAAX_SELLER_PRIVATE_KEY` — seller wallet key (original archived 2026-10-04)
- `SAAX_TEST_BUYER_KEY` — test buyer wallet key

### Rotation confirmation (performed 2026-10-06 before the rewrite)
- **Postgres password rotated** — old password rejected (`password authentication failed`), new password works (psql `SELECT 1` → `1`)
- **POSTGREST_JWT_SECRET rotated** — PostgREST reconnected cleanly with the new secret (119-row table read through the API)
- **SAAX_POSTGREST_KEY re-signed** with the new secret (`JWT provisioned: yes (3 parts, len 201)`)
- **Seller key `0x6611F...` accepted as loss** (dust only) — not drained
- **Test buyer key** — carried over unchanged from the prior rotation (operator accepted its dust exposure; not part of this rotation scope)

### History rewrite
- Tool: `git filter-repo` 2.47.0, run on the fresh backup clone (`saax-backup2`), `--path .env --path daily-logs/archived-keys --invert-paths` (1 commit parsed, 5 rewritten)
- **Old root:** `4854caef` → **New root:** `5ad5f6a5`
- **New HEAD:** `c7cfb9f2` (full `c7cfb9f2eeb9f095eab1a3d2059fc0985a9e87d8`)
- **Force-push completed:** 2026-10-06, `+ c74a5c1a...c7cfb9f2 main -> main (forced update)`
- **Both leaked paths verified absent from ALL history** (local clone and remote): `git log --all --full-history -- .env` and `-- daily-logs/archived-keys` both return empty; only `.env.example` remains (safe keep)
- Backups intact at `C:\Users\Bryant\saax-backup` and `C:\Users\Bryant\saax-backup2` (do not touch)

### GitHub retention note
GitHub may retain the unreachable old commits (containing the leaked `.env`) for an indeterminate period after the force-push. If the operator wants garbage collection, contact GitHub Support to request it.

### Standing constraint (updated — now precaution, not live exposure)
The repo remains **private**. If it ever goes public **or** a collaborator is added, treat **all pre-rewrite credentials** as compromised and re-rotate. With the rewrite complete, the leaked files are gone from the remote; this constraint is a precaution rather than a live exposure.## pg_hba.conf Tightening (2026-10-06)

- **Ground truth:** `SHOW hba_file;` → `/var/lib/postgresql/data/pg_hba.conf` (authoritative). `data_directory` same path; `/var/lib/postgresql/data` is a real directory, **not a symlink** (`readlink -f` returns the same path).
- **Change applied in place via `sed -i` inside the container (no `docker cp`):**
  - `host all all 127.0.0.1/32 trust` → `host all all 127.0.0.1/32 scram-sha-256`
  - `host all all ::1/128 trust` → `host all all ::1/128 scram-sha-256`
  - `local all all trust` **left unchanged** (container startup path)
  - `local/host replication` loopback trust + final `host all all all scram-sha-256` **unchanged**
- **Reload:** `SELECT pg_reload_conf();` → `t` (no restart needed).
- **Verification (all passed):**
  - Loopback `127.0.0.1:5432` + password → SELECT 1 ✅
  - Loopback `127.0.0.1:5432` no password → rejected (`fe_sendauth: no password supplied`) ✅
  - Host port `5433` + password (via `host.docker.internal` from container) → SELECT 1 ✅
  - Host port `5433` no password → rejected ✅
  - PostgREST API `localhost:3000/agents?limit=1` with current key → HTTP 200 ✅
- **Divergence note:** `psql` is not installed on the host PATH; all connection tests were executed via `docker exec` (equal fidelity, including the real host-port 5433 path through the container network). Earlier `docker cp` copy-back did not take effect because it was aimed at the wrong path; the in-place `sed -i` to the `SHOW hba_file;` path resolved it.
- **No revert needed** — PostgREST and the DB both healthy after the change.