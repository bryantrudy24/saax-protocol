> This log was written under the previous project name AX Router; the project is now SAAX Protocol.

SAAX Protocol — SPRINT 1 DAILY LOG
DAY 2 · Reputation Fetch Layer
Date: 2026-10-01 (run 27849e15)

WHAT WAS BUILT
- scripts/probe-reputation.js, probe-reputation2.js: verified the ReputationRegistry address
  (0x8004BAa17C55a88189AE136b182e5fdA19dE9b63 — canonical CREATE2 addr per ERC-8004 Explorer)
  and the getClients(agentId) -> getSummary(agentId, clients, '', '') flow against live Base RPC.
- scripts/enrich-reputation.js: full enrichment pipeline for the 119 cached agent ids.
  Returns (count, summaryValue, valueDecimals); avgX100 = summaryValue / 10^valueDecimals.
- data/agent-ids-day2.json (119 real ids from DB), data/reputation-day2.json,
  data/upsert-reputation.sql (applied to Supabase).

WHAT WAS TESTED
- Contract v2.0.0 verified: getVersion()=2.0.0, getIdentityRegistry()=0x8004A169FB4a3325136EB29fA0ceB6D2e539a432 (match).
- Empty clientAddresses reverts with "clientAddresses required" — must pass getClients() result.
- READ-ONLY validation vs known leaderboard agents through same code path:
  agent 1380 (Captain Dackie): 1514 clients, 1534 feedback, score 99  [leaderboard: 99]
  agent 51085 (Surf AI): 31 clients, 54 feedback, score 99          [leaderboard: 90]
  agent 55985 (Knidos fund): 9745 clients, 13168 feedback, score 71 [leaderboard: 91]
  agent 84947 (NuSHA): 1 client, 1 feedback, score 92              [our index]
- RPC reliability: mainnet.base.org returns FALSE reverts on healthy contracts; switched to
  base-rpc.publicnode.com which is consistent (verified same agents on both). publicnode 403s
  eth_getLogs, so event-level timestamp derivation was attempted via logs + explorer and
  abandoned (below).

WHAT WAS STORED
- 5 agents with real on-chain reputation (all active, score/count verified):
  84979 Merv Microfund 94/1 · 84947 NuSHA 92/1 · 84978 Brisa Research 92/1
  84982 5vl Auto 92/1 · 84981 Javier CodeFix 91/1
- 114 agents with zero feedback (clean getClients []) — reputation_score NULL, feedback_count 0.
- All rows written to Supabase saax_router.agents; read-back query confirms
  5 scored + 114 zero + 119 total.

WHAT IS MOCKED
- last_feedback_timestamp: no reliable on-chain timestamp source (getSummary has none;
  eth_getLogs 403 on publicnode; QuickNode feedback API is x402-paywalled). Set NULL rather
  than fabricate. Day 4+ can derive from NewFeedback event scan via an archive that allows logs.
- All payment paths remain placeholder by design.

WHAT BROKE / ROUTED AROUND
- mainnet.base.org archive node: inconsistent "missing revert data" on healthy contracts.
  Switched default RPC to base-rpc.publicnode.com; scripts take SAAX_RPC_URL override.
- ethers v6 array-arg quirk: getClients() returns frozen array; pass [...clients] to getSummary.
- Initial probe tested ids 0..119 — wrong; real registered ids are sparse (73244..96675).
  Fixed by exporting ids from Supabase.

WHAT IS NEXT
- Day 3 (ranking): note that the 119-agent index contains only 5 agents with any reputation —
  the high-reputation leaderboard suppliers (1380, 2290, 55985, 51085, ...) are NOT in the
  index. Recommendation: expand index or maintain a separate high-reputation supplier pool
  so the router ranks meaningful matches for capability queries.