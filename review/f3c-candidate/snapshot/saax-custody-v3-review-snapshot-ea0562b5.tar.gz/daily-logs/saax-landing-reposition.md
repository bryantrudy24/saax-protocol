# SAAX Landing Reposition — Protocol / Network / Router

Date: 2026-10-06. Landing page repositioned from the older one-thing framing
(routing + settlement) to the three-layer architecture: Protocol (standard),
Network (federated nodes), Router (commercial product). **The Router was NOT
removed — it remains fully described as the commercial product and primary
revenue engine.**

---

## 1. Architectural repositioning

The page now presents three layers in order:

1. **SAAX Protocol** — the vendor-neutral standard for governed, contract-defined, outcome-verified, recoverable and auditable economic commitments between autonomous systems.
2. **SAAX Network** — the federated set of independently operated endpoints that exchange conforming SAAX commitment messages.
3. **SAAX Router** — the optional commercial service for discovering, ranking and matching providers and connecting commitments to supported settlement rails. Base, USDC, x402, and MPP are the Router's current settlement profile — **not** requirements of the Protocol.

---

## 2. Hero and copy changes

- **Headline:** "The commitment protocol for autonomous commerce." (was "The routing and settlement layer for AI agent commerce.")
- **Subheadline:** "SAAX gives autonomous systems a standard way to prove authority, define terms, verify outcomes, recover from failure, link settlement and preserve an auditable record."
- **Primary CTA:** "Read the Protocol →" → `/protocol`
- **Secondary CTA:** "Try SAAX Router →" → `/docs` (was the MCP Registry listing)
- **Trust badges:** `Live on Base Mainnet` kept; **`ERC-8004 Compatible` → `Commitment-Neutral`** (ERC-8004 is not a protocol-level requirement); **`x402 & MPP Settlement` → `Rail-Agnostic Settlement`** (Router choices, not Protocol requirements); `Open Registry` kept.
- **What It Does** section replaced by a **three-layer presentation** (`One Protocol, Three Layers`) with the exact layer copy.
- **New "What the Protocol Defines" section** — the 9 differentiators (Authority, Terms, Acceptance criteria, Evidence, Outcome verification, Recovery, Settlement linkage, Finality, Audit).
- **"How a Commitment Moves"** — the 4-step flow retained (step 4 wording: "Outcome feedback updates").
- **For Developers** restructured to three paths: Read the Protocol (→ `/protocol`), Try SAAX Router (→ `/docs`, live endpoints), Deploy a Node (coming soon).
- **Recovery disclaimer** added to "Before You Use SAAX": "SAAX standardizes recovery and dispute states within the commitment lifecycle. It does not guarantee reimbursement, reversal, or resolution of disputes..."
- **For Suppliers** paragraph aligns with the new framing (providers "found and ranked through the SAAX Router").
- Footer adds the `Commitment Lifecycle Spec` link (`/spec`).

---

## 3. New pages

- **`landing/protocol.md`** (`/protocol`, 7168 bytes) — the Read-the-Protocol target: overview, why it exists (the 9 questions), the full lifecycle sequence (Authority → Commitment → Contract Terms → Execution → Evidence → Verification → Fulfilled or Failed → Settlement or Recovery → Finality → Audit), evidence/authority external-by-design, settlement-linkage rail-neutral, the Network, the Router as reference implementation, link to `/spec`. **No Router internals** (no signer/vault/gas/module names).
- **`landing/spec.md`** (`/spec`, 7232 bytes) — the commitment lifecycle spec rendered for the public: lifecycle, evidence schema + verification-policy model + evaluation, authority-proof structure + validation, settlement-rail neutrality + rail interface. Stripped of internal-only notes (module file paths, wiring seams, divergence details).

---

## 4. Metadata additions

- **Canonical URLs** — `<link rel="canonical">` on the homepage (the other pages are single-file rewrites; the homepage carries the canonical).
- **Open Graph** — og:title, og:description, og:url, og:type, og:image on the homepage; twitter:card summary_large_image.
- **OG image** — `landing/og-image.png` (783 KB, 1200×630, valid PNG, generated with the text-capable image model).
- **JSON-LD** — `SoftwareApplication` schema on the homepage.
- **`landing/robots.txt`** — Allow all + Sitemap reference.
- **`landing/sitemap.xml`** — the five URLs (/, /protocol, /docs, /terms, /spec).

---

## 5. Vercel configuration

`vercel.json` rewrites updated (9 total, valid JSON):

```
/            → /landing/index.html
/protocol    → /landing/protocol.md
/docs        → /landing/docs.md
/terms       → /landing/terms.md
/spec        → /landing/spec.md
/robots.txt  → /landing/robots.txt
/sitemap.xml → /landing/sitemap.xml
/og-image.png→ /landing/og-image.png
/mcp         → /api/mcp.mjs   (unchanged)
```

Deployment: `vercel deploy --prod` → Ready in 19s, aliased `https://saax-protocol.com` (production `ax-router-l3syz1a2j-bryant-s-projects5.vercel.app`).

---

## 6. Verified URLs (all live, HTTP 200)

| URL | Result |
|---|---|
| https://saax-protocol.com | 200, 17345 bytes (new hero + 3 layers + 9 diff items + recovery disclaimer) |
| https://saax-protocol.com/protocol | 200, 7168 bytes |
| https://saax-protocol.com/spec | 200, 7232 bytes |
| https://saax-protocol.com/docs | 200, 3728 bytes |
| https://saax-protocol.com/terms | 200, 3103 bytes |
| https://saax-protocol.com/robots.txt | 200, 69 bytes |
| https://saax-protocol.com/sitemap.xml | 200, 385 bytes |
| https://saax-protocol.com/og-image.png | 200, 783119 bytes |
| https://www.saax-protocol.com/mcp | 200, MCP initialize handshake OK |
| https://settlement.saax-protocol.com/health | 200, 249 bytes |

Content-level: no stale "verified service providers" phrase anywhere; no GitHub repo link present (the `io.github.bryantrudy24` strings are the MCP Registry listing path, not the repo — verified by scan).

---

## 7. GitHub link confirmation

The GitHub repo link was already removed in the prior sprint (verified: the only GitHub-domain strings on the page are the MCP Registry listing URLs `registry.modelcontextprotocol.io/.../io.github.bryantrudy24%2Fsaax-protocol/versions`, which are required and correct). No action needed beyond confirmation.

---

## 8. Tests

Representative regression gate (landing content does not touch endpoint/gateway code; full 13-suite gate was green in the prior sprint):

- `scripts/test-evidence.js` — 9 passed, 0 failed
- `scripts/test-authority.js` — 10 passed, 0 failed
- `endpoint/test-day11-smoke.js` — ALL PASS

---

## 9. Divergences

1. **Live MCP serverInfo reports 1.0.2 while the registry metadata is 1.0.3** — a pre-existing, known cosmetic drift from the domain-migration sprint (the API function's version string was not bumped when the registry listing went 1.0.3). Not introduced by this sprint; no endpoint code changes were permitted here. Client resolution uses registry metadata (1.0.3); the flag is recorded for a future version-string bump.
2. The OG image could not be vision-verified (no vision route on the session model); verified structurally instead (valid PNG signature, 1200×630, 783 KB, generated with the text-capable `gemini-3-pro-image` model). Recommend a visual check by the operator.
3. `docs.md` heading encoding was briefly mangled by an in-place PowerShell edit (em-dash → `?`); file rewritten cleanly via proper UTF-8 write (verified: 0 replacement chars, correct em-dash).
4. Open Graph preview (opengraph.xyz etc.) not run — external tool, optional; the metadata and image are served correctly per direct fetch.

---

## 10. Commit

`3ef75e4d` — "Reposition landing page: Protocol / Network / Router separation; add protocol, spec, OG, sitemap" — 8 files, +416/−64, pushed to `main` (`4d0ceefb..3ef75e4d`).
## Amendment — Truthful Status Indicators (2026-10-06)

**Principle applied:** every claim on the landing page states its current stage — live, draft, planned, or coming soon. No aspirational framing; no overstating what exists.

### Changes made
1. **Three-layer status badges** (`landing/index.html`):
   - **SAAX Protocol** — pill `Draft` (amber) + status line "v1 draft — open for comment."
   - **SAAX Network** — pill `Planned` (gray) + status line "One node is live today — the SAAX Router. Multi-operator federation is planned."
   - **SAAX Router** — pill `Live` (green) + status line "Live on Base mainnet. Test with small amounts."
   - Distinct pill styling per status (`.status-live` green, `.status-draft` amber, `.status-planned` muted) — visually distinct, clearly readable, placed inline next to each layer title.
2. **For Developers CTAs** — restructured from 3 to 4 entries, each with its real status:
   - Read the Protocol — **Live** (link → /protocol)
   - Try SAAX Router — **Live** (link → /docs)
   - Run Conformance Tests — **Coming Soon** (disabled: `.disabled-cta` styled as a non-clickable outlined chip, no link, `cursor:default`)
   - Deploy a Node — **Coming Soon** (disabled, no link)
3. **Recovery disclaimer updated** — "Before You Use SAAX" now leads with the heading **What SAAX Does Not Guarantee** and the corrected text: "SAAX standardizes recovery and dispute states within the commitment lifecycle. Enforcement mechanisms are in development. SAAX does not guarantee reimbursement, reversal, or resolution of disputes. Enforcement depends on the parties involved and any arbitration mechanisms they agree to."
4. **Spec scope note** — `landing/spec.md` now opens with a **Scope** section: the specification is under active development; current documents cover the commitment schema, lifecycle, authority and evidence interfaces, settlement linkage, and error codes; additional documents (conformance fixtures, node deployment guidance, threat model, full error taxonomy) are in development.
5. **Hero badge updates** — replaced the four neutral badges with truthful per-claim stages, color-coded:
   - Router: Live on Base Mainnet (green)
   - Protocol: v1 Draft (amber)
   - Network: Planned (gray)
   - MCP Registry: Listed (blue)
   - Dropped "Commitment-Neutral" and "Rail-Agnostic Settlement" framings from the hero badge row per the amendment (settlement rails are a Router implementation detail, not a Protocol claim; the layer cards below carry the accurate rail description).

### Constraint compliance
- Coming Soon items are visibly disabled and do not look clickable (no `<a>`, disabled-chip style).
- SAAX Router remains fully described and live — the commercial product was not weakened.
- No Router internals, competitor names, uptime claims, or architecture details exposed.
- No test suites touched (landing markup + spec doc only); endpoint code untouched.

### Verification
All six URLs verified live after redeploy: landing page (status pills + 4 CTAs + updated disclaimer), /protocol (200), /spec (scope note present), /docs (unchanged), /terms (unchanged), www.saax-protocol.com/mcp (MCP handshake intact). Commit: [commit hash recorded at deploy time].
