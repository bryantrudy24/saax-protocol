# SAAX Stripe Webhook — Integration Record

Date: 2026-10-07

## 1. Webhook function

- **File:** `api/stripe/webhook.mjs` (Vercel serverless, Node runtime)
- **Live URL:** `https://saax-protocol.com/api/stripe/webhook`
- **Events handled:**
  - `checkout.session.completed` — creates the subscription record for a new customer (email, customer id, subscription id, tier from `amount_total`, status `active`, period end)
  - `invoice.paid` — extends the subscription period for recurring billing (`lines[0].period.end` → `current_period_end`, status `active`)
  - `invoice.payment_failed` — marks the subscription `past_due`
  - Default branch — acknowledges unhandled types so Stripe stops retrying

## 2. Signature verification

- Uses the **RAW request body** (never parsed JSON) via `Stripe.webhooks.constructEvent(rawBody, req.headers["stripe-signature"], STRIPE_WEBHOOK_SECRET)`
- `constructEvent` is called **statically** (`Stripe.webhooks.constructEvent`) — requires only the webhook signing secret, no REST key
- `api.bodyParser: false` in the function config — Vercel must NOT parse the body (JSON parsing would destroy the exact signed bytes)
- Unsigned/invalid requests → **HTTP 400** with a clear error (verified live: `{"error":"invalid_signature","message":"No stripe-signature header value was provided."}`)
- The endpoint rejects ANY request without a valid signature (no publicly callable path without the secret)

## 3. Shared Supabase client

- **File:** `api/lib/supabase.mjs` — instantiated once per cold start, imported by BOTH the webhook and the MCP server gating
- **Key used:** the **anon key** (`SUPABASE_ANON_KEY` env) — safe because the subscriptions table has **RLS enabled with ZERO policies** (no direct anon reads/writes possible), and all access goes through **SECURITY DEFINER RPCs**
- Env vars: `SUPABASE_URL`, `SUPABASE_ANON_KEY` (set in Vercel production)

## 4. Subscriptions table schema (existing in Supabase project `codboejrwohkjidrrcgl`)

| Column | Type | Notes |
|---|---|---|
| id | bigint identity | PK |
| email | text | customer email |
| stripe_customer_id | text | nullable |
| subscription_id | text | **unique** |
| price_tier | text | Developer / Business |
| amount_cents | integer | nullable |
| currency | text | nullable |
| status | text | default 'active' (active, past_due, canceled) |
| current_period_end | timestamptz | |
| created_at / updated_at | timestamptz | default now() |

RLS: **enabled, zero policies** — no client can read/write directly.

## 5. RPC signatures (SECURITY DEFINER, granted EXECUTE to anon)

```sql
CREATE OR REPLACE FUNCTION public.upsert_subscription(
  p_email text, p_stripe_customer_id text, p_subscription_id text,
  p_price_tier text, p_status text, p_current_period_end timestamptz
) RETURNS public.subscriptions ... ON CONFLICT (subscription_id) DO UPDATE ...;

CREATE OR REPLACE FUNCTION public.lookup_subscription(p_email text)
RETURNS SETOF public.subscriptions ... WHERE email = p_email AND status='active'
  AND current_period_end > now() ORDER BY current_period_end DESC LIMIT 1;
```

## 6. Deployment

- Commits (pushed to `main`):
  - `279b5e68` — Add Stripe webhook and shared Supabase client
  - `79a0a906` — Fix webhook raw body handling on Vercel (bodyParser:false)
  - `dcd66994` — Use static Stripe.webhooks.constructEvent (no REST key required)
  - `e316e1f9` — Add premium gating to MCP server (evidence + authority tools)
  - `7fdbc484` — Gate premium tools on explicit subscriptionEmail argument
  - `dd7820df` — Add webhook E2E simulator
- Vercel env set: `SUPABASE_URL`, `SUPABASE_ANON_KEY` (both Secret, Production)
- **PENDING: `STRIPE_WEBHOOK_SECRET`** — operator must supply the `whsec_...` value (see §9)

## 7. Gating logic (MCP server)

- **File:** `api/mcp.mjs`
- **Premium tools gated:**
  - `get_evidence_verification` — validates evidence against acceptance criteria (wraps `endpoint/evidence.js` evaluateCriterion)
  - `get_authority_validation` — validates authority proofs (wraps `endpoint/authority.js`)
- **Identity resolution:** the caller passes `subscriptionEmail` as a tool argument (the MCP SDK does not expose HTTP headers to tool handlers; agent-driven identity presentation is the standard). The gate calls `lookupSubscription(email)` and requires `status='active'` AND `current_period_end > now()`.
- **Denied response:** `{status:"payment_required", reason:"no_active_subscription", tool, subscribe: <Payment Link>}`
- **Non-premium tools (6)** remain ungated: get_protocol_info, get_routing_fee, ping, route_request, get_commitment, list_capabilities

## 8. Test results

### Local E2E simulator (`simulate-webhook-e2e.mjs`) — ALL PASS against real Supabase
| Step | Result |
|---|---|
| checkout.session.completed — signature verified | ✅ |
| Subscription recorded (active, Developer) | ✅ |
| Gate lookup active | ✅ (found, active) |
| invoice.paid — signature verified, period extended (+60d → 2026-12-06) | ✅ |
| invoice.payment_failed — signature verified, status → past_due | ✅ |
| Gate denies after past_due | ✅ `payment_required (correct)` |

### Live MCP gating (deployed endpoint) — BOTH PATHS PROVEN
| Call | Result |
|---|---|
| get_evidence_verification, seeded active sub `live-gate-test@saax.dev` | ✅ **`verified` / `satisfied`** (evidence validated, criterion satisfied) |
| get_authority_validation, unknown email | ✅ **`payment_required` / `no_active_subscription`** + Payment Link |

### Test suites (all green)
- MCP smoke: **17/17** (8 tools listed incl. both premium)
- evidence: 9/9 · authority: 10/10 · conformance: 55/55

## 9. Pending operator dependency (hard blocker for the live signed deliverable)

**`STRIPE_WEBHOOK_SECRET` (whsec_...) is not in Vercel env.** Stripe only shows the signing secret once, at webhook-endpoint creation; it cannot be retrieved via API (the connector redacts it). Both remaining test paths converge on this value:

1. **Operator:** Stripe Dashboard → Developers → Webhooks → `we_1UNr4wAWggRLQc7cvbCMaJKw` → Signing secret → copy `whsec_...`
2. **Set it:** `echo <whsec...> | vercel env add STRIPE_WEBHOOK_SECRET production`
3. **Redeploy:** `vercel deploy --prod`
4. **Live signed test:** run `simulate-webhook-e2e.mjs` with `STRIPE_WEBHOOK_SECRET` set, or use `stripe trigger checkout.session.completed` (CLI) once the value is live — the deployed endpoint will then accept real Stripe deliveries and record to Supabase.

## 10. Divergences

- **The `whsec_...` signing secret could not be retrieved via the Stripe API/connector** (redacted at creation). Webhook endpoint registered (`we_1UNr4wAWggRLQc7cvbCMaJKw`) but live signed delivery is pending the operator supplying the secret.
- Stripe CLI is **not installed** — test events were simulated locally with the exact HMAC algorithm Stripe uses, plus live MCP gating tests against the real endpoint.
- The MCP SDK does not expose HTTP headers to tool handlers → identity is passed as `subscriptionEmail` argument (documented in tool descriptions) instead of a header.
- The subscriptions table already existed from a prior sprint (reused, not recreated); RPCs were created new.
- `vercel env add` first attempt accidentally captured a stray `t` value for SUPABASE_URL — corrected by re-adding the real URL.
- Vercel's Node runtime Webhook initially 500'd on `Invalid supabaseUrl` (stale env during deploy) — fixed with the correct env + redeploy.