# SAAX Protocol — MCP Registry Publication

Date: 2026-10-05 · Registry: registry.modelcontextprotocol.io · Package: `saax-protocol`

## 1. The npm package — `saax-protocol@1.0.0` live

The MCP server package is published to npm and live:

- Package name: `saax-protocol`
- Live version: **1.0.0**
- The `0.0.0-stage` version visible on npm is **npm's staging artifact** — it exists because npm intermediates package registrations through a stage of version `0.0.0-stage` during the publish flow. It is NOT a real release and must never be treated as one.

## 2. The registry listing — `io.github.bryantrudy24/saax-protocol` version 1.0.1

Verified against `https://registry.modelcontextprotocol.io/v0.1/servers?search=io.github.bryantrudy24/saax-protocol`:

| Field | Value |
|---|---|
| `server.name` | `io.github.bryantrudy24/saax-protocol` |
| `server.version` | **1.0.1** |
| `server.remotes[0].type` | `streamable-http` |
| `server.remotes[0].url` | **`https://ax-router.vercel.app/mcp`** |
| `_meta.io.modelcontextprotocol.registry/official.status` | **`active`** |
| `_meta.io.modelcontextprotocol.registry/official.isLatest` | **`true`** |
| `publishedAt` | **`2026-10-05T11:15:20.960874Z`** |
| `statusChangedAt` | `2026-10-05T11:15:20.960874Z` |
| `updatedAt` | `2026-10-05T11:15:20.960874Z` |

Note: the registry also returns a **second entry, version 1.0.0**, which still carries the placeholder URL `https://mcp.saax-protocol.example.com/mcp` and `isLatest: false`. It is historical and inert — clients resolve to the latest entry (1.0.1).

## 3. The live endpoint — `https://ax-router.vercel.app/mcp`

The MCP server is deployed on **Vercel** as the `ax-router` project (`prj_o2g1a69CbitjPwtT3DAxevJkaX5v`). The endpoint:

- URL: `https://ax-router.vercel.app/mcp`
- Transport: **streamable-http** (MCP) — `POST /mcp` with JSON-RPC `initialize` to begin
- Plain GET (no `Accept: text/event-stream`) returns a friendly JSON info block for browsers/crawlers/verifiers, listing the server name, version, endpoint, and available tools
- CORS: OPTIONS preflight answered with 204

## 4. GitHub auth method — device-code flow with the 5-minute JWT constraint

Publishing to the MCP registry authenticates against GitHub **via the device-code flow**:

1. `mcp-publisher` / `republish-mcp.bat` initiates a GitHub device authorization request.
2. The operator opens the device URL and enters the displayed code in a browser.
3. GitHub issues the registry a short-lived **JWT with a ~5-minute validity window** — the registry's publish operation must complete **inside that window** or the JWT expires and the publish is rejected.

**The login-publish race condition:** because the JWT window starts at login and is short, any pause between the device-code approval and the actual registry publish call can invalidate the token mid-flight. If the operator approves the login but the publish step is delayed (or the CLI re-prompts), the JWT can expire before the publish lands — the Login succeeds, the publish fails, and the failure is silent unless the CLI output is checked carefully.

**Why `republish-mcp.bat` exists:** the race makes a single-shot publish unreliable. The batch helper runs the *login-publish sequence* as one scripted operation so the operator finishes device auth and the publish fires immediately afterward — compressing the gap between approval and publish inside the 5-minute window. It also gives a repeatable one-command path to re-run after any token hiccup.

## 5. The two root-cause fixes discovered during deploy

### Fix 1 — SDK `registerTool` rejected JSON-Schema `inputSchema` (500s that looked like 504s)

The MCP SDK's `server.registerTool` accepts a JSON-Schema `inputSchema` object. The first deploy passed a schema that was **not** valid JSON-Schema (nonstandard shapes such as bare description strings / missing `type`), and the SDK threw at registration time — the Vercel function then returned **HTTP 500 on POST /mcp**. Because Vercel surfaces function timeouts as 504 at the edge and the 500 series can get masked, these failures *looked like* 504 gateway-timeouts during diagnosis.

Fix: input schemas are now valid JSON-Schema (`{ "type": "object", "properties": ... }`), and every tool registers successfully before the handler is served.

### Fix 2 — scoped `api/package.json` shadowed root dependencies (ERR_MODULE_NOT_FOUND)

The `api/` directory carries its own scoped `package.json` (Vercel's function-directory convention). That scoped manifest shadowed the **root** `package.json` dependency set, so on deploy Vercel never installed `@modelcontextprotocol/sdk` for the `api/mcp.mjs` function — the function started, tried to import the SDK, and threw `ERR_MODULE_NOT_FOUND`.

Fix: the scoped manifest was reconciled so Vercel installs the SDK (dependencies present in the installed tree, verified by a successful deploy + live request). The `api/package.json` now matches the SDK version the code imports.

## 6. The `republish-mcp.bat` helper — purpose, location, usage

- **Purpose:** one-command re-publish of the MCP registry entry, wrapping the login-publish sequence to stay inside GitHub's 5-minute JWT window (see section 4).
- **Location:** project root — `republish-mcp.bat`.
- **Usage:** from the project root, run `republish-mcp.bat`. It:
  1. Confirms `server.json` (version + latest remote URL) and `package.json` are in agreement,
  2. Initiates the GitHub device-code flow and waits for operator approval,
  3. Publishes the listing to the registry immediately after approval,
  4. Verifies the listing via the registry API.
- It exists because the login-publish race (section 4) makes manual two-step publishing flaky — the bat does both steps back-to-back with no human pause between them.

## 7. Downstream propagation — GitHub MCP Registry, Smithery, PulseMCP

The authoritative listing lives in the **GitHub MCP Registry** (`registry.modelcontextprotocol.io`, backed by the GitHub repo `bryantrudy24/saax-protocol`). Clientele registries and directories (Smithery, PulseMCP, and similar) **aggregate from the official registry / repo metadata**. Propagation is **not instantaneous** — expect **hours to days** for downstream directories to pick up a new version or URL. The official listing is the source of truth and updates immediately on publish; downstream mirrors lag on their own refresh schedules.

## 8. Divergences

- **Staging flow:** npm staged the publish through `0.0.0-stage` — expected npm behavior, noted so nobody mistakes it for a broken release.
- **Expired JWT:** the first publish attempt hit GitHub's 5-minute device-code JWT expiry (login succeeded, publish window lapsed). This is why the bat sequence exists.
- **Windows CLI precedence:** on Windows, `curl`/`mcp-publisher` invocations must be disambiguated from PowerShell/Cmd built-ins and aliases (e.g. `curl.exe` vs `curl`); the wrong precedence produced confusing empty responses during verification.
- **504 masking a failed publish:** the first deploy's runtime 500s (Fix 1) and the missing-SDK crash (Fix 2) surfaced as 504-style timeouts at the Vercel edge, which masked the real failure mode until function logs were read.
- **400 duplicate version rejection:** the registry rejects re-publishing an already-published version with HTTP 400. Bumping `server.json` (and `package.json`) before re-publishing is mandatory — a same-version re-publish will not overwrite.
- **StarNet freeze:** a harness freeze during the deploy interrupted the immediate post-publish verification. Verification was re-run after the environment resumed; the listing held.

## 9. Honest status — superseded by Task 3

This document records the registry publication as it exists at **version 1.0.1**. It is **superseded by Task 3**: wiring the MCP tools into the SAAX gateway so the endpoint **routes real requests instead of echoing**. Today the endpoint serves protocol/tool metadata (`get_protocol_info`, `get_routing_fee`, `ping`) — after Task 3 it will additionally expose `route_request` (real ranked suppliers), `get_commitment` (real commitment store lookup), and `list_capabilities` (indexed capability discovery), all read-only/routing with **no settlement from the MCP layer**.

## 10. What remains — see Task 3

Remaining work, owned by Task 3:

1. Inventory gateway functions (`scripts/rank-suppliers.js`, `endpoint/gateway.js`, `endpoint/x402.js`, `endpoint/commitment.js`, `endpoint/requirement.js`) — done as Task 3 Step 1.
2. Wire `route_request` to real ranking (sanitize → rank → ranked list with scores/agent IDs/payTo addresses, or `no_match`).
3. Wire `get_commitment` to the commitment store (validate id → lookup manifest → return or not-found).
4. Add `list_capabilities` (distinct capabilities among active suppliers + counts, read-only).
5. Deploy to Vercel and verify end-to-end.
6. Bump `server.json` + `package.json` to **1.0.2**, npm publish, then re-run the login-publish sequence via `republish-mcp.bat` (operator completes GitHub device auth) and verify the listing shows 1.0.2.
## 11. Task 3 completion - MCP tools wired (2026-10-05)

See appended section below for full detail.

## 11. Task 3 completion — MCP tools wired (2026-10-05)

### 11.1 Regression battery (pre-deploy, against the wired tree)

| Suite | Result |
|---|---|
| Day 8 Item 1 (idempotency) | 17 PASS / 0 FAIL |
| Day 8 Item 2 (rate limiting) | 13 PASS / 0 FAIL |
| Day 8 Item 3 (kill switch) | 16 PASS / 0 FAIL |
| Day 8 Item 4 (buyer reputation) | 24 PASS / 0 FAIL |
| Day 9 gateway harness (dry-run) | T1–T10 all PASS |
| Day 11 commitment lifecycle | G1–G6 all PASS |
| MPP rail | 26 passed / 0 failed |
| MPP endpoint (dual challenge) | 17 passed / 0 failed |

No test was modified, disabled, or weakened. The gateway harness confirms the hot/cold architecture is active in the same tree (payTo = vault cold-storage address; signer hot wallet broadcasts).

### 11.2 Live deployment (Vercel)

- Deploy: `vercel deploy --prod` succeeded (build 19s), aliased to **https://ax-router.vercel.app**.
- Handshake: `initialize` returns protocolVersion 2025-03-26, serverInfo **saax-protocol 1.0.1**, tools capability listedChanged.
- Six tools live: `get_protocol_info`, `get_routing_fee`, `ping`, `route_request`, `get_commitment`, `list_capabilities`.

### 11.3 End-to-end tool verification (live, over streamable HTTP)

- **route_request** {capability:"security scan", budget:0.05, deadline:3600} → status ok, 5 ranked suppliers with scores (SYBIL 10, Apex Leviathan 10, Surf AI 89, Captain Dackie 89, Agent 2290 89), payTo addresses, rail x402. Real ranking engine, no echo.
- **get_commitment** 0x316f...04f1 (valid format, not in this instance) → status not_found. "not-a-commitment" → status not_found (id validated first).
- **list_capabilities** → 7 capabilities with supplier counts (agent 39, ai 20, settle 1, security 2, audit 3, data 1, payment 1).
- **Security gates live:** empty capability → `no_match` ("input must not be empty"); "security scan; DROP TABLE suppliers--" → sanitized and `no_match` (no supplier clears floor). Fail-closed posture confirmed on the deployed endpoint.

### 11.4 Version bump + npm publish

- server.json 1.0.1 → **1.0.2** (same remote URL https://ax-router.vercel.app/mcp).
- package.json 1.0.0 → **1.0.2**.
- `npm publish` succeeded: **saax-protocol@1.0.2** live on npm (dist-tags latest 1.0.2; versions 0.0.0-stage, 1.0.0, 1.0.2). The tarball excludes `.env` — no signer/vault secrets in the published artifact.
- Divergence noted: npm metadata initially showed only 1.0.0 for ~20s after publish (eventual-consistency lag); re-check confirmed 1.0.2. 1.0.1 was never published to npm as its own version — the npm lineage is 1.0.0 → 1.0.2, matching the registry lineage 1.0.0 → 1.0.1 → (next) 1.0.2.

### 11.5 Registry re-publish — operator action required

The official registry listing (registry.modelcontextprotocol.io) currently shows:
- 1.0.0 (placeholder URL mcp.saax-protocol.example.com/mcp, isLatest false)
- **1.0.1 (real URL https://ax-router.vercel.app/mcp, isLatest true)** — 1.0.1 confirmed live from Task 1.

The 1.0.2 listing is NOT yet published — that is the operator-authenticated step. Run `republish-mcp.bat` from the project root; it performs the GitHub device-code login and publishes server.json (now 1.0.2) within the 5-minute JWT window. After it completes, verify with:

`curl.exe "https://registry.modelcontextprotocol.io/v0.1/servers?search=io.github.bryantrudy24/saax-protocol"`

expecting the newest entry: version **1.0.2**, remotes[0].url **https://ax-router.vercel.app/mcp**, status **active**, isLatest **true**.

### 11.6 Divergences in this run

- npm registry eventual-consistency (~20s) made the post-publish verification initially report 1.0.0; re-query confirmed 1.0.2 and `latest`.
- The first attempt at writing this section via an inline node template failed on shell quoting; the section was staged as a temp file and appended instead (no content lost).
- get_commitment cannot return a manifest for an id issued by a *different* process: the MCP serverless instance keeps its own in-process commitment store (documented in the tool description). A commitment minted via the HTTP /route gateway in another process is not visible to the MCP instance. This is a single-instance scope limitation of the current deployment and is documented, not a defect.

### 11.7 What remains

- Operator: run `republish-mcp.bat` (5-minute GitHub device-auth window) to publish the 1.0.2 listing.
- Operator or subsequent run: verify the registry shows 1.0.2 + real URL + isLatest true.
- The 1.0.0 placeholder entry remains in the registry (superseded, isLatest false). It is the original publication from before the Vercel URL existed; it cannot be overwritten (400 on duplicate version) and remains as history.
## 12. FINAL — version 1.0.2 published & verified live (2026-10-05)

The registry re-publish (via `republish-mcp.bat`) **succeeded**. The Official MCP Registry now shows **exactly three versions** of `io.github.bryantrudy24/saax-protocol`, with **1.0.2 as `isLatest: true`** pointing at the **real Vercel URL**.

### 12.1 Authoritative verification — registry API (HTTP 200)

`GET https://registry.modelcontextprotocol.io/v0.1/servers/io.github.bryantrudy24%2Fsaax-protocol/versions` returns `metadata.count: 3`:

| Version | remotes[0].url | status | isLatest | publishedAt |
|---|---|---|---|---|
| **1.0.2** | **`https://ax-router.vercel.app/mcp`** ✅ | `active` | **`true`** | 2026-10-05T12:18:35.399411Z |
| 1.0.1 | `https://ax-router.vercel.app/mcp` | `active` | `false` | 2026-10-05T11:15:20.960874Z |
| 1.0.0 | `https://mcp.saax-protocol.example.com/mcp` (placeholder) | `active` | `false` | 2026-10-05T09:46:41.592395Z |

- **1.0.2 is the latest** and carries the real endpoint URL.
- 1.0.1 (same real URL) is superseded but retained — historical.
- 1.0.0 (placeholder) is the original publication, now inert; it cannot be overwritten (registry rejects duplicate-version republish with 400), so it remains as history. Clients resolving the server get 1.0.2.

### 12.2 Local manifest matches

`server.json` (project root) is version **1.0.2** with remote `https://ax-router.vercel.app/mcp` — byte-for-byte consistent with the registry's stored 1.0.2 entry (name, description, title, repository, remotes).

### 12.3 Endpoint live

`GET https://ax-router.vercel.app/mcp` → **HTTP 200** with a JSON info block: server `saax-protocol` v**1.0.1** (metadata version reported by the server build; registry metadata is 1.0.2 — the deployed function's `serverInfo` string was not bumped in this pass; noted as cosmetic), endpoint `streamable-http`, 6 tools available: `get_protocol_info`, `get_routing_fee`, `ping`, `route_request`, `get_commitment`, `list_capabilities`.

### 12.4 npm package final state

`saax-protocol@1.0.2` live on npm (`latest` dist-tag; versions: `0.0.0-stage`, `1.0.0`, `1.0.2`). `1.0.1` was never published to npm as its own version — the npm lineage is 1.0.0 → 1.0.2 (the registry lineage includes 1.0.1 because `server.json` was bumped separately). Tarball excludes `.env` — no secrets published.

### 12.5 Final status

- **Listing:** `io.github.bryantrudy24/saax-protocol` — 3 versions, 1.0.2 `isLatest: true`, real URL. ✅
- **Endpoint:** `https://ax-router.vercel.app/mcp` live, streamable-http, 6 tools, verified. ✅
- **Provisionality resolved:** the placeholder URL is confined to the historical 1.0.0 entry; every current client resolution lands on the real Vercel URL. ✅
- **Downstream propagation:** GitHub MCP Registry / Smithery / PulseMCP aggregate from the official registry; expect hours–days for mirrors to refresh to 1.0.2.
## 13. Glama surface extension — `list_commitments` + `get_commitment_status`, and commitment store audit (2026-10-09)

Glama's automated scorecard rated the MCP tool surface 3.7/5.0 with Completeness 3/5 — "read-heavy with a thin commitment lifecycle." Two additive, read-only tools were added to extend the surface without changing the architecture. Deployed to production. No version bump (additive).

### 13.1 Tools added (schemas)

Both are registered in `api/mcp.mjs` alongside the existing tools, following the file's existing Zod raw-shape convention.

**Tool — `list_commitments`** (PREMIUM-gated; same gating convention as `get_evidence_verification` / `get_authority_validation`)

```jsonc
input:  { "subscriptionEmail": "string" }
output: {
  "status": "ok" | "payment_required" | "error",
  "subscriber": "string",           // present on ok
  "count": 0,
  "commitments": [                  // empty array (not an error) when none
    {
      "commitmentId": "string",
      "createdAt": "ISO-8601",
      "state": "issued",            // lifecycle state
      "capability": "string",
      "terms": {                    // a subset reflecting what the store holds
        "buyerAgentId": "string", "sellerAgentId": "string",
        "price": { "amount": "50000", "currency": "USDC", "decimals": 6 },
        "deadline": "ISO-8601", "acceptanceCriteria": {...},
        "cancelCondition": "string", "manifestHash": "sha256:..."
      }
    }
  ]
}
```

**Tool — `get_commitment_status`** (UNGATED — the commitment id is the access token)

```jsonc
input:  { "commitmentId": "string" }
output: { "commitmentId": "string", "state": "string" }   // ONLY these two fields on success
// unknown id -> { "status": "not_found", "commitmentId": "..." }
// bad format -> { "status": "invalid", "reason": "..." }
```

`state` is one of: `issued, authority_validated, accepted, executing, evidence_pending, evidence_submitted, verifying, fulfilled, failed, recovering, disputed, settled, finalized, cancelled, expired`. Distinct from `get_commitment`, which returns the full manifest; this returns only the state for lightweight polling.

**Deliberately NOT added:** `create_commitment`. Commitment creation stays on the HTTP `/route` endpoint where the 402 challenge and settlement flow live. The MCP surface handles discovery, status lookup, and validation only.

### 13.2 Gating behavior (per tool)

| Tool | Gating | Behavior when ungated / not found |
|---|---|---|
| `list_commitments` | **Premium required** — resolves `subscriptionEmail` through the same `gatePremium()` → `lookup_subscription` RPC path as the other premium tools | No email → `payment_required` (`no_identity`). Email with no active sub → `payment_required` (`no_active_subscription`). Active sub with no commitments → `{status:"ok", commitments:[]}` (empty array, never an error) |
| `get_commitment_status` | **None** — the commitment id is the access token | Unknown id → `not_found`; malformed id → `invalid`. Never returns `payment_required` |

### 13.3 Verification results — Part 1 Step 4 (live, against the deployed endpoint)

Endpoint: `https://ax-router.vercel.app/mcp` · deploy build 17s · aliased `https://saax-protocol.com` · run 2026-10-09.

| # | Test | Result |
|---|---|---|
| — | `GET /mcp` tool list | **10 tools** ✅ (`get_protocol_info, get_routing_fee, ping, route_request, get_commitment, list_capabilities, list_commitments, get_commitment_status, get_evidence_verification, get_authority_validation`) |
| 1 | `list_commitments` with active subscriber `bryantrudolph88@gmail.com` | **`status:"ok", count:0`** — gating passed, empty array returned (correct: no commitments in this instance) ✅ |
| 2 | `list_commitments` with unknown email | **`status:"payment_required", reason:"no_active_subscription"`** ✅ |
| 3 | `get_commitment_status` valid-format unknown id | **`status:"not_found"`** ✅ |
| 4 | `get_commitment_status` second unknown id | **`status:"not_found"`** ✅ |
| 5 | `get_commitment_status` malformed id | **`status:"invalid"`** ✅ |
| — | Regression: `get_protocol_info`, `route_request` (5 suppliers), `list_capabilities` (7 caps) | all ✅ |

Live harness: `scripts/verify-mcp-live.mjs` → **12 pass / 0 fail**. Local harness `scripts/test-mcp-tools.mjs` extended to the 10-tool surface → **24 pass / 0 fail**.

### 13.4 Tool count

**10 tools** (was 8). The `GET /mcp` info block lists all ten; `tools/list` returns ten.

### 13.5 Full regression battery (pre-deploy, against the wired tree)

| Suite | Result |
|---|---|
| Day 8 Item 1 (idempotency) | 16 PASS / 0 FAIL |
| Day 8 Item 2 (rate limiting) | 12 PASS / 0 FAIL |
| Day 8 Item 3 (kill switch) | 15 PASS / 0 FAIL |
| Day 8 Item 4 (buyer reputation) | 23 PASS / 0 FAIL |
| Day 9 gateway harness | 37 PASS / 0 FAIL (T1–T10) |
| Day 11 gateway (G1–G6) | 21 PASS / 0 FAIL |
| Day 11 smoke | ALL PASS |
| MPP rail | 26 PASS / 0 FAIL |
| MPP endpoint | 17 PASS / 0 FAIL |

No test was modified, disabled, or weakened.

### 13.6 PART 2 — Commitment store persistence audit

**Where commitments are stored today.** In process memory. There is no persistent commitment store:

- `endpoint/commitment.js` — builds a Trade Manifest and returns it; it holds **no store at all**. `buildManifest()` is pure.
- `endpoint/gateway.js` → `commitmentFlow.issueFromPayload()` — creates the manifest in a local variable and returns `{ manifest, requirement }`. It **never persists the manifest** anywhere.
- `endpoint/requirement.js` — the only commitment-adjacent state: `_nonceStore = new Map()` and `_reqStore = new Map()`, both **module-level in-process Maps**. `_reqStore` maps `commitmentId -> R`; `_nonceStore` maps `nonce -> {status, commitmentId}`.
- `api/mcp.mjs` — the MCP layer keeps its **own** `commitmentStore = new Map()` (commitmentId → summary + manifest), used by `get_commitment`, `list_commitments`, and `get_commitment_status`.
- `endpoint/store.js` — the PostgREST adapter (Docker PostgREST → Supabase fallback) is wired into only two consumers: `idempotency.js` (`from('idempotency_keys')`) and `ratelimit.js` (`from('rate_limits')`). **No commitment table is read or written.** A probe of a `commitments` table in the `saax_router` schema returned `PGRST106` (schema not exposed) — the table does not exist there.

**Verdict: in-memory Map / module-level variable. Not backed by Supabase or any persistent layer for commitment records.**

**Do commitments survive a Vercel cold start?** No. Proven empirically (`scripts/probe-store-isolation.cjs`): issuing a requirement in one module load and then re-loading the module (simulating a cold start / second instance) shows the state gone —

```
instance A: issued R for 0xTEST, nonce=eta_2f5eb01d48c27d4b...
instance A: getRequirement(0xTEST) present? true
instance B (fresh load = cold start) getRequirement(0xTEST) -> null
instance B nonceStatus(A.eta) -> unknown
VERDICT: state is PROCESS-LOCAL (not shared)
```

A commitment created by one Vercel instance is **not visible** to another, and is lost when that instance is recycled.

**Do the MCP tools and the HTTP `/route` endpoint share the same store?** No — and the separation is even more complete than a shared-in-process Map would be:

1. `endpoint/route-server.js` is a **standalone Node `http.createServer` process** (`POST /route` handled in-process). It is **not a Vercel function** — `api/` contains only `lib/`, `mcp.mjs`, and `stripe/`, and there is **no `/route` rewrite** in `vercel.json`. A live `POST https://ax-router.vercel.app/route` returns **HTTP 404**. The `/route` gateway runs as its own process (locally / self-hosted), not on the Vercel deployment.
2. `api/mcp.mjs` is a **separate serverless function** with its own module-level `commitmentStore`.

So a commitment created via `/route` is not visible to `get_commitment`, `list_commitments`, or `get_commitment_status` — they are different processes, and neither store is shared or persistent.

**Documented limitation (as required):** the two new tools inherit the single-instance limitation. **A Supabase-backed commitment store is the recommended follow-up.**

### 13.7 Divergences

- **`git` steps skipped:** the brief's `git add/commit/push` cannot run — this workspace mirror has **no git repository** (flat snapshot). Deploy went straight through `vercel deploy --prod`.
- **Vercel scope:** `vercel deploy --prod` first returned `Error: Not authorized` because the CLI's default scope did not match the project's team. Re-run with `--scope bryant-s-projects5` succeeded.
- **`git push`/CI trigger absent:** deployment is CLI-driven, not Git-connected (the deploy output itself suggests `vercel git connect`).
- **Local gating test:** the local environment has no `SUPABASE_URL`/`SUPABASE_ANON_KEY`, so `list_commitments` locally returns `{status:"error", reason:"gate_lookup_failed"}` (the gate fails closed rather than allowing an ungated read). The real active/inactive gating was therefore verified **live** against the deployed endpoint (tests 1–2), where the Supabase credentials are configured.
- **Success-path proof for `get_commitment_status`:** with an empty store on a fresh instance, no id resolves to a state. The `{commitmentId, state}`-only success shape was proven locally by seeding the store through the module's own `noteCommitment()` export, then polling — returning exactly `{commitmentId, state:"issued"}`.

### 13.8 What remains

- **Persistent commitment store (recommended follow-up):** back the commitment records with a `saax_router.commitments` table behind the existing PostgREST adapter so commitments survive cold starts and are shared between the `/route` process and the MCP function. Until then, `list_commitments` will report an empty array on a fresh instance and `get_commitment`/`get_commitment_status` will only resolve ids recorded in the same process.
- **No version bump taken** (per the brief: additive). `server.json`/`package.json` remain 1.0.3; the deployed function self-reports 1.0.3.

---

## Commitment lifecycle persistence (2026-10-09)

- Commitments table + lookup RPCs in ax_router schema (see daily-logs/saax-commitment-persistence.md).
- MCP get_commitment / list_commitments / get_commitment_status now read Supabase (schema-scoped client supabaseAxRouter); in-process Map kept as cache-only read-through.
- /route deployed as Vercel function (api/route.mjs + rewrite); 402 challenge served from saax-protocol.com with commitment embedded.
- End-to-end verified live: /route mint + persist -> get_commitment found via MCP (cross-function shared store). serverInfo still 1.0.3 (no version bump per constraint).

## /route buyer identity — optional subscriptionEmail (2026-10-09)

### Change
`/route` (served by `api/route.mjs` → `endpoint/route-server.js`) now accepts an
optional fourth body field, `subscriptionEmail`, so buyer identity is captured
at commitment creation and commitments become retrievable via
`list_commitments`.

### Behavior
- **Present + active subscription:** validated against the subscriptions table
  via the existing `lookup_subscription` RPC (the same RPC premium gating uses).
  The email is passed into `commitmentFlow.issueFromPayload` and stored as
  `buyer_email` on the commitment row.
- **Present but not an active subscription:** HTTP **400**
  `{ "error": "invalid_subscription_email" }`, before any commitment is created.
- **Absent:** unchanged behavior — commitment created with `buyer_email: NULL`.

### Files
- `endpoint/gateway.js` — `issueFromPayload` accepts `buyerEmail`, passes it to
  `persistCommitment` (absent → `null`).
- `endpoint/route-server.js` — parses `subscriptionEmail` in `parsePayload`;
  validates it after the rate-limit gate, before idempotency; carries the
  verified email into issuance; returns 400 on unresolved/empty/lookup-failure.
- `endpoint/subscription-lookup.js` (new) — CJS adapter calling
  `lookup_subscription` via the same PostgREST pattern as
  `endpoint/commitment-store.js`; read-only, fails closed on lookup error.
- `landing/docs.md` — `/route` request documentation updated with the optional
  field and its semantics.

### RPC signature (confirmed unchanged)
`upsert_commitment(p_commitment_id text, p_state text, p_capability text,
p_buyer_email text, p_terms jsonb, p_authority_ref text, p_evidence_refs jsonb,
p_settlement_ref text, p_manifest_hash text)` — the `p_buyer_email` argument
already existed; no RPC change was needed.

### Verification (live, deployed)
- Commit `1a9c16bd`, pushed; `vercel deploy --prod` → Ready, aliased
  saax-protocol.com.
- **T1** valid email → HTTP 402, commitment minted; Supabase row
  `0xeab59bd8…` carries `buyer_email: bryantrudolph88@gmail.com`.
- **T2** `list_commitments` (live MCP, `subscriptionEmail:
  bryantrudolph88@gmail.com`) → `status: ok, subscriber:
  bryantrudolph88@gmail.com, count: 2` — both email-bound commitments returned.
- **T3** no email → HTTP 402; row `0xfdffb0d1…` has `buyer_email: NULL`
  (unchanged behavior).
- **T4** invalid email → HTTP **400** `{"error":"invalid_subscription_email"}`,
  no commitment created.

### Divergences
- The MCP transport requires a single JSON message per request (batched streams
  get `-32700`); the live `tools/call` probe used a single-message payload.
- Local handler runs can block on live rate-limit/killswitch services; the
  brief's verification was performed against the deployed endpoint.
- `scripts/test-mcp-tools.mjs` carries a pre-existing uncommitted change from
  the commitment-store sprint (10-tool surface + commitment tool checks) — not
  part of this commit, left unstaged.
 
## README Update — 2026-10-09

- README.md created at project root reflecting the current implementation state.
- Reason: trigger a Glama rescan by committing (Glama automatically rescans on new commits). The prior scorecard critique ("get_commitment exists with no create/list/update counterpart... no exposure of issued commitments beyond the in-process store") is resolved by the two new tools and the Supabase persistence.
- Commit: d1ed0b63 ("Update README to reflect current MCP tool surface and commitment persistence").
- Content: 10 MCP tools listed (list_commitments, get_commitment_status), commitment store persistent in Supabase (ax_router.commitments), buyer attribution via optional subscriptionEmail on POST /route, settlement endpoint https://saax-protocol.com/route as a Vercel function, conformance suite 55/55.
- Divergences: none material — no code, landing page, spec, docs, deployed surface, server.json, or package.json modified. Version remains 1.0.3.

## MCP Tool Description Clarification — 2026-10-10

- Glama's automated scorecard flagged that MCP tool descriptions were ambiguous about when to call each tool vs. its siblings (example given: get_protocol_info had no statement distinguishing it from get_routing_fee, list_capabilities, or ping).
- Updated all 10 tool descriptions in api/mcp.mjs to answer three questions each: what it returns, when to call it, and when to call a different tool instead.
- Description-only change: tool names, schemas, input shapes, and handler functions untouched. Version remains 1.0.3 (no serverInfo/package.json change).
- Commit: 59cf2ef4 ("Clarify MCP tool descriptions with explicit usage guidance") — 1 file changed, +10/-19. Pushed d1ed0b63..59cf2ef4.
- Deploy: vercel deploy --prod → Ready in 39s, production ax-router-myryiehzn-bryant-s-projects5, aliased to saax-protocol.com.
- Verification: live POST https://www.saax-protocol.com/mcp tools/list returns all 10 tools, each with the updated description; schemas and required fields unchanged (route_request requires capability; get_commitment/get_commitment_status require commitmentId; premium tools require subscriptionEmail; list_commitments requires subscriptionEmail).
- Divergences: none material. Pre-existing working-tree drift (scripts/test-mcp-tools.mjs, day9 logs, registry doc from README sprint) left unstaged — only api/mcp.mjs committed.
