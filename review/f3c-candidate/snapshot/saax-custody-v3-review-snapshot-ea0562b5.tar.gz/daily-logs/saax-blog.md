# SAAX Blog — Sprint Log (2026-10-08)

## Objective
Create the blog section on the SAAX landing page and publish the first post. The blog is the canonical home for content mapping to the search intent of developers who have the problem SAAX solves.

## Changes

### Blog route and index
- Created `landing/blog/index.md` — SAAX Protocol — Essays index (250 bytes)
- Title: SAAX Protocol — Essays; tagline on agentic commerce, commitment lifecycles, autonomous transaction infrastructure
- Posts list: How to Handle Agentic Commerce Disputes — 2026-10-08

### First post
- Created `landing/blog/how-to-handle-agentic-commerce-disputes.md` (1,954 bytes)
- Full expansion in the byline: **SAAX Protocol — Solvent Applied Autonomous Exchange Protocol**
- Dated October 8, 2026
- Core argument: the commitment record (not a resolution mechanism) is what makes agentic commerce disputes decidable
- Lifecycle states: COMMITTED → EXECUTING → FAILED → RECOVERY → DISPUTE → RESOLVED → FINAL
- Links to /spec and /conformance

### Vercel rewrites (vercel.json)
Appended two rewrites, preserving all 20 existing:
```json
{ "source": "/blog", "destination": "/landing/blog/index.md" }
{ "source": "/blog/:slug", "destination": "/landing/blog/:slug.md" }
```
22 total now.

### Nav and footer (landing/index.html)
- Nav: Blog link added after Docs (`<a href="/blog">Blog</a>` at line 196)
- Footer: Blog link added after Commitment Lifecycle Spec (`<a href="/blog">Blog</a>` at line 408)

### Sitemap (landing/sitemap.xml)
Added, preserving all 5 existing entries (now 7):
```xml
<url><loc>https://saax-protocol.com/blog</loc></url>
<url><loc>https://saax-protocol.com/blog/how-to-handle-agentic-commerce-disputes</loc></url>
```

### llms.txt (landing/llms.txt)
Added Essays section below Core Documentation:
```
## Essays
- [How to Handle Agentic Commerce Disputes](https://saax-protocol.com/blog/how-to-handle-agentic-commerce-disputes): The commitment record problem in agent-initiated purchases
```

## Verification results (fresh fetches, post-deploy)

| URL | Status | Content-Type |
|---|---|---|
| https://saax-protocol.com/blog | 200 | text/markdown; charset=utf-8 |
| https://saax-protocol.com/blog/how-to-handle-agentic-commerce-disputes | 200 | text/markdown; charset=utf-8 |
| https://saax-protocol.com | 200 | text/html; charset=utf-8 |
| https://saax-protocol.com/sitemap.xml | 200 | application/xml |
| https://saax-protocol.com/llms.txt | 200 | text/plain; charset=utf-8 |

First 200 bytes of the post response:
```
# How to Handle Agentic Commerce Disputes

**SAAX Protocol — Solvent Applied Autonomous Exchange Protocol**
```
Nav/footer Blog links confirmed in the live landing HTML (2 matches for /blog).
llms.txt Essays section and post link confirmed live.

## Deploys
- Commit `f750e3d4` — "Add blog section and publish first post on agentic commerce disputes" (6 files, +47) — pushed to origin/main
- `vercel deploy --prod` — Ready in 20s, aliased to https://saax-protocol.com (deployment ax-router-2h1zi6ijt-bryant-s-projects5)

## Divergences
- None. All existing rewrites preserved (22 total), all sitemap entries preserved (7 total), no existing page content modified. Blog files written via Python (UTF-8-safe) to preserve em-dashes and arrow glyphs.
## Rendering Fix + Second Post (2026-10-08)

### Rendering issue — diagnosed
The blog index and posts were served as raw Markdown. Fresh headers captured:
- `/blog` → `Content-Type: text/markdown; charset=utf-8`, body began `# SAAX Protocol - Essays` (literal # heading syntax)
- `/blog/how-to-handle-agentic-commerce-disputes` → `text/markdown; charset=utf-8`, raw markdown body
- `/spec` → ALSO `text/markdown; charset=utf-8` — the "renders correctly" premise did not hold at the HTTP layer; all .md routes on the site share the same serving pattern

vercel.json rewrites at the time: `/blog` → `/landing/blog/index.md`, `/blog/:slug` → `/landing/blog/:slug.md`. A Content-Type header alone cannot convert `#` syntax to rendered headings in a browser, so the fix (brief Option A) was pre-rendered `.html` pages with real `<h1>/<h2>` markup, with the blog rewrites pointed at them.

### Fix applied
- Created `landing/blog/index.html` — pre-rendered blog index: real `<h1>SAAX Protocol — Essays</h1>`, `<h2>Posts</h2>`, both posts listed with dates, site nav/footer (brand, dark GitHub-style theme from the landing page's CSS tokens)
- Created `landing/blog/how-to-handle-agentic-commerce-disputes.html` — pre-rendered first post (content generated verbatim from the existing .md via a mini markdown→HTML renderer; the .md itself untouched byte-for-byte)
- Created `landing/blog/agent-execution-liability-who-pays-when-an-agent-buys-wrong.html` — pre-rendered second post
- vercel.json: `/blog` → `/landing/blog/index.html`, `/blog/:slug` → `/landing/blog/:slug.html` (all 20 other rewrites preserved byte-for-byte, JSON validated)

### Second post published
- `landing/blog/agent-execution-liability-who-pays-when-an-agent-buys-wrong.md` (3,554 bytes) — verbatim per brief: liability allocation problem, card-network two-party model break, stablecoin rail irreversibility, commitment-as-record answer, links to /spec and /conformance
- `landing/blog/index.md` updated to list both posts (397 bytes)
- sitemap.xml: added the second post URL (8 entries now, all prior preserved)
- llms.txt: Essays section now lists both posts

### Verification results (fresh fetches, post-deploy)
| URL | Status | Content-Type |
|---|---|---|
| https://saax-protocol.com/blog | 200 | **text/html; charset=utf-8** |
| https://saax-protocol.com/blog/how-to-handle-agentic-commerce-disputes | 200 | **text/html; charset=utf-8** |
| https://saax-protocol.com/blog/agent-execution-liability-who-pays-when-an-agent-buys-wrong | 200 | **text/html; charset=utf-8** |
| https://saax-protocol.com/sitemap.xml | 200 | application/xml (all 3 blog URLs listed) |
| https://saax-protocol.com/llms.txt | 200 | text/plain (Essays lists both posts) |

Rendered body checks (findstr on live HTML):
- Index: `<h1>SAAX Protocol — Essays</h1>`, `<h2>Posts</h2>`, both post links with `— 2026-10-08` dates
- Post 1: `<h1>How to Handle Agentic Commerce Disputes</h1>`, state string rendered as `<p class="states"><strong>COMMITTED → EXECUTING → FAILED → RECOVERY → DISPUTE → RESOLVED → FINAL</strong></p>`, /spec and /conformance links live
- Post 2: `<h1>Agent Execution Liability: Who Pays When an Agent Buys Wrong</h1>`, "liability allocation problem" and "decidable" passages, /spec and /conformance links
- No literal `#` heading syntax anywhere in the served blog HTML

MCP endpoint: 200 with `serverInfo: saax-protocol 1.0.3` (spec-compliant initialize; requires Accept: application/json, text/event-stream — standard MCP streamable-HTTP). Settlement health: 200. Landing page: 200, unchanged (pricing section, nav Blog link, footer Blog link all present).

### Deploy
- Commit `b82f2f9d` — "Fix blog rendering; publish second post on agent execution liability" (8 files, +259/−2) — pushed to origin/main
- `vercel deploy --prod` — Ready in 24s, aliased to https://saax-protocol.com (deployment ax-router-eqipf3wzj-bryant-s-projects5)

### Divergences
- The brief's premise that /spec "renders correctly" while /blog doesn't was not true at the HTTP layer — both serve text/markdown. Since the constraints forbid modifying /spec and friends, the fix was applied to the blog routes only (pre-rendered HTML + rewrites). /spec, /docs, /terms etc. remain text/markdown (browser-dependent rendering, as before).
- One probe initially returned 406 on /mcp — root cause was a missing `Accept: application/json, text/event-stream` header on my curl probe (standard MCP requirement), not a regression. With the header, 200 + serverInfo confirmed.

## Protocol/Spec/Docs Rendering Fix — 2026-10-08

### The three rewrites updated
Changed in vercel.json — protocol/spec/docs destinations pointed at pre-rendered HTML files:
- `/protocol` -> `/landing/protocol.html`
- `/spec` -> `/landing/spec.html`
- `/docs` -> `/landing/docs.html`

All other rewrites preserved byte-for-byte (22 total). JSON validated.

### Live verification results (fresh fetches, all 200)
| URL | Content-Type | First bytes |
|---|---|---|
| /blog/preventing-autonomous-agent-double-purchasing | text/html | <!DOCTYPE html> <title>Preventing Autonomous Agent Double-Purchasing</title> |
| /blog | text/html | <!DOCTYPE html> <title>SAAX Protocol - Essays</title> (all three posts listed) |
| /protocol | text/html | <!DOCTYPE html> <title>SAAX Protocol - The Standard</title> |
| /spec | text/html | <!DOCTYPE html> <title>SAAX Protocol - Commitment Lifecycle Specification</title> |
| /docs | text/html | <!DOCTYPE html> <title>SAAX Protocol - Integration Guide</title> |
| /sitemap.xml | application/xml | <?xml ... urlset (all four blog URLs) |
| /llms.txt | text/plain | # SAAX Protocol ... (Essays: all three posts) |

- Blog index confirms all three posts: How to Handle Agentic Commerce Disputes, Agent Execution Liability, Preventing Autonomous Agent Double-Purchasing.
- Sitemap includes all four blog URLs; llms.txt lists all three posts.
- No literal # renders as visible text on /protocol, /spec, or /docs (no raw-hash / escaped-hash in any served HTML).
- Dark theme confirmed on all three: `:root{--bg:#0d1117;--fg:#e6edf3;--muted:#9aa7b4;--accent:#2f81f7;--border:#2d333b;}` — GitHub-dark black background, near-white text. H2/H3/code blocks render as formatted HTML.

### Semantic preservation confirmation
ALL_CONTENT_PRESERVED for all three pages (word-coverage vs .md sources):
- protocol: 97.3%
- spec: 99.2%
- docs: 98.9%
Content unchanged — only the rendering.

### Verification artifacts (strip-tool, NOT page defects)
1. Ordered-list numbering in the spec headings ("1. Scope", etc.) — the strip tool splits "1." -> "1" in the diff; the rendered HTML carries the numbers inside the heading text. Confirmed non-defect.
2. cose/jws inline-code slash spacing (e.g., `cose/jws`) — the strip tool removes or splits the `/` in inline code; the rendered page shows the code correctly. Confirmed non-defect.

### Divergences
None material. Deploy: commit 10f61ea3 (vercel.json, 3 rewrites), pushed; vercel deploy --prod Ready in 24s, aliased to saax-protocol.com.
## Sixth Post: What Does an Agent Actually Commit To? — 2026-10-10

- .md source: landing/blog/what-does-an-agent-actually-commit-to.md (5183 B)
- Pre-rendered HTML: landing/blog/what-does-an-agent-actually-commit-to.html (9552 B)
- Blog index: landing/blog/index.md + index.html — new entry added (date 2026-10-10)
- Sitemap: https://saax-protocol.com/blog/what-does-an-agent-actually-commit-to added
- /llms.txt: essay entry added to the Essays section

Verification (fresh fetches):
- https://saax-protocol.com/blog/what-does-an-agent-actually-commit-to → 200 text/html; h1 renders "What Does an Agent Actually Commit To?"; no literal # visible
- https://saax-protocol.com/blog → 200 text/html; lists all four posts
- https://saax-protocol.com/sitemap.xml → 200 application/xml; new URL present, prior entries preserved
- https://saax-protocol.com/llms.txt → 200 text/plain; new essay entry present

Deploy: commit 81fa6607; vercel deploy --prod → Ready in 29s, aliased to https://saax-protocol.com

Divergences:
- The brief anticipated 5 prior posts; the blog physically contains 3 prior posts (2026-10-08). This is the 4th physical entry. Index, sitemap, and llms.txt updated to match the real existing set.
- fs_write lands in the sandbox (workspaces\agent\landing\...), not the project dir; files were copied into ax-router\landing\blog and sandbox copies deleted.
- Blog index.html had a pre-existing minor formatting quirk (one sitemap line missing indentation predates this sprint) — untouched.
- The post HTML includes code/pre styling (from the index template) to render inline and block code per the brief.

# Sixth Post Publication (2026-10-10) - Audit Trail + Payment Authorization

## Reconciliation context
The blog reconciliation audit confirmed two posts were approved for publication but never written to disk: "The Audit Trail Problem in Agentic Commerce" and "Why Payment Authorization != Fulfillment in Agentic Commerce". This sprint published both.

## Files created
- landing/blog/the-audit-trail-problem-in-agentic-commerce.md (7 K9s)
- landing/blog/the-audit-trail-problem-in-agentic-commerce.html (12 KBs)
- landing/blog/why-payment-authorization-does-not-equal-fulfillment.md (6 K ) Commerce".

- landing/blog/why-payment-authorization-does-not-equal-fulfillment.html (10 K Bs)

## Registry updates
- landing/blog/index.md + index.html: all six posts now listed
- landing/sitemap.xml: both new URLs added, prior entries preserved
- landing/llms.txt: both essays added to the Essays section

## Verification (all live, fresh fetches)
- /blog/the-audit-trail-problem-in-agentic-commerce - 200 text/html, h1 renders, no literal # leak
- /blog/why-payment-authorization-does-not-equal-fulfillment - 200 text/html
- /blog - lists all six posts
- /sitemap.xml - both new URLs present
- /llms.txt - both essays present in Essays section

GI# Commit & deploy
- Commit 632efec0 (8 files, +447/-7), pushed 37ed012b..632efec0
- vercel deploy --prod: Ready in 45s, aliased to saax-protocol.com

## Divergences
- llms.txt entries initially appended to file tail; corrected into the Essays section
- Pre-existing dirty files (day9 logs, _NOTE.b64, saax-append.b64) excluded from commit

## FAQ Post — Agentic Commerce Disputes: The Complete FAQ (2026-10-10)

### Published
- **Post:** [Agentic Commerce Disputes: The Complete FAQ](/blog/agentic-commerce-disputes-complete-faq)
- **Source:** `landing/blog/agentic-commerce-disputes-complete-faq.md` (14,791 bytes) — published verbatim from the brief
- **HTML:** `landing/blog/agentic-commerce-disputes-complete-faq.html` (20,533 bytes) — exact existing post template (dark GitHub palette, same nav/footer, h1/h2/ul/ol/code rendering, byline + date + hr)
- **Date:** October 10, 2026

### Pipeline updates
- **Blog index:** `landing/blog/index.md` + `index.html` — seventh entry added (seven posts total), same styling
- **Sitemap:** `landing/sitemap.xml` — new URL added, all 12 prior entries preserved (13 total)
- **/llms.txt:** Essays section — new entry added (7 essay lines total), all prior entries preserved

### OG / Twitter tags (added to the post head)
- `og:title` Agentic Commerce Disputes: The Complete FAQ — SAAX Protocol
- `og:description` Answers to the nine most common questions about disputes in AI agent commerce.
- `og:url` https://saax-protocol.com/blog/agentic-commerce-disputes-complete-faq
- `og:type` article · `og:site_name` SAAX Protocol
- `twitter:card` summary_large_image · `twitter:title` · `twitter:description`
- Plus `canonical` and `meta description` matching the other posts

### Verification (fresh fetches after deploy, 2026-10-10)
| URL | Status | Content-Type | Notes |
|---|---|---|---|
| /blog/agentic-commerce-disputes-complete-faq | 200 | text/html; charset=utf-8 | **9 H2 headings** (exactly the nine PAA questions), H1 correct, **5 OG + 3 Twitter tags**, canonical present, **zero literal `#` in text** |
| /blog | 200 | text/html; charset=utf-8 | **Seven posts listed** (new entry present) |
| /sitemap.xml | 200 | application/xml | **13 URLs** (new entry present) |
| /llms.txt | 200 | text/plain; charset=utf-8 | **7 essay lines** (new entry present) |

### Deploy
- Commit `ef6ad367` — "Publish FAQ post: Agentic Commerce Disputes" (6 files, +349)
- Push `f7c58a3b..ef6ad367 main -> main`
- `vercel deploy --prod` — Ready in 59s, aliased to saax-protocol.com

### Divergences
- None material. One inline PowerShell quoting issue during verification (cmd `&` splitting a node -e script) — routed around with a file-based check script, deleted after use.
- LF→CRLF warnings on commit (cosmetic, consistent with prior commits).

## Post 8 — How to Actually Make Money with AI Agents (And Why Most People Don't) — 2026-10-10

### Published
- **Slug:** `/blog/how-to-make-money-with-ai-agents`
- **Files:** `landing/blog/how-to-make-money-with-ai-agents.md` (verbatim source), `landing/blog/how-to-make-money-with-ai-agents.html` (pre-rendered, template-matched to the FAQ post)
- **Commit:** `3e54b1e7` — pushed to `main`
- **Deploy:** `vercel deploy --prod` — Ready in 22s, aliased to `saax-protocol.com`

### OG / Twitter tags added
- `og:title` "How to Actually Make Money with AI Agents (And Why Most People Don't) — SAAX Protocol"
- `og:description` "The advice is everywhere. The revenue isn't. What separates agents that sell from agents that sit idle — and the trust layer that closes the gap."
- `og:url`, `og:type=article`, `og:site_name`, `twitter:card=summary_large_image`, `twitter:title`, `twitter:description` — all present and verified in served HTML.

### Index / sitemap / llms.txt updates
- `landing/blog/index.md` — 8th entry added (2026-10-10)
- `landing/blog/index.html` — 8th `<li>` added, same styling
- `landing/sitemap.xml` — post URL added (14 URLs total)
- `landing/llms.txt` — 8th Essays entry added

### Verification results (fresh fetches, all live)
| URL | Status | Content-Type |
|---|---|---|
| /blog/how-to-make-money-with-ai-agents | **200** | text/html |
| /blog | **200** | text/html |
| /sitemap.xml | **200** | application/xml |
| /llms.txt | **200** | text/plain |

- Post HTML verified: OG tags present, canonical present, 5 H2 headings, **no literal # rendered as text**
- **Served HTML == committed file byte-identical** (10,474 B both, MATCH=True)

### Divergences
- Python `-c` one-liner output is silently swallowed by this cmd wrapper (multi-line `-c` scripts and file-based scripts work). Routed around with temp `.py` files, deleted after use.
- fs tools resolve to the sandbox, not the project dir (known) — project writes done via shell copy from sandbox, byte-verified.
- LF→CRLF warnings on commit (cosmetic, consistent with prior commits).


## Post 9 — What Is Agentic Commerce? The Complete Guide (2026-10-11)

- Slug: /blog/what-is-agentic-commerce
- Source: landing/blog/what-is-agentic-commerce.md (4,540 B) — verbatim from brief
- Pre-rendered: landing/blog/what-is-agentic-commerce.html (9,574 B) — exact template shell (dark GitHub palette, nav, footer, CSS), H1 + 4 H2, byline, post-date, hr
- OG/Twitter: og:title, og:description, og:url, og:type=article, og:site_name, twitter:card=summary_large_image, twitter:title, twitter:description, canonical — all present in served HTML
- Index: index.md + index.html — ninth entry (2026-10-11), same styling
- Sitemap: https://saax-protocol.com/blog/what-is-agentic-commerce added (15 URLs total, all 14 prior preserved)
- llms.txt: Essays entry appended after the money-with-agents line
- Commit: 95d83032 ("Publish ninth post: What Is Agentic Commerce? The Complete Guide", 6 files +153), pushed c1ca4e68..95d83032
- Deploy: vercel deploy --prod → Ready 43s, aliased to saax-protocol.com (production ax-router-p11g4p5cg)
- Verification (fresh fetches):
  - /blog/what-is-agentic-commerce → 200 text/html 9,574 B (== committed file), OG tags present, H2_COUNT=4, LITERAL_HASH=False
  - /blog → 200 text/html 5,678 B, 9 posts listed including the 9th
  - /sitemap.xml → 200 application/xml 1,314 B, new URL present, count 15
  - /llms.txt → 200 text/plain 3,931 B, essay present
- Divergences: python -c multi-line output swallowed by cmd wrapper (file-based scripts used instead); fs_write sandbox path (script run from sandbox with absolute project ROOT); PowerShell display renders em-dash as ?" but files are correct UTF-8
## Tenth Post + /welcome Dark Theme Fix — 2026-10-11

### Published: Agentic Commerce Protocols Explained: AP2, x402, ACP, and UCP
- Slug: /blog/agentic-commerce-protocols-explained (target keyword: "agentic commerce protocol")
- .md source: landing/blog/agentic-commerce-protocols-explained.md (4,022 B, verbatim from brief)
- Pre-rendered HTML: landing/blog/agentic-commerce-protocols-explained.html (9,077 B)
  - Dark GitHub palette (--bg:#0d1117 / --fg:#e6edf3), same nav/footer as all posts
  - 6 H2 headings, H1, OG tags (og:title/description/url/type/site_name), Twitter tags (card/title/description), canonical
  - No literal # visible as text (verified HASH False)
- Blog index: index.md + index.html updated — 10 entries (entry: 2026-10-11)
- Sitemap: 16 URLs, new URL added, all prior preserved, well-formed
- /llms.txt: 10th Essays entry added

### /welcome dark theme — FIXED (was serving raw Markdown)
- Root cause: vercel.json rewrite pointed /welcome at /landing/welcome.md — served raw Markdown with light browser view
- Fix: created landing/welcome.html (7,129 B) from welcome.md via the blog template shell
  - Dark theme (--bg:#0d1117, --fg:#e6edf3), nav/footer match site
  - H1 "Welcome to SAAX Premium", 6 H2 sections, trial sentence present
  - MCP endpoint code block, subscriptionEmail JSON example, customer portal link, support contact
  - No literal # as text
- vercel.json: /welcome destination changed to /landing/welcome.html (all 25 rewrites preserved, JSON valid)

### Deploy
- Commit 4fe42d15 (8 files, +284): post md+html, welcome.html, index.md/html, sitemap.xml, llms.txt, vercel.json
- Pushed d21c2604..4fe42d15 main
- vercel deploy --prod: Ready in 24s, aliased to saax-protocol.com

### Verification (all five URLs)
| URL | Status | Content-Type |
|---|---|---|
| /blog/agentic-commerce-protocols-explained | 200 | text/html (formatted post, OG tags present) |
| /blog | 200 | text/html (10 posts) |
| /sitemap.xml | 200 | application/xml (16 URLs) |
| /llms.txt | 200 | text/plain (10 essays) |
| /welcome | 200 | text/html (dark theme, formatted) |

### Divergences
- fs tools resolve to the workspace sandbox (known) — file writes via shell copy into the real repo, byte-verified
- Python -c stdout swallowed by the cmd wrapper — file-based scripts used (deleted after use)
- Prior sprint's claim that /welcome was "already dark-themed" was incorrect — the welcome.html file did not exist on disk and the rewrite pointed at welcome.md; corrected and proven this sprint (live fetched HTML, no markdown syntax)
- Vercel CLI first deploy attempt returned "Not authorized" (transient) — retry succeeded
## Blog Index Category Restructure - 2026-10-11

Restructured landing/blog/index.md and index.html from a flat chronological list into four topic categories plus Uncategorized (five <h2> sections).

Category assignments: Disputes (2): How to Handle Agentic Commerce Disputes 2026-10-08, Agentic Commerce Disputes: The Complete FAQ 2026-10-10. Liability (3): Agent Execution Liability 2026-10-08, Preventing Double-Purchasing 2026-10-08, Audit Trail Problem 2026-10-08. Protocols (3): What Does an Agent Actually Commit To? 2026-10-10, Why Payment Authorization != Fulfillment 2026-10-08, Agentic Commerce Protocols Explained 2026-10-11. Making Money with Agents (1): How to Actually Make Money with AI Agents 2026-10-10. Uncategorized (1): What Is Agentic Commerce? The Complete Guide 2026-10-11 (not in the brief's assignments - reported per rule rather than forced).

Category navigation row added: Disputes . Liability . Protocols . Making Money (anchor links). Blog JSON-LD added (Blog type, publisher SAAX Protocol).

Verification: /blog 200 text/html; five <h2> categories; ten posts under correct categories; nav row renders; JSON-LD valid (@type=Blog); no literal # renders as text (12 total #: 8 CSS hex + 4 nav anchors).

Divergences: What Is Agentic Commerce? unassigned -> Uncategorized; no OG tags on index (only JSON-LD requested for this page); LF-to-CRLF warnings (cosmetic).
- Moved �What Is Agentic Commerce? The Complete Guide� from Uncategorized to Protocols (first entry); removed empty Uncategorized heading. Commit 823e08b0.
