# SAAX Protocol — Commitment Lifecycle Specification

Date: 2026-10-06. Additive specification update to the governed commitment
lifecycle (Day 11). Three extensions: Evidence/Attestation Abstraction (Item 1),
Authority-Proof Interface (Item 2), and Settlement-Rail Neutrality documentation
(Item 3). No removal of existing functionality; routing and ranking layers
unchanged.

---

## 1. Governing Model

The commitment lifecycle is the Cedulon Trade Manifest (governed commitment):

```
governed commitment -> verified outcome -> recovery -> audit
```

The manifest binds the TERMS (capability, price, acceptance criteria, deadline,
cancel condition) BEFORE value moves. It carries no rail, no credential, no
settlement reference — settlement is resolved at execution time (R/S
separation, IETF draft-king-yew-choo-agentic-payments).

The manifest is issued before value moves. A spend bound to a manifest MUST be
denied if the requested amount or currency differs (checkSpendBinding).

---

## 2. Evidence / Attestation Abstraction (Item 1)

### 2.1 Principle

SAAX does not trust the buyer or seller to declare fulfillment. Evidence comes
from EXTERNAL sources with independent verification — temperature sensors,
delivery trackers, reputation oracles, inspectors. SAAX validates evidence
(structure, signature, provenance, binding) and evaluates it against the
commitment's acceptance-criterion verification policies. **SAAX never produces
the evidence.**

### 2.2 Evidence record schema

```json
{
  "evidenceId": "0x...",
  "evidenceType": "temperature-reading",
  "issuer": "0x...",
  "subject": "0x...",
  "issuanceTimestamp": "2026-10-06T...",
  "contextReference": "0x...",
  "payload": { ... },
  "payloadHash": "sha256:...",
  "provenance": { ... },
  "signature": "COSE_Sign1...",
  "verificationScheme": "eip712|cose|jws",
  "verificationMaterial": "0x...",
  "commitmentId": "0x...",
  "acceptanceCriterionId": "0x..."
}
```

Every field is validated; only recognized fields are kept. The payloadHash is
SHA-256 of the canonical JSON encoding of the payload — any payload tampering
changes the hash and fails validation.

### 2.3 Verification-policy model

The commitment specifies a verification policy per acceptance criterion:

```json
{
  "criterionId": "0x...",
  "criterionDescription": "delivery temperature <= 5C",
  "requiredEvidenceType": "temperature-reading",
  "acceptedIssuers": ["0x..."],
  "verificationScheme": "cose",
  "evaluationLogic": "payload.temperature <= 5",
  "maxEvidenceAge": 3600,
  "minimumEvidenceCount": 1
}
```

Policies are provider-neutral: `acceptedIssuers` is an optional allowlist,
`evaluationLogic` is a tiny SAFE evaluator (numeric comparison only — no
`eval()`), `verificationScheme` selects the signature scheme
(eip712 | cose | jws).

### 2.4 Evaluation function — `endpoint/evidence.js`

- `validateEvidence(evidence, commitment)` — checks structure, signature,
  provenance, binding to commitment and criterion. Returns `{ ok, reason, stage }`.
  A hash-vs-payload mismatch (tampering) fails at `payload-hash`.
- `evaluateCriterion(criterion, evidence[])` — applies the verification policy
  (type, allowlist, freshness, evaluation logic, minimum count) and returns
  `satisfied | not_satisfied | insufficient_evidence`.
- `recordOutcome(commitmentId, criterionId, outcome, evidenceRefs[])` — writes
  the result to the commitment record (`commitment.evidenceOutcomes[criterionId]`),
  with an in-process store adapter (persistOutcome/getOutcome/listOutcomes).

### 2.5 Evidence lifecycle wiring

```
committee issued
  ->
acceptance criteria defined with verification policies
  ->
external evidence submitted (from any source)
  ->
SAAX validates evidence (structure, signature, provenance, binding)
  ->
SAAX evaluates against criterion
  ->
outcome recorded: satisfied | not_satisfied | insufficient_evidence
  ->
commitment reaches finality or enters recovery
```

Wiring seam: `gateway.commitmentFlow.issueFromPayloadWithEvidence(...)` accepts
an optional `evidenceList`; each criterion's policy is evaluated against it at
issuance. The signature scheme `eip712` is verified cryptographically via viem
`signTypedData`/`verifyTypedData` over the EIP-712 domain `{ name: 'SAAX
Evidence', version: '1' }`; `cose`/`jws` envelopes are validated structurally
(Phase-1 posture consistent with the manifest's COSE_Sign1 emulation) with a
pluggable verifier hook for later-phase token verification.

### 2.6 Test harness — `scripts/test-evidence.js` (9 assertions)

1. Valid evidence from an approved issuer with a valid signature binds to a commitment and satisfies its criterion
2. Evidence with a bad signature fails validation
3. Evidence bound to the wrong commitment fails binding
4. Evidence older than maxEvidenceAge fails the freshness check
5. Evidence with minEvidenceCount unmet returns insufficient_evidence
6. Evidence with an unapproved issuer fails when the allowlist is present
7. Payload tampering (hash mismatch) fails validation
Plus integrity checks on recordOutcome/evaluateLogic.

---

## 3. Authority-Proof Interface (Item 2)

### 3.1 Principle

The commitment previously assumed the buyer's signature is sufficient
authorization. This extension references an EXTERNAL authority proof — AP2
mandates, verifiable intents, OAuth tokens, or custom schemes. **SAAX does not
issue authority proofs; it consumes them** from external systems and
re-evaluates them at execution time.

### 3.2 AuthorityProof structure

```json
{
  "authorityProofId": "0x...",
  "proofType": "ap2-mandate|verifiable-intent|oauth-token|custom",
  "issuer": "0x...",
  "subject": "0x...",
  "scope": { ... },
  "validFrom": "2026-10-06T...",
  "validUntil": "2026-10-07T...",
  "signature": "COSE_Sign1...",
  "verificationScheme": "cose|jws|eip712",
  "verificationMaterial": "0x..."
}
```

Scope model: `actions[]` (requestedAction must be in this list), optional
`capability`, optional `amountMax` (raw units), optional `currency`. An ABSENT
scope dimension is unrestricted; a PRESENT dimension must be satisfied by the
commitment.

### 3.3 Validation function — `endpoint/authority.js`

- `validateAuthorityProof(proof, commitment)` — checks structure, signature,
  scope, and TIME validity. Returns `{ ok, reason, stage }`.
- `isAuthorized(proof, requestedAction, commitmentContext)` — verifies the
  proof covers the specific action the commitment represents (combines
  integrity + time + scope).
- `scopeCovers(proof, action, context)` — pure scope check.
- `attachAuthorityProof(commitment, proof)` — attaches the proof REFERENCE to
  the commitment at issuance (authorityProofId, proofType, issuer, subject,
  scope, validUntil, scheme, material). **Non-leakage: the full proof and its
  signature are never stored on the commitment** — only the verifiable
  reference; the proof material lives at the external issuer.

EIP-712 domain for proofs: `{ name: 'SAAX Authority', version: '1' }`; signature
verified cryptographically via viem `verifyTypedData` (cose/jws validated
structurally, same Phase-1 posture).

### 3.4 Authority lifecycle wiring

```
authority proof presented (external source)
  ->
SAAX validates proof (structure, signature, scope, time)
  ->
commitment issued, referencing the authority proof
  ->
proof evaluated at execution time (still valid? still in scope?)
  ->
commitment validly authorized or rejected
```

Wiring seam: `issueFromPayloadWithEvidence(..., authorityProof)` validates and
attaches the proof at issuance. The commitment record carries
`authorityProofId`; execution-time re-evaluation uses `isAuthorized`.

**Backward compatibility:** a commitment without any authority proof follows
the legacy path (buyer signature only) — unchanged and fully operational.

### 3.5 Test harness — `scripts/test-authority.js` (10 assertions)

1. Valid authority proof allows the commitment to be issued
2. Expired proof rejects the commitment
3. Proof with insufficient scope rejects the commitment (action + amount)
4. Proof with bad signature rejects the commitment
5. Commitment without a proof follows the legacy path (buyer signature only)

---

## 4. Settlement-Rail Neutrality (Item 3)

**SAAX does not prescribe a settlement rail.**

- The commitment issues a settlement **requirement (R)** that is rail-agnostic:
  `R = <amt, cur, payee, eta, scheme, t_exp>` — no rail knowledge at
  commitment time.
- The **rail (S)** is resolved at execution time from the registered registry
  (`endpoint/rails/index.js`): `register(method, impl)` / `resolve(method)` /
  `list()`.
- Currently registered rails: **x402**, **MPP**.
- Future rails: entitlement, card, ACH, internal ledger — any implementation of
  the `realise/validate/settle` interface can register as a SAAX settlement
  rail. Registration is the operator's explicit opt-in for a live rail.

### 4.1 Rail interface (documented)

```
interface SettlementRail {
  realise(R): Credential            // turn a neutral requirement into a credential
  validate(Credential, R): boolean  // is this credential valid FOR R?
  settle(Credential): TransactionReference  // move value; return PUBLIC tx ref
}
```

Any system that implements this interface can register as a SAAX settlement
rail:

```js
const registry = require('./endpoint/rails');
registry.register('stripe', { realise, validate, settle });
const rail = registry.resolve('stripe');
```

The rail knows nothing about the commitment's content; it only knows how to
realise R. Rail credentials never appear in receipts, logs, or tool results —
only the public `railReference` (credential non-leakage).

---

## 5. Constraints honored

- Additive only: no ranking engine, demand intake, MCP registry, or existing
  functionality removed.
- No routing-layer changes: evidence and authority abstractions are additions
  to the commitment lifecycle, not replacements.
- No external integrations: API3, AP2 and similar are referenced as PATTERNS,
  not integrated; the abstractions are provider-neutral (eip712|cose|jws
  schemes; any issuer).
- All existing tests must still pass (verified: new harnesses green, existing
  suites re-run).

## 6. Divergences

1. **COSE_Sign1 / JWS verification is structural Phase-1 emulation** (consistent
   with the manifest's existing emulated COSE envelope): `eip712` is verified
   cryptographically; `cose`/`jws` validate envelope format with an optional
   verifier hook for real token verification later.
2. **Evidence store is in-process** (single server instance, mirrors
   requirement.js): `persistOutcome/getOutcome/listOutcomes`. A shared store
   (Supabase) is a later-phase durability item.
3. **viem 2.57 API surface**: `signTypedData` lives in `viem/accounts` and
   `verifyTypedData` in top-level `viem`; both are async (Promise-returning)
   in this version. The modules import accordingly.
4. The spec doc lives at `daily-logs/saax-commitment-lifecycle.md` (per the
   brief); the historical Day 11 log `daily-logs/day11-commitment-lifecycle.md`
   is untouched.