# SAAX Stripe Products — Configuration Log

Date: 2026-10-06
Status: Phase 1 complete (product + prices); Phase 2 recorded below when landed

## Phase 1 — SAAX Premium Product and Prices (Stripe)

### Product

| Field | Value |
|---|---|
| Product ID | `prod_VOb34vZPo8Otvx` |
| Name | SAAX Premium |
| Type | service |
| Tax code | `txcd_10103001` (Software as a Service (SaaS) - Business Use) |
| Livemode | true |
| Description | The approved checkout description (SAAX Protocol — Premium Subscription; verified outcomes, dispute resolution, audit access; what's included list; closing paragraph). Stored verbatim. |

### Prices (both attached to prod_VOb34vZPo8Otvx)

| Tier | Price ID | Amount | Currency | Billing | Tax behavior |
|---|---|---|---|---|---|
| Developer | `price_1UNns6PHXel7gDrW22mrBV5K` | 2900 ($29.00) | USD | Monthly (recurring, interval_count 1) | exclusive |
| Business | `price_1UNns6PHXel7gDrWlK12GKiz` | 19900 ($199.00) | USD | Monthly (recurring, interval_count 1) | exclusive |

Verified via list-prices read-back: exactly two prices on the product; both `active: true`, `type: recurring`, `billing_scheme: per_unit`.

### Enterprise tier

Deliberately NOT created as a Stripe Price. Enterprise is custom-priced and handled via invoice (operator decision). List-prices read-back confirms no third price exists.

### Stripe MCP connection method

Connected via the StarNet Stripe MCP connector using a restricted API key (agent-flagged account). No secret values printed or stored in this log. Account: acct_1TvLN8PHXel7gDrW (NextGen intel).

### Divergences

- None in configuration. `default_price` on the product was not set (the landing page links each tier to its own Payment Link; a product default price is not required and was intentionally omitted).
- Do not enable Stripe Tax or create webhooks/subscriptions — explicitly deferred to a later sprint (operator constraint).## Phase 1.5 — Payment Links (created after Phase 1, before landing-page wiring)

### Developer Payment Link

| Field | Value |
|---|---|
| Payment Link ID | `plink_1UNoEIPHXel7gDrW8Pr8dqVz` |
| Price | `price_1UNns6PHXel7gDrW22mrBV5K` (Developer, $29.00/mo) |
| Submit type | subscribe |
| **URL** | **https://buy.stripe.com/3cIdRb2w24Gagrn6c8bII02** |

### Business Payment Link

| Field | Value |
|---|---|
| Payment Link ID | `plink_1UNoENPHXel7gDrWZnzSZzur` |
| Price | `price_1UNns6PHXel7gDrWlK12GKiz` (Business, $199.00/mo) |
| Submit type | subscribe |
| **URL** | **https://buy.stripe.com/14A14p9Yu5Ke8YVfMIbII03** |

Both created via `POST /v1/payment_links` with `line_items:[{price, quantity:1}]`, `submit_type:"subscribe"`, no `after_completion` override (default hosted confirmation). Both `active: true`, livemode.

### Verification (browser, Stripe-hosted checkout)

| Check | Developer link | Business link |
|---|---|---|
| HTTP status | 200 | 200 |
| Product shown | "Subscribe to SAAX Premium" | "Subscribe to SAAX Premium" |
| Price shown | **$29.00 per month** | **$199.00 per month** |
| Billing period | monthly ($29.00 / month) | monthly ($199.00 / month) |
| Description | Full approved checkout description rendered | Full approved checkout description rendered |
| Checkout renders | Contact info + Card fields (Visa/MC/Amex/Discover/JCB/Diners/UnionPay, Cash App, Klarna, Bank) | Contact info + Card + Link + Phone/country fields |
| Payment mode | Live (test data not accepted) | Live (test data not accepted) |

### Divergences

- **Merchant header shows "iGen digital marketplace"** on both checkout pages — the connected Stripe account is the operator's iGen account; the SAAX Premium product, price, and description render correctly beneath it. Cosmetic; a branded-checkout/statement-descriptor styling item if the operator wants the header to read "SAAX" (deferred — not part of Phase 1/2 scope, no webhooks or subscription flows were configured).
- No Stripe subscriptions were created for any customer (Payment Links only, as constrained).
- No secrets printed.

### Status

Phase 1 (product + prices) and the Payment Links are complete and verified. **Paused before Phase 2** (landing page pricing section wiring) awaiting operator confirmation.
## Fresh Verification Pass (2026-10-07)

### Arrow escape defect — fixed
- Defect: literal `\u2192` escape sequences rendered on the landing page buttons (introduced by PowerShell single-quoted strings during the pricing-section edit).
- Fix: 13 arrow glyphs corrected to real `→` characters across the pricing section buttons (`Subscribe →` x2, `Contact us →`, plus nav/hero arrows).

### Commit & deploy
- Commit `52700c08` — arrow glyph fix (pushed to main).
- Deploy: `vercel deploy --prod` — success, aliased to `https://saax-protocol.com`.

### Verification checks (fresh fetches, 2026-10-07)
1. **Landing page** https://saax-protocol.com — HTTP 200, text/html, pricing section (SAAX Premium: Developer $29/month, Business $199/month, Enterprise Custom pricing) present; buttons render with real arrow glyphs: `Subscribe →`, `Subscribe →`, `Contact us →` (no `\u2192` literals anywhere); nav `Pricing` link present (href #pricing); Developer/Business Subscribe hrefs = https://buy.stripe.com/8x2fZg1GR96BcC11keawo00 and https://buy.stripe.com/cNifZg85f6Yt6dD2oiawo01; Enterprise Contact us href = mailto:support@saax-protocol.com. PASS
2. **Developer Payment Link** https://buy.stripe.com/8x2fZg1GR96BcC11keawo00 — merchant `Saax-protocol`, product `Subscribe to SAAX Premium`, $29.00 per month, billed monthly, Live mode. PASS
3. **Business Payment Link** https://buy.stripe.com/cNifZg85f6Yt6dD2oiawo01 — merchant `Saax-protocol`, product `Subscribe to SAAX Premium`, $199.00 per month, billed monthly, Live mode. PASS
4. **MCP endpoint** https://www.saax-protocol.com/mcp — POST initialize → HTTP 200, `{"serverInfo":{"name":"saax-protocol","version":"1.0.3"},"capabilities":{"tools":{"listChanged":true}},"protocolVersion":"2025-03-26"}`. PASS (handshake requires full params; omitted params produce a validation error response — that is the endpoint validating, not failing)
5. **Settlement endpoint** https://settlement.saax-protocol.com/health — HTTP 200, `{"ok":true,"mode":"self","x402Mode":"self","killSwitch":false,"rails":["x402","mpp"],...}`. PASS

### Divergences
- MCP initialize rejects a bare `{"jsonrpc":"2.0","method":"initialize","id":1}` with a JSON-RPC -32603 validation error (expected params.protocolVersion/capabilities/clientInfo); a spec-compliant handshake succeeds. Documented, not a defect.
- Checkout merchant header renders as `Saax-protocol` (Stripe account display name). Verified as the intended account per the Phase 1 migration.
