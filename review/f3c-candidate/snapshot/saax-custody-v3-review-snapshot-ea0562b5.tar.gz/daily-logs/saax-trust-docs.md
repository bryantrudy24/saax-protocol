# SAAX Trust & Safety Documents

*Sprint log — 2026-10-06*

## Scope

Published the public trust-and-safety document set for SAAX: security posture, privacy/retention policy, and the dispute channel. All four artifacts are live on the production domain.

## Documents created

### `landing/security.md` — Security
Public threat model and vulnerability-reporting process.

- **Scope:** commitment integrity, settlement correctness, reputation integrity, availability of the routing layer.
- **Threat model (generic):** duplicate charges (idempotency), gas abuse/DoS (rate limiting), nonce replay (nonce-bound idempotency), spoofed buyer reputation (signature-derived reputation), signature forgery (EIP-712 verification, proxy-aware scanning), prompt injection (sanitization gate), supply-side fraud (capability floor + reputation weighting), credential leakage (non-custodial design, non-leakage architecture).
- **Mitigations in place:** table of deployed controls without exposing Router internals.
- **Residual risks:** smart-contract risk, key compromise, censorship/liveness, RPC dependency, reputation gaming, social engineering.
- **Out of scope:** user key compromise, off-protocol counterparty fraud, market/legal consequences, attacks on Base/USDC/RPC infrastructure, user error.
- **Reporting:** security@reachsaaxprotocol@gmail.com; ack within 5 business days, triage within 10, coordinated disclosure up to 90 days. No production testing beyond necessity.

### `landing/privacy.md` — Privacy
Actual-practice privacy and retention policy.

- **Collected:** commitment records, wallet addresses, IPs (rate limiting), timestamps, evidence references.
- **Public:** on-chain records (commitments, settlements, reputation feedback) — permanent and public.
- **Private:** Router working memory (in-memory), rate-limit counters, session data, unsettled state, unrecorded evidence payloads.
- **Retention:** in-memory state = life of process (lost on restart); rate-limit/IP = transient; on-chain = permanent; logs = per provider. **No deletion SLA claimed.**
- **Third-party processors:** Vercel (site/MCP), Railway (routing service + env), Base RPC providers (on-chain reads/writes), Namecheap (domain).
- **User rights:** access/correction/deletion requests via email; best-effort; proof of wallet control required; on-chain records cannot be deleted.
- **What cannot be deleted:** on-chain records immutable.

### `landing/disputes.md` — Disputes
Dispute and complaint channel.

- **When to use:** commitment misbehavior, incorrect/duplicate charge, service misbehavior, name misuse, privacy concerns. Explicitly NOT for off-protocol quality disputes, market losses, or immutable-record reversals.
- **How to file:** email with commitment ID, issue description, evidence, wallet address(es), contact.
- **Response:** best-effort — ack ≤5 business days, initial response ≤10; no SLA claimed.
- **Resolution process:** acknowledge → triage → investigate (on-chain + provider records) → findings → outcome (correction of private records / explanation / good-faith accommodation only where operator fault; on-chain records never reversed) → closure.
- **Escalation:** reply-to-thread escalation, re-file with evidence, external-entity routing (USDC/Base/host). No formal appeals body beyond operators; arbitration only if parties agreed.
- **What SAAX can/cannot do:** recovery-states standardized, no guarantee of reimbursement/reversal/resolution.

### `landing/.well-known/security.txt`
Verbatim per brief; served as `text/plain`.

## Contact address

All three documents use **reachsaaxprotocol@gmail.com** as the security/privacy/disputes contact (mailto in security.txt).

**TEMPORARY — flagged in all three docs and in this log:** this address should migrate to saax-protocol.com addresses (security@, privacy@, disputes@) once domain email is configured. `security.txt` Canonical/Policy URLs already point at saax-protocol.com paths.

## Vercel rewrites added (`vercel.json`)

```json
{ "source": "/security", "destination": "/landing/security.md" }
{ "source": "/privacy", "destination": "/landing/privacy.md" }
{ "source": "/disputes", "destination": "/landing/disputes.md" }
{ "source": "/.well-known/security.txt", "destination": "/landing/.well-known/security.txt" }
```

All existing routes preserved byte-identical (verified). JSON validity checked with `node -e JSON.parse`.

## Landing-page footer

Second `.links` row added to `landing/index.html`:

```html
<div class="links">
  <a href="/security">Security</a>
  <a href="/privacy">Privacy</a>
  <a href="/disputes">Disputes</a>
</div>
```

## Deployment

- Commit `13fe427d` — "Add trust and safety docs: security, privacy, disputes; wire rewrites and footer" (6 files, +277)
- Pushed to `main` (`c21ab391..13fe427d`)
- `vercel deploy --prod --yes` → Ready in 21s, aliased to `saax-protocol.com`

## Verified URLs (live)

| URL | Result |
|---|---|
| https://saax-protocol.com/security | **200**, 6921 bytes |
| https://saax-protocol.com/privacy | **200**, 5410 bytes |
| https://saax-protocol.com/disputes | **200**, 5326 bytes |
| https://saax-protocol.com/.well-known/security.txt | **200**, `Content-Type: text/plain; charset=utf-8`, content matches brief verbatim |
| https://saax-protocol.com/ | **200**, 19566 bytes (footer links present) |
| https://www.saax-protocol.com/mcp | **200**, MCP initialize handshake OK (`serverInfo: saax-protocol 1.0.2`) — unchanged |

## Test suites (all pass)

- Conformance: **55 passed, 0 failed**
- Evidence: **9 passed, 0 failed**
- Authority: **10 passed, 0 failed**

## Divergences

1. **MCP serverInfo reports 1.0.2** while registry metadata is 1.0.3 — pre-existing cosmetic drift (endpoint code not in scope for this sprint; flagged for a future version-string bump).
2. **fs tools resolve to a sandbox**, not the project dir — all project-file writes routed through the `ax-router/` path prefix; read-back verified each file (sha256 receipts).
3. LF→CRLF warnings on commit (Git autocrlf) — cosmetic, no functional impact.
4. The `landing/.well-known/` directory did not exist; created in this sprint (Vercel serves it at `/.well-known/security.txt` without config beyond the rewrite).

## Standing notes

- Recovery disclosure repeated in `disputes.md` and `security.md` (residual risks) per the existing "What SAAX Does Not Guarantee" positioning.
- No Router internals exposed anywhere; no credential-leak references; no uptime/reliability claims; no deletion SLA or response-time guarantee claimed.
## Contact address migration (2026-10-06)
- The temporary Gmail contact (reachsaaxprotocol@gmail.com) has been replaced with branded domain addresses now that email forwarding is live on saax-protocol.com.
  - landing/security.md → security@saax-protocol.com (temporary note removed)
  - landing/privacy.md → privacy@saax-protocol.com (temporary note removed)
  - landing/disputes.md → disputes@saax-protocol.com (all 3 contact rows; temporary note removed)
  - landing/.well-known/security.txt → Contact: mailto:security@saax-protocol.com
- Commit 96567df4 pushed; vercel deploy --prod aliased to saax-protocol.com (Ready 15s).
- Verified live: /security, /privacy, /disputes show branded addresses; .well-known/security.txt shows mailto:security@saax-protocol.com.
- No Gmail or temporary-contact references remain in any of the four files.