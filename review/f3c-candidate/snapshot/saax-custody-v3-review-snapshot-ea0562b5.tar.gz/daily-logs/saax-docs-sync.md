# SAAX Docs Sync — 2026-10-09

## Purpose

Bring all public documentation surfaces in line with the current implementation state:
- Commitments persist to Supabase (`ax_router.commitments`), surviving cold starts and shared across functions
- `/route` accepts optional `subscriptionEmail`, storing buyer attribution on the commitment row
- The MCP endpoint exposes **10 tools** (up from 8): `list_commitments` and `get_commitment_status` added
- The settlement endpoint is deployed as a Vercel function at `saax-protocol.com/route`

## Pages updated (10 files, commit `b99c2b9b`)

### /docs — `landing/docs.md` + `landing/docs.html`
- Replaced the vague "Available tools include…" line with the explicit **MCP tools (10)** list
- Added bullet descriptions for `list_commitments` (requires active subscription) and `get_commitment_status` (no subscription required)
- Noted `/route` is served from `saax-protocol.com/route` as a deployed Vercel function
- (The `subscriptionEmail` field was already documented on /docs from the earlier buyer-identity sprint — confirmed present, includes the 400 `invalid_subscription_email` behavior)

### /conformance — `landing/conformance.md`
- Added the **MCP Tool Surface** section listing all 10 tools with the exact names

### /spec — `landing/spec.md` + `landing/spec.html`
- Added one paragraph to "Relationship to External Systems": the reference implementation persists commitments to a durable store (Supabase), attributes them by buyer identity where provided, and exposes them via HTTP and MCP; the spec itself requires no specific persistence layer or identity mechanism
- No schema, lifecycle state, or error-code content modified

### /protocol — `landing/protocol.md` + `landing/protocol.html`
- Added the same reference-implementation note under "Reference Implementation" (the page does mention the Router as the reference implementation, so the note applies per the brief's conditional)

### /welcome — `landing/welcome.md`
- Added "As a SAAX Premium subscriber, you can call:" list with all four tools: `get_evidence_verification`, `get_authority_validation`, `list_commitments`, `get_commitment_status`

### Landing page — `landing/index.html`
- Checked: the landing page does **not** display an MCP tool count or tool list — left unchanged per Item 6

### /llms.txt — `landing/llms.txt`
- Added the Tools line to the MCP Integration section: all 10 tools

### /llms-full.txt — `landing/llms-full.txt`
- Regenerated from source: `spec/*.md` (7 files) + `protocol.md` + `docs.md` + `security.md` + `privacy.md` + `terms.md`, same six-section structure

## Verification (live fetches, post-deploy)

| URL | Status | Content check |
|---|---|---|
| /docs | 200 | "MCP tools (10)" ✅ + list_commitments ✅ |
| /conformance | 200 | "MCP Tool Surface" ✅ |
| /spec | 200 | "durable store" ✅ |
| /protocol | 200 | "durable store" ✅ |
| /welcome | 200 | "list_commitments" ✅ |
| /llms.txt | 200 | "get_commitment_status" ✅ |
| /llms-full.txt | 200 | 10-tools ✅ · durable store ✅ |
| / (landing) | 200 | unchanged (no tool count existed) ✅ |

## Deployment

- Commit `b99c2b9b` ("Sync documentation to current state: commitment persistence, buyer attribution, 10 MCP tools") — 10 files, +55/−10
- Pushed: `cf0a6b62..b99c2b9b main -> main`
- `vercel deploy --prod` — Ready in 27s, aliased to `https://saax-protocol.com`

## Divergences

1. **fs_patch writes to a sandbox, not the project** — edits were applied via a generated Python script in the project directory instead; verified via `git diff` (the real files) before commit.
2. **llms-full.txt doesn't include conformance.md** by design — its structure is Spec / Protocol Overview / Integration Guide / Security / Privacy / Terms; the 10-tool surface flows through the regenerated docs.md block. The brief's Item 8 structure is preserved exactly.
3. No other divergences; no schema/lifecycle/error-code content touched; trust documents, hero, pricing, and blog untouched; no code changes.