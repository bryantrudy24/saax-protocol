// one-off patch: internal references to ACTIVE chain/asset in gateway.js
const fs = require('fs');
const p = 'endpoint/gateway.js';
let c = fs.readFileSync(p, 'utf8');

// 1) settleAuthorization dual-path probe -> ACTIVE chain/asset
const a = 'getSignaturePath({ asset: USDC_BASE_SEPOLIA, chainId: BASE_SEPOLIA_CHAIN_ID })';
const b = 'getSignaturePath({ asset: USDC_BASE_SEPOLIA, chainId: ACTIVE_CHAIN_ID })';
let n = c.split(a).length - 1;
c = c.split(a).join(b);
console.log('settle getSignaturePath replacements:', n);

// 2) parseChainId fallback
const d = 'return m ? Number(m[1]) : BASE_SEPOLIA_CHAIN_ID;';
const e = 'return m ? Number(m[1]) : ACTIVE_CHAIN_ID;';
n = c.split(d).length - 1;
c = c.split(d).join(e);
console.log('parseChainId fallback replacements:', n);

// 3) domainFor default chainId
const f = 'chainId: chainId || BASE_SEPOLIA_CHAIN_ID,';
const g = 'chainId: chainId || ACTIVE_CHAIN_ID,';
n = c.split(f).length - 1;
c = c.split(f).join(g);
console.log('domainFor chainId replacements:', n);

fs.writeFileSync(p, c);
console.log('patched; new length', c.length);
console.log('ACTIVE_CHAIN_ID occurrences now:', (c.match(/ACTIVE_CHAIN_ID/g) || []).length);