// one-off: mpp.js local chain constants -> gateway active values
const fs = require('fs');
const p = 'endpoint/rails/mpp.js';
let c = fs.readFileSync(p, 'utf8');

const old = `const USDC_BASE_SEPOLIA = '0x036CbD53842c5426634e7929541eC2318f3dCF7e';
const BASE_SEPOLIA_CHAIN_ID = 84532;
const USDC_DECIMALS = 6;
const USDC_DOMAIN = { name: 'USDC', version: '2' };`;
const next = `// Active chain/asset: follow the gateway's env-selected configuration
// (SAAX_CHAIN_ID / SAAX_X402_ASSET / SAAX_RPC_URL). The gateway exports the
// legacy names BASE_SEPOLIA_* / USDC_BASE_SEPOLIA aliased to the ACTIVE
// chain, so the MPP rail tracks the same .env switch (testnet <-> mainnet).
const USDC_BASE_SEPOLIA = gateway.USDC_BASE_SEPOLIA || '0x036CbD53842c5426634e7929541eC2318f3dCF7e';
const BASE_SEPOLIA_CHAIN_ID = gateway.BASE_SEPOLIA_CHAIN_ID || 84532;
const USDC_DECIMALS = 6;
const USDC_DOMAIN = { name: 'USDC', version: '2' };`;
if (!c.includes(old)) { console.error('MPP OLD BLOCK NOT FOUND'); process.exit(1); }
c = c.replace(old, next);
fs.writeFileSync(p, c);
console.log('mpp.js constants aliased to gateway active values; contains gateway.USDC_BASE_SEPOLIA:', c.includes('gateway.USDC_BASE_SEPOLIA'));