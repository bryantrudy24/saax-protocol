# AX Router — Operator Handoff (Complete Project Archive)

## What AX Router is

AX Router is a machine-to-machine economic routing layer for the agent economy. It sits between demand and supply: agents submit routing requests, and AX Router pairs them with the best supplier and settles the payment. The system is built as four layers — **demand intake** (the `/route` endpoint that accepts payment-backed routing requests and issues governed commitments), **discovery/ranking** (`router.js` + `rank-suppliers.js` score suppliers by price, freshness, and on-chain reputation), **payment routing** (a rail-agnostic settlement layer: x402 self-hosted gateway and the Machine Payments Protocol rail, chosen at execution time), and **reputation feedback** (`feedback.js` writes outcome data back to the reputation registry so routing quality compounds over time).

## Current state

- **Sprint 1 complete.** The four-layer pipeline is built and exercised end-to-end.
- **Day 8 security controls in place:** nonce-bound idempotency (replay-safe, no double charging), rate limiting (per-IP and per-wallet windows, proxy-spoof resistant), kill switch (instant 503 circuit-breaker, first gate in the pipeline, zero RPC under halt), and signature-derived buyer reputation (the signer of the payment authorization resolves to an on-chain identity).
- **Day 9: live testnet settlement proven on Base Sepolia** — 15 settlements across five consecutive clean runs (three required + two bonus), every transaction hash in `transaction-hashes.txt` and independently verifiable on BaseScan.
- **Day 10: dual-path signature detection.** The gateway probes the USDC contract for the `transferWithAuthorization` selector (`0xe3ee160e`) and selects EIP-3009 if present, EIP-2612 otherwise. Base Sepolia USDC is FiatTokenV2 (EIP-2612 only) — the EIP-2612 permit path is executed and proven on-chain; the EIP-3009 path is implemented and documented but unexecuted (mainnet RPC not touched). Evidence: `daily-logs/probe-signature-path-output.txt`.
- **Day 11: rail-agnostic commitment lifecycle.** Governed commitment (Trade Manifest, COSE_Sign1) → settlement-method-neutral requirement R → rail-selected validation → settlement → Spend Receipt binding commitment to rail reference. Recovery layer (Kleros Escrow V2) stubbed, interface-complete. See `daily-logs/day11-commitment-lifecycle.md`.
- **Day 12: MPP rail implemented.** `mppx` SDK integrated; the gateway emits dual challenges (x402 `PAYMENT-REQUIRED` + MPP `WWW-Authenticate: Payment`), accepts either credential, settles via the correct rail, and returns the matching receipt header. The same commitment settles via either rail (proven: `scripts/test-mpp-rail.js` 26/26, `scripts/test-mpp-endpoint.js` 17/17). MPP sessions deferred to a follow-up sprint. See `daily-logs/day12-mpp.md`.
- **Mainnet not activated.** No live-mode flags set; the gateway targets Base Sepolia only.

## Full project inventory

Every top-level directory and its purpose:

- `endpoint/` — the routing pipeline: HTTP intake (`route-server.js`), the x402 gateway (`gateway.js`), x402 protocol (`x402.js`), commitment/requirement/receipt builders (`commitment.js`, `requirement.js`, `receipt.js`), rail registry + rails (`rails/` — `index.js`, `x402.js`, `mpp.js`, `entitlement.js`), recovery interface (`recovery.js`), security controls (idempotency, rate limit, kill switch, identity, feedback), and the Day 8 test harnesses (`test-day8-item1-4.js`).
- `scripts/` — test harnesses, probes, generators, and tuning: `test-gateway.js` (Day 9 gateway harness incl. T10 dual-path), `test-mpp-rail.js`, `test-mpp-endpoint.js`, `rank-suppliers.js`, `probe-signature-path.js`, `gen-seller-wallet.js`, Day 8 probes, and the `tuning/` subdirectory (Day 6 hyperparameter tuning).
- `dump/` — database schema and restore files: `schema.sql`, `roles.sql`, `data.sql` (seed agent registry — testnet/public metadata only), `ranking_outcomes.sql`, `tuning_tables.sql`, plus Docker-backed verification harnesses and evidence.
- `data/` — agent registry snapshots and generated artifacts: Day 1-4 raw agent JSON, leaderboards, enrichment/rankings, and generated SQL batches (regenerable from `scripts/` + `dump/`).
- `abis/` — contract ABIs for on-chain interaction: `IdentityRegistry.json`, `ReputationRegistry.json`.
- `daily-logs/` — chronological build record: Day 1 through Day 12 logs, migration log, security-sprint reports, Day 10 custody setup + completion, Day 11 commitment lifecycle, Day 12 MPP, dual-path probe output, and the wallet checklist (now including the Day 10 mainnet readiness sections §13-17).
- Root files — `docker-compose.yml` (Postgres + PostgREST stack), `package.json`/`package-lock.json` (exact-pinned deps incl. `mppx`), `.env.example` (all variables documented with placeholders, incl. `AX_X402_SIGNATURE_PATH`, `AX_MPP_ENABLED`, `MPP_SECRET_KEY`), `transaction-hashes.txt` (the 15 Day 9 settlements), `dumpsig.txt` (mock x402 signature envelope), evidence files (`.output-*`), root reports (`sprint1-summary.md`, `day8-completion-report.md`), and `workshop/` (Day 1 control-proof artifact).

## Prerequisites

- **Node.js** 18+ (developed on v26; viem requires Node 18+)
- **Docker** + Docker Compose v2 (for the Postgres/PostgREST store)
- **npm** (dependency install)

```
npm install
```

## How to start the Docker stack

```
docker compose up -d
```

Verify the containers are healthy:

```
docker compose ps
```

You should see `ax_router_db` and `ax_router_postgrest` both reporting **healthy** (the db healthcheck runs `pg_isready`). Postgres listens on host port `5433`, PostgREST on `3000`.

## How to restore the database schema

The schema lives in `dump/schema.sql` plus `dump/roles.sql`. Restore with:

```
psql -h localhost -p 5433 -U postgres -d ax_router -v ON_ERROR_STOP=1 \
  -c "SET session_replication_role = replica;" \
  -f dump/roles.sql -f dump/schema.sql \
  -c "SET session_replication_role = DEFAULT;"
```

- The `session_replication_role = replica` setting disables trigger/constraint firing during restore so the schema loads cleanly in dependency order.
- `dump/ranking_outcomes.sql` and `dump/tuning_tables.sql` define the feedback/tuning tables used by Day 6+ features.
- `dump/data.sql` is the seed agent registry (testnet / public agent metadata only — no secrets).

## Environment variables

Copy `.env.example` to `.env` and populate **every** variable. There are no useful defaults — every value in `.env.example` is a placeholder. Critical groups:

- **Wallet**: `AX_SELLER_PRIVATE_KEY` (generate your own — never reuse testnet keys on mainnet), `AX_SELLER_ADDRESS`, `AX_TEST_BUYER_KEY`
- **Database**: `POSTGRES_PASSWORD`, `POSTGREST_JWT_SECRET`, `POSTGREST_URL`, `AX_POSTGREST_KEY`
- **Payment mode**: `AX_X402_MODE` (`mock` | `self`), `AX_GATEWAY_DRY_RUN` (`1` = no real broadcasts), `AX_X402_SIGNATURE_PATH` (`auto` | `eip3009` | `eip2612`)
- **MPP rail**: `AX_MPP_ENABLED` (`true` | `false` — default `true`, MPP registered as a rail), `MPP_SECRET_KEY` (HMAC key for MPP credential verification)
- **Security controls**: `AX_RATE_LIMIT_*`, `AX_KILL_SWITCH*`, `AX_FEEDBACK_SIGN_MODE`

## How to run the tests

Gateway harness (full x402 flow — dry-run by default, set `AX_GATEWAY_DRY_RUN=0` for live testnet settlement):

```
node scripts/test-gateway.js
```

MPP rail harness (the same commitment settling via either rail — the rail-agnosticism proof):

```
node scripts/test-mpp-rail.js
```

MPP endpoint harness (dual-challenge HTTP flow):

```
node scripts/test-mpp-endpoint.js
```

Day 8 security-control harnesses (against the Docker store):

```
node endpoint/test-day8-item1.js    # idempotency
node endpoint/test-day8-item2.js    # rate limiting
node endpoint/test-day8-item3.js    # kill switch
node endpoint/test-day8-item4.js    # buyer reputation / identity
```

Ranking harness:

```
node scripts/rank-suppliers.js
```

## What is mocked vs live

Honest accounting:

- **Mock by default.** `AX_X402_MODE=mock` is the default; payments are simulated, no blockchain interaction.
- **Self-hosted gateway available.** Set `AX_X402_MODE=self` for the real x402 gateway (`endpoint/gateway.js`). This is **testnet-proven** on Base Sepolia — mainnet is **not** activated.
- **Dual-path signatures.** EIP-2612 (permit + transferFrom) is executed and proven on Base Sepolia. EIP-3009 (transferWithAuthorization) is implemented with on-chain probe selection but **documented-only** — it has not been exercised against a live EIP-3009 signature.
- **MPP rail live in dry-run.** The MPP rail (`endpoint/rails/mpp.js`) is fully implemented and verified with `mppx` credential verification and settlement routing — but all settlements are dry-run; no live on-chain MPP broadcast has been made.
- **MPP sessions deferred.** Pay-as-you-go session support (off-chain vouchers, net settlement) is documented in `daily-logs/day12-mpp.md` but not implemented — it requires a different payment method (pathUSD/TIP-20) and is a follow-up sprint.
- **Custody: single-key testnet wallet.** The Safe multi-sig (3-of-5) custody model is documented (`daily-logs/day10-custody-setup.md`) but **not deployed** — pending operator hardware wallet procurement. Mainnet custody must switch to the Safe before activation.
- **Kleros recovery stubbed.** `endpoint/recovery.js` exposes the full escrow/dispute interface but throws `NOT_IMPLEMENTED` — actual Kleros integration happens post-mainnet.
- **Mainnet not activated.** No live-mode flags are set anywhere; the gateway targets Base Sepolia only (`eip155:84532`).

## What's next

1. **Mainnet activation path** — procure hardware wallets (manufacturer-direct per OOT framework), deploy the 3-of-5 Safe on Base mainnet, migrate the seller wallet into the Safe, create and fund the separate fee-payer wallet (gas only), verify the signature path with a read-only mainnet probe (expect EIP-3009), fund the seller with a small amount, then run the mainnet test sequence: three consecutive $0.01 USDC settlements, each verified on BaseScan with transaction hash and fee delta.
2. **EIP-3009 vs EIP-2612 divergence** — Base Sepolia USDC is FiatTokenV2 (EIP-2612 only); Base mainnet USDC supports both transferWithAuthorization (EIP-3009) and permit (EIP-2612). The dual-path probe resolves this at runtime, but the mainnet path must be verified against real mainnet USDC before activation.
3. **Demand generation** — the intake layer is built and tested; the next step is real demand (agent traffic) hitting `/route` with funded wallets. This is a separate track from mainnet activation.
4. **MPP sessions** — the pay-as-you-go mechanism that makes sub-cent routing fees economical; deferred to a follow-up sprint (see `daily-logs/day12-mpp.md`).

## Security notes

- **Generate your own wallet.** Never import or reuse the testnet seller/buyer keys on mainnet. `AX_SELLER_PRIVATE_KEY` must be a fresh key you generate and hold.
- **Never reuse testnet keys on mainnet** — testnet keys are public knowledge by design; any mainnet funds sent to a testnet-derived address are at risk. The archived testnet key (`daily-logs/archived-keys/`) is testnet-only by design.
- **Kill switch** — `AX_KILL_SWITCH=true` (or the kill-switch file, see `day7-wallet-checklist.md` §5) returns 503 from every endpoint with **zero** blockchain RPC calls and **zero** settlement broadcasts. It is the first gate in the pipeline. Test it before going live and keep it documented.
- **MPP secret** — `MPP_SECRET_KEY` is the HMAC key for MPP credential verification. It must be a long random value, never committed, and rotated if compromised.
- The ranking algorithm, weights, and outcome data are proprietary and never leave this project. Only plan/agent IDs and transaction metadata cross the payment boundary.