// AX Router — Day 2: verify getClients -> getSummary flow on live agents
const { JsonRpcProvider, Contract } = require('ethers');
const fs = require('fs');

const RPC = process.env.AX_RPC_URL || 'https://mainnet.base.org';
const REP = '0x8004BAa17C55a88189AE136b182e5fdA19dE9b63';

async function main() {
  const provider = new JsonRpcProvider(RPC);
  const abi = JSON.parse(fs.readFileSync(__dirname + '/../abis/ReputationRegistry.json', 'utf8'));
  const rep = new Contract(REP, abi, provider);

  for (const id of [0, 1, 2, 3, 4, 5, 100, 101, 107, 250, 500]) {
    let clients = [];
    try { clients = await rep.getClients(id); } catch (e) { console.log(`agent ${id}: getClients ERR ${String(e).slice(0,120)}`); continue; }
    console.log(`agent ${id}: ${clients.length} clients -> ${clients.slice(0,3).map(c => String(c)).join(',')}`);
    if (clients.length > 0) {
      try {
        const [count, summaryValue, decimals] = await rep.getSummary(id, [...clients], '', '');
        console.log(`   getSummary: count=${count} summaryValue=${summaryValue} decimals=${decimals}`);
        // avgX100 = summaryValue/count scaled to 0-100 (if decimals=0 and values are 0-100 style)
      } catch (e) {
        console.log(`   getSummary ERR ${String(e).slice(0,160)}`);
      }
    } else {
      console.log(`   -> no reputation feed; score null`);
    }
  }
  console.log('DONE');
}
main().catch(e => { console.error('FATAL', e); process.exit(1); });