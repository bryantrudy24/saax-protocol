const { JsonRpcProvider, Contract } = require('ethers');
const fs = require('fs');
const abi = JSON.parse(fs.readFileSync('abis/ReputationRegistry.json', 'utf8'));
const ADDR = '0x8004BAa17C55a88189AE136b182e5fdA19dE9b63';
async function main() {
  const p = new JsonRpcProvider('https://base-rpc.publicnode.com');
  const rep = new Contract(ADDR, abi, p);
  const targets = [73244, 73245, 73249, 95752, 96675, 84947];
  for (const id of targets) {
    try {
      const c = await rep.getClients(id);
      if (c.length === 0) { console.log(id, 'clients:0 (clean empty)'); continue; }
      const [cnt, sv, dec] = await rep.getSummary(id, [...c], '', '');
      console.log(id, 'clients:' + c.length, 'count:' + cnt, 'score:' + sv, 'dec:' + dec);
    } catch (e) { console.log(id, 'ERR:', String(e).slice(0, 120)); }
  }
}
main();