// AX Router — Day 3: Probe reputation for the capability-matched security agents
// (SYBIL 84667, Apex Leviathan 85380, plus STR 5859 subset used by leaderboard).
const { JsonRpcProvider, Contract } = require('ethers');
const fs = require('fs');

const RPC = process.env.AX_RPC_URL || 'https://base-rpc.publicnode.com';
const REPUTATION_REGISTRY = process.env.AX_REPUTATION_REGISTRY || '0x8004BAa17C55a88189AE136b182e5fdA19dE9b63';

async function main() {
  const provider = new JsonRpcProvider(RPC);
  const rep = new Contract(REPUTATION_REGISTRY, JSON.parse(fs.readFileSync('abis/ReputationRegistry.json', 'utf8')), provider);
  const ids = [84667, 85380];
  const out = [];
  for (const id of ids) {
    try {
      const clients = await rep.getClients(id);
      if (clients.length === 0) { out.push({ id, clients: 0, count: 0, avgX100: null }); continue; }
      const [count, summaryValue, valueDecimals] = await rep.getSummary(id, [...clients], '', '');
      const norm = Number(summaryValue) / Math.pow(10, Number(valueDecimals));
      out.push({ id, clients: clients.length, count: Number(count), avgX100: Math.round(norm * 100) / 100 });
    } catch (e) {
      out.push({ id, error: String(e).slice(0, 80) });
    }
  }
  console.log(JSON.stringify(out, null, 1));
  process.exit(0);
}
main().catch(e => { console.error('FATAL', String(e)); process.exit(1); });