// AX Router — Day 9: Kill switch zero-RPC proof (self mode, valid signature)
// Sends a VALID EIP-3009 auth to a kill-switch-ON server and proves:
//   - 503 halted (gate 1)
//   - NO payment-required / payment-response header (nothing processed)
//   - settlement path never ran (gateway nonce store untouched)
const path = require('path');
const http = require('http');
const crypto = require('crypto');
const { spawn } = require('child_process');
const { generatePrivateKey, privateKeyToAccount } = require('viem/accounts');
const { createWalletClient, http: vh } = require('viem');
const dotenv = require('dotenv');
dotenv.config({ path: path.join(__dirname, '..', '.env') });
const gateway = require('../endpoint/gateway.js');

const PORT = 8699;

function httpReq(port, p, method, headers, body) {
  return new Promise((resolve, reject) => {
    const r = http.request({ host: 'localhost', port, path: p, method, headers: headers || { 'Content-Type': 'application/json' } }, res => {
      let d = '';
      res.on('data', c => d += c);
      res.on('end', () => resolve({ status: res.statusCode, headers: res.headers, body: d }));
    });
    r.on('error', reject);
    if (body) r.write(body);
    r.end();
  });
}

async function waitHealth(port) {
  for (let i = 0; i < 60; i++) {
    try { const r = await httpReq(port, '/health', 'GET'); if (r.status === 200) return; } catch (_) {}
    await new Promise(r => setTimeout(r, 250));
  }
  throw new Error('server did not start on ' + port);
}

(async () => {
  const child = spawn(process.execPath, [path.join('endpoint', 'route-server.js')], {
    cwd: process.cwd(),
    env: {
      ...process.env,
      AX_PORT: String(PORT),
      AX_X402_MODE: 'self',
      AX_GATEWAY_DRY_RUN: '1',
      AX_KILL_SWITCH: 'true',
      AX_RATE_LIMIT_STORE: 'memory',
    },
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  child.stdout.on('data', () => {});
  child.stderr.on('data', () => {});
  try {
    await waitHealth(PORT);
    console.log('server up on :' + PORT + ' (AX_KILL_SWITCH=true, self mode)');

    // Build a VALID authorization — a kill switch must halt it at gate 1.
    const buyer = privateKeyToAccount(generatePrivateKey());
    const seller = gateway.getSellerAddress();
    const now = Math.floor(Date.now() / 1000);
    const domain = gateway.domainFor();
    const w = createWalletClient({ account: buyer, chain: gateway.baseSepolia, transport: vh() });
    const msg = {
      owner: buyer.address.toLowerCase(),
      spender: seller.toLowerCase(),
      value: BigInt(gateway.rawUnits(0.05)),
      nonce: BigInt(1),
      deadline: BigInt(now + 3600),
    };
    const sig = await w.signTypedData({ domain, types: gateway.EIP3009_TYPES, primaryType: 'Permit', message: msg });
    const payload = Buffer.from(JSON.stringify({
      x402Version: 2,
      resource: { url: 'urn:ax-router:route:v1' },
      accepted: { scheme: 'exact', network: gateway.NETWORK_CAIP2_BASE_SEPOLIA, amount: String(msg.value), asset: gateway.USDC_BASE_SEPOLIA, payTo: seller, maxTimeoutSeconds: 60 },
      payload: { signature: sig, authorization: { from: String(msg.owner), to: String(msg.spender), value: String(msg.value), validAfter: String(now - 60), validBefore: String(msg.deadline), nonce: String(1) } },
    })).toString('base64');

    const body = JSON.stringify({ capability: 'security scan', budget: 500, deadline: '2026-10-08' });
    gateway.clearNonces(); // assert the guard store is EMPTY before
    const t = await httpReq(PORT, '/route', 'POST', { 'Content-Type': 'application/json', 'payment-signature': payload }, body);
    console.log('kill-switch + valid signature -> HTTP ' + t.status);
    console.log('body: ' + t.body.slice(0, 140));
    console.log('payment-required header present? ' + !!t.headers['payment-required']);
    console.log('payment-response header present? ' + !!t.headers['payment-response']);
    const settled = gateway.getNonce(msg.nonce);
    console.log('nonce store after (settled?) ' + JSON.stringify(settled));

    const ok = t.status === 503 &&
      !t.headers['payment-required'] &&
      !t.headers['payment-response'] &&
      !settled;
    console.log(ok ? 'KILL SWITCH ZERO-RPC PROOF: PASS' : 'KILL SWITCH ZERO-RPC PROOF: FAIL');
    process.exit(ok ? 0 : 1);
  } finally {
    child.kill();
  }
})().catch(e => { console.error('PROBE CRASHED: ' + e); process.exit(2); });