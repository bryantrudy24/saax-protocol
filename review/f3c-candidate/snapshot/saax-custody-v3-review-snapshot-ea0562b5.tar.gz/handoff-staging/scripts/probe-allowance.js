// AX Router — live: probe allowance + nonce after the run-7 T2 allowance error.
const { createPublicClient, http } = require('viem');
const { baseSepolia } = require('viem/chains');
const BUYER = '0x8DB70f40A7Aa4563FaB645cf325F55934EEad07a';
const SELLER = '0x6611Fadc959c323C4CDCDd54FBb415954d795fDF';
const USDC = '0x036CbD53842c5426634e7929541eC2318f3dCF7e';
const client = createPublicClient({ chain: baseSepolia, transport: http('https://sepolia.base.org') });
const fn = (name, inputs, outputs) => ({ name, type: 'function', stateMutability: 'view', inputs, outputs });
(async () => {
  const allowance = await client.readContract({ address: USDC, abi: [fn('allowance', [{ name: 'o', type: 'address' }, { name: 's', type: 'address' }], [{ name: '', type: 'uint256' }])], functionName: 'allowance', args: [BUYER, SELLER] });
  const nonce = await client.readContract({ address: USDC, abi: [fn('nonces', [{ name: 'a', type: 'address' }], [{ name: '', type: 'uint256' }])], functionName: 'nonces', args: [BUYER] });
  console.log('allowance[buyer][seller]:', allowance.toString());
  console.log('buyer permit nonce       :', nonce.toString());
})().catch(e => { console.error('ERR', e.message || e); process.exit(1); });