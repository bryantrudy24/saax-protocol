// AX Router — Day 9 live: USDC contract state probe (read-only).
// Reads the exact on-chain facts needed to diagnose a transferWithAuthorization
// revert: chainId, name, symbol, decimals, version, DOMAIN_SEPARATOR,
// and nonceUsed[from][nonce] for the buyer + a fresh unused nonce.
const { createPublicClient, http, getAddress } = require('viem');
const { baseSepolia } = require('viem/chains');
const crypto = require('crypto');
require('dotenv').config({ path: require('path').join(__dirname, '..', '.env') });

const RPC = process.env.AX_BASE_SEPOLIA_RPC || 'https://sepolia.base.org';
const USDC = '0x036CbD53842c5426634e7929541eC2318f3dCF7e';
const BUYER = getAddress('0x8DB70f40A7Aa4563FaB645cf325F55934EEad07a');
const client = createPublicClient({ chain: baseSepolia, transport: http(RPC) });

const fn = (name, inputs, outputs) => ({ name, type: 'function', stateMutability: 'view', inputs, outputs });

async function main() {
  console.log('chainId from RPC: ' + await client.getChainId());
  const calls = {
    name: client.readContract({ address: USDC, abi: [fn('name', [], [{ name: '', type: 'string' }])], functionName: 'name' }),
    symbol: client.readContract({ address: USDC, abi: [fn('symbol', [], [{ name: '', type: 'string' }])], functionName: 'symbol' }),
    decimals: client.readContract({ address: USDC, abi: [fn('decimals', [], [{ name: '', type: 'uint8' }])], functionName: 'decimals' }),
    version: client.readContract({ address: USDC, abi: [fn('version', [], [{ name: '', type: 'string' }])], functionName: 'version' }),
    domainSep: client.readContract({ address: USDC, abi: [fn('DOMAIN_SEPARATOR', [], [{ name: '', type: 'bytes32' }])], functionName: 'DOMAIN_SEPARATOR' }),
    buyerBalance: client.readContract({ address: USDC, abi: [fn('balanceOf', [{ name: 'a', type: 'address' }], [{ name: '', type: 'uint256' }])], functionName: 'balanceOf', args: [BUYER] }),
  };
  const results = {};
  for (const [k, p] of Object.entries(calls)) { try { results[k] = await p; } catch (e) { results[k] = 'ERR ' + (e.message || e).slice(0, 120); } }
  console.log('name            :', results.name);
  console.log('symbol          :', results.symbol);
  console.log('decimals        :', results.decimals);
  console.log('version         :', results.version);
  console.log('DOMAIN_SEPARATOR:', results.domainSep);
  console.log('buyer USDC      :', results.buyerBalance);

  // nonceUsed for a FRESH nonce (must be false) and for all-zero ff nonce
  const freshNonce = '0x' + crypto.randomBytes(32).toString('hex');
  const nf = await client.readContract({ address: USDC, abi: [fn('nonceUsed', [{ name: 'a', type: 'address' }, { name: 'n', type: 'bytes32' }], [{ name: '', type: 'bool' }])], functionName: 'nonceUsed', args: [BUYER, freshNonce] }).catch(e => 'ERR ' + e.message.slice(0, 100));
  const ffNonce = '0x' + 'ff'.repeat(32);
  const nff = await client.readContract({ address: USDC, abi: [fn('nonceUsed', [{ name: 'a', type: 'address' }, { name: 'n', type: 'bytes32' }], [{ name: '', type: 'bool' }])], functionName: 'nonceUsed', args: [BUYER, ffNonce] }).catch(e => 'ERR ' + e.message.slice(0, 100));
  console.log('nonceUsed[buyer][fresh] =', nf);
  console.log('nonceUsed[buyer][0xff*32] =', nff);
  console.log('fresh nonce shown       =', freshNonce);
}

main().catch(e => { console.error('PROBE_ERROR', e && e.message ? e.message : e); process.exit(1); });