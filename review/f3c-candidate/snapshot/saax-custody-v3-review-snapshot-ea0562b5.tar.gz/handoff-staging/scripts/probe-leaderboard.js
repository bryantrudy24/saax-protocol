// AX Router — Day 3: Probe known ERC-8004 leaderboard agents for reputation.
// Uses the same verified Day-2 code path (getClients -> getSummary) to build
// a supplier pool that has real reputation spread. READ-ONLY. No wallet.
const { JsonRpcProvider, Contract } = require('ethers');
const fs = require('fs');

const RPC = process.env.AX_RPC_URL || 'https://base-rpc.publicnode.com';
const REPUTATION_REGISTRY = process.env.AX_REPUTATION_REGISTRY || '0x8004BAa17C55a88189AE136b182e5fdA19dE9b63';

async function main() {
  const provider = new JsonRpcProvider(RPC);
  const rep = new Contract(REPUTATION_REGISTRY, JSON.parse(fs.readFileSync('abis/ReputationRegistry.json', 'utf8')), provider);

  // Known leaderboard / named agents on ERC-8004 (from Day 1-2 logs + registry).
  const ids = [1380, 2290, 55985, 51085, 51169, 85430, 85332, 85331, 7522, 73244, 73245, 73246, 73247, 73248, 73249, 73250, 73251];
  const results = [];
  for (const id of ids) {
    try {
      const clients = await rep.getClients(id);
      if (clients.length === 0) { results.push({ id, clients: 0, count: 0, avgX100: null, note: 'no clients' }); continue; }
      const [count, summaryValue, valueDecimals] = await rep.getSummary(id, [...clients], '', '');
      const norm = Number(summaryValue) / Math.pow(10, Number(valueDecimals));
      results.push({ id, clients: clients.length, count: Number(count), avgX100: Math.round(norm * 100) / 100 });
    } catch (e) {
      results.push({ id, error: String(e).slice(0, 100) });
    }
  }
  console.log(JSON.stringify(results, null, 1));
  fs.writeFileSync('data/leaderboard-probe-day3.json', JSON.stringify(results, null, 1));
  process.exit(0);
}
main().catch(e => { console.error('FATAL', String(e)); process.exit(1); });