// AX Router — live: inspect the seller's recent USDC txs (permit vs
// transferFrom) around run 7's T2 failure to see the exact spender/value the
// permit set vs what transferFrom tried to pull.
const { createPublicClient, http, getAddress } = require('viem');
const { baseSepolia } = require('viem/chains');
const SELLER = getAddress('0x6611Fadc959c323C4CDCDd54FBb415954d795fDF');
const USDC = '0x036CbD53842c5426634e7929541eC2318f3dCF7e';
const client = createPublicClient({ chain: baseSepolia, transport: http('https://sepolia.base.org') });

(async () => {
  const latest = await client.getBlockNumber();
  const from = latest - 300n;
  const txs = await client.getLogs({
    address: USDC,
    event: { type: 'event', name: 'Transfer', inputs: [{ type: 'address', name: 'from', indexed: true }, { type: 'address', name: 'to', indexed: true }, { type: 'uint256', name: 'value', indexed: false }] },
    fromBlock: from,
    toBlock: latest,
  });
  // Only show events where the SELLER is to (incoming settlements)
  const incoming = txs.filter(t => String(t.args.to).toLowerCase() === SELLER.toLowerCase());
  console.log('incoming transfers to seller:', incoming.length);
  incoming.slice(-14).forEach(t => console.log('  block', t.blockNumber.toString(), 'value', (t.args.value || 0n).toString(), 'tx', t.transactionHash.slice(0, 20) + '...'));
  // Also grab the actual TX calldata for the last few incoming transfers (the
  // sender of the tx = seller = gas payer -> this is transferFrom calldata)
  for (const t of incoming.slice(-4)) {
    try {
      const tx = await client.getTransaction({ hash: t.transactionHash });
      const sel = tx.input.slice(0, 10);
      console.log('tx', t.transactionHash.slice(0, 20) + '...', 'to', tx.to, 'input[:10]', sel, 'from(sender)', tx.from);
    } catch (e) { console.log('getTx ERR', String(e.message || e).slice(0, 80)); }
  }
})().catch(e => { console.error('ERR', e.message || e); process.exit(1); });