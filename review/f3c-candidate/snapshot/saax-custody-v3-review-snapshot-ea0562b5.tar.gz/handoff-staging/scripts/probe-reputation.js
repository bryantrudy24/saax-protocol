// AX Router — Day 2: probe the ERC-8004 ReputationRegistry on Base mainnet
// Verifies the canonical deployed address, then calls getSummary() for a few
// known agent ids to confirm return shape (count, summaryValue, summaryValueDecimals).
// READ-ONLY on-chain; no wallet, no writes, no settlement.
const { JsonRpcProvider, Contract } = require('ethers');
const fs = require('fs');

const RPC = process.env.AX_RPC_URL || 'https://mainnet.base.org';
const REPUTATION_REGISTRY = process.env.AX_REPUTATION_REGISTRY || '0x8004BAa17C55a88189AE136b182e5fdA19dE9b63';
const IDENTITY_REGISTRY = '0x8004A169FB4a3325136EB29fA0ceB6D2e539a432';

async function main() {
  console.log('AX Router — Day 2 ReputationRegistry probe');
  console.log(`RPC: ${RPC}`);
  console.log(`ReputationRegistry: ${REPUTATION_REGISTRY}`);
  console.log(`Expected IdentityRegistry ref: ${IDENTITY_REGISTRY}`);

  const provider = new JsonRpcProvider(RPC);
  const abi = JSON.parse(fs.readFileSync(__dirname + '/../abis/ReputationRegistry.json', 'utf8'));
  const rep = new Contract(REPUTATION_REGISTRY, abi, provider);

  const chainId = await provider.send('eth_chainId', []);
  console.log(`chainId: ${chainId}`);
  if (chainId !== '0x2105') throw new Error(`unexpected chain ${chainId}`);

  const version = await rep.getVersion();
  console.log(`getVersion: ${version}`);

  const idReg = String(await rep.getIdentityRegistry());
  console.log(`getIdentityRegistry: ${idReg}`);
  console.log(`ref matches expected: ${idReg.toLowerCase() === IDENTITY_REGISTRY.toLowerCase()}`);

  // Probe a spread of agent ids from Day 1 indexing
  for (const id of [0, 1, 2, 3, 4, 5, 100, 101, 107]) {
    try {
      const [count, summaryValue, decimals] = await rep.getSummary(id, [], '', '');
      console.log(`agent ${id}: count=${count} summaryValue=${summaryValue} decimals=${decimals}`);
    } catch (e) {
      console.log(`agent ${id}: ERR ${String(e).slice(0, 160)}`);
    }
  }
  console.log('DONE');
}

main().catch(e => { console.error('FATAL', e); process.exit(1); });