// AX Router — live: list ALL buyer->seller 50000 transfers ordered by block,
// with tx hash + permit nonce mapping, to enumerate every settlement tx for the
// report. The transfer's tx hash IS the transferFrom (settlement) hash.
const { createPublicClient, http, parseAbiItem, getAddress } = require('viem');
const { baseSepolia } = require('viem/chains');
const BUYER = getAddress('0x8DB70f40A7Aa4563FaB645cf325F55934EEad07a');
const SELLER = getAddress('0x6611Fadc959c323C4CDCDd54FBb415954d795fDF');
const USDC = '0x036CbD53842c5426634e7929541eC2318f3dCF7e';
const client = createPublicClient({ chain: baseSepolia, transport: http('https://sepolia.base.org') });
(async () => {
  const latest = await client.getBlockNumber();
  // Scan back ~2500 blocks to cover the session
  const from = latest - 2500n;
  let all = [];
  for (let b = from; b <= latest; b += 300n) {
    const to = b + 299n > latest ? latest : b + 299n;
    try {
      const logs = await client.getLogs({
        address: USDC,
        event: parseAbiItem('event Transfer(address indexed from,address indexed to,uint256 value)'),
        fromBlock: b, toBlock: to,
        args: { from: BUYER, to: SELLER },
      });
      all = all.concat(logs);
    } catch (e) { /* skip range */ }
  }
  all.sort((a, b) => Number(a.blockNumber) - Number(b.blockNumber));
  console.log('total buyer->seller transfers:', all.length);
  // Show the last 20 (the live-test session)
  all.slice(-20).forEach(l => {
    console.log('block', l.blockNumber.toString(), 'value', String(l.args.value), 'hash', l.transactionHash, 'txnIdx', l.transactionIndex);
  });
})().catch(e => { console.error('ERR', e.message || e); process.exit(1); });