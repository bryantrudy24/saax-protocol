// AX Router — Day 9: Real-broadcast mode probe (NO dry-run)
// Proves the live settlement path errors CLEANLY when wallets aren't funded
// (502, no partial charge) — and documents what funding unlocks.
// Run manually when the seller wallet holds testnet ETH + USDC to see a real
// broadcast; without funds it must fail with a clear settlement error.
const path = require('path');
const http = require('http');
const crypto = require('crypto');
const { spawn } = require('child_process');
const { generatePrivateKey, privateKeyToAccount } = require('viem/accounts');
const { createWalletClient, http: vh } = require('viem');
const dotenv = require('dotenv');
dotenv.config({ path: path.join(__dirname, '..', '.env') });
const gateway = require('../endpoint/gateway.js');

const PORT = 8705;

function httpReq(port, p, method, headers, body) {
  return new Promise((resolve, reject) => {
    const r = http.request({ host: 'localhost', port, path: p, method, headers: headers || { 'Content-Type': 'application/json' } }, res => {
      let d = '';
      res.on('data', c => d += c);
      res.on('end', () => resolve({ status: res.statusCode, headers: res.headers, body: d }));
    });
    r.on('error', reject);
    if (body) r.write(body);
    r.end();
  });
}

async function waitHealth(port) {
  for (let i = 0; i < 60; i++) {
    try { const r = await httpReq(port, '/health', 'GET'); if (r.status === 200) return; } catch (_) {}
    await new Promise(r => setTimeout(r, 250));
  }
  throw new Error('server did not start on ' + port);
}

(async () => {
  const child = spawn(process.execPath, [path.join('endpoint', 'route-server.js')], {
    cwd: process.cwd(),
    env: { ...process.env, AX_PORT: String(PORT), AX_X402_MODE: 'self', AX_GATEWAY_DRY_RUN: '0', AX_RATE_LIMIT_STORE: 'memory' },
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  child.stdout.on('data', () => {});
  child.stderr.on('data', () => {});
  try {
    await waitHealth(PORT);
    console.log('server up on :' + PORT + ' (self mode, REAL broadcast, no dry-run)');
    const buyer = privateKeyToAccount(generatePrivateKey());
    const seller = gateway.getSellerAddress();
    const now = Math.floor(Date.now() / 1000);
    const domain = gateway.domainFor();
    const w = createWalletClient({ account: buyer, chain: gateway.baseSepolia, transport: vh() });
    // FiatTokenV2 Permit: owner=buyer, spender=seller, value, nonce (counter),
    // deadline.
    const permitNonce = 0;
    const msg = {
      owner: buyer.address.toLowerCase(),
      spender: seller.toLowerCase(),
      value: BigInt(gateway.rawUnits(0.05)),
      nonce: BigInt(permitNonce),
      deadline: BigInt(now + 3600),
    };
      const domain = gateway.domainFor();
      const w = createWalletClient({ account: buyer, chain: gateway.baseSepolia, transport: vh() });
    const sig = await w.signTypedData({ domain, types: gateway.EIP3009_TYPES, primaryType: 'Permit', message: msg });
    const payload = Buffer.from(JSON.stringify({
    x402Version: 2,
    resource: { url: 'urn:ax-router:route:v1' },
      accepted: { scheme: 'exact', network: gateway.NETWORK_CAIP2_BASE_SEPOLIA, amount: String(msg.value), asset: gateway.USDC_BASE_SEPOLIA, payTo: seller, maxTimeoutSeconds: 60 },
      payload: { signature: sig, authorization: { from: msg.owner, to: msg.spender, value: String(msg.value), validAfter: String(now - 60), validBefore: String(msg.deadline), nonce: String(permitNonce) } },
    })).toString('base64');
    const body = JSON.stringify({ capability: 'security scan', budget: 500, deadline: '2026-10-08' });
    const t = await httpReq(PORT, '/route', 'POST', { 'Content-Type': 'application/json', 'payment-signature': payload }, body);
    console.log('real-broadcast without funded wallets -> HTTP ' + t.status);
    console.log('body: ' + t.body.slice(0, 220));
    const pr = t.headers && t.headers['payment-response'];
    console.log('payment-response: ' + (pr ? Buffer.from(pr, 'base64').toString('utf8') : 'none'));
    // Expected without funds: 502 settlement failed (broadcast reverted / no
    // gas). This is the CLEAN failure mode — no partial charge, no routing
    // result served.
    const cleanFail = t.status === 502 && /settlement failed/i.test(t.body) && !pr;
    console.log(cleanFail ? 'REAL-BROADCAST CLEAN-FAILURE PROOF: PASS' : 'REAL-BROADCAST PROBE: status ' + t.status + ' (see body)');
    process.exit(cleanFail ? 0 : 1);
  } finally {
    child.kill();
  }
})().catch(e => { console.error('PROBE CRASHED: ' + e); process.exit(2); });