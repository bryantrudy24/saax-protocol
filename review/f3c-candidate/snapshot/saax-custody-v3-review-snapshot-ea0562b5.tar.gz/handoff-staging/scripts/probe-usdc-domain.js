// AX Router — Day 9: Probe USDC contract on Base Sepolia (name/version/domain)
// Confirms the EIP-712 domain parameters the gateway uses for EIP-3009
// signature verification, and proves Base Sepolia RPC reachability.
const { createPublicClient, http, getAddress } = require('viem');
const { baseSepolia } = require('../endpoint/gateway.js');

const USDC = '0x036CbD53842c5426634e7929541eC2318f3dCF7e';

(async () => {
  const client = createPublicClient({ chain: baseSepolia, transport: http() });
  console.log('RPC:', baseSepolia.rpcUrls.default.http[0]);
  try {
    const [name, symbol, decimals, version, domain] = await Promise.all([
      client.readContract({ address: USDC, abi: [{ name: 'name', type: 'function', stateMutability: 'view', inputs: [], outputs: [{ name: '', type: 'string' }] }], functionName: 'name' }),
      client.readContract({ address: USDC, abi: [{ name: 'symbol', type: 'function', stateMutability: 'view', inputs: [], outputs: [{ name: '', type: 'string' }] }], functionName: 'symbol' }),
      client.readContract({ address: USDC, abi: [{ name: 'decimals', type: 'function', stateMutability: 'view', inputs: [], outputs: [{ name: '', type: 'uint8' }] }], functionName: 'decimals' }),
      client.readContract({ address: USDC, abi: [{ name: 'version', type: 'function', stateMutability: 'view', inputs: [], outputs: [{ name: '', type: 'string' }] }], functionName: 'version' }),
      client.readContract({ address: USDC, abi: [{ name: 'DOMAIN_SEPARATOR', type: 'function', stateMutability: 'view', inputs: [], outputs: [{ name: '', type: 'bytes32' }] }], functionName: 'DOMAIN_SEPARATOR' }),
    ]);
    console.log('name:', name);
    console.log('symbol:', symbol);
    console.log('decimals:', decimals);
    console.log('version:', version);
    console.log('DOMAIN_SEPARATOR:', domain);
    // Recompute the expected EIP-712 domain separator locally to cross-check.
    const { keccak256, encodePacked, concat, toHex, pad } = require('viem');
    const EIP712_DOMAIN_TYPEHASH = keccak256(toHex('EIP712Domain(string name,string version,uint256 chainId,address verifyingContract)'));
    const nameHash = keccak256(toHex(String(name)));
    const versionHash = keccak256(toHex(String(version)));
    const expected = keccak256(concat([
      EIP712_DOMAIN_TYPEHASH,
      nameHash,
      versionHash,
      pad(toHex(84532), { size: 32 }),
      pad(getAddress(USDC), { size: 32 }),
    ]));
    console.log('expected separator :', expected);
    console.log('match:', String(domain).toLowerCase() === expected.toLowerCase() ? 'YES' : 'NO');
  } catch (e) {
    console.log('PROBE ERROR:', String(e.message || e).slice(0, 300));
  }
})();