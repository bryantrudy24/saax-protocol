// Probe ERC-8004 Identity Registry on Base mainnet (Day 1 recon, no writes)
const { JsonRpcProvider, Contract } = require('ethers');
const fs = require('fs');

const RPC = 'https://mainnet.base.org';
const IDENTITY_REGISTRY = '0x8004A169FB4a3325136EB29fA0ceB6D2e539a432';

(async () => {
  const provider = new JsonRpcProvider(RPC);
  const abi = JSON.parse(fs.readFileSync(__dirname + '/../abis/IdentityRegistry.json', 'utf8'));
  const reg = new Contract(IDENTITY_REGISTRY, abi, provider);

  // Chain sanity
  const chainId = await provider.send('eth_chainId', []);
  console.log('chainId:', chainId);

  // Does the ABI/deployment expose totalSupply or similar enumerables?
  const fnNames = abi.filter(f => f.type === 'function').map(f => f.name);
  console.log('has totalSupply:', fnNames.includes('totalSupply'));
  console.log('has tokenURI:', fnNames.includes('tokenURI'));
  console.log('has ownerOf:', fnNames.includes('ownerOf'));

  // Probe a window of ids for existing behavior
  for (let i = 0; i < 12; i++) {
    let uri = null, owner = null;
    try {
      uri = await reg.tokenURI(i);
    } catch (e) { uri = 'REVERT:' + String(e).slice(0, 60); }
    try {
      owner = await reg.ownerOf(i);
    } catch (e) { owner = 'REVERT:' + String(e).slice(0, 60); }
    console.log(`id=${i} uri=${uri ? String(uri).slice(0, 60) : '(empty)'} owner=${String(owner).slice(0, 20)}`);
  }
})().catch(e => { console.error('PROBE FAIL', e); process.exit(1); });