// AX Router — Day 10: Probe the signature path for an asset+chain (dual-path)
// Evidence tool for the EIP-3009 vs EIP-2612 decision:
//   - Reads the token contract CODE and searches for the
//     transferWithAuthorization selector (0xe3ee160e, DERIVED from the ABI
//     signature 9-arg function, not hardcoded — see EIP-3009 spec).
//   - Prints the selector evidence + the selected path.
//   - Same derivation as endpoint/gateway.js (TWA_SELECTOR) — any drift in the
//     ABI signature is caught here first.
//
// Usage:
//   node scripts/probe-signature-path.js                      (Base Sepolia USDC)
//   node scripts/probe-signature-path.js 0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913 8453
//     (Base MAINNET USDC — read-only probe, no tx, no funds)
const { createPublicClient, http, getAddress, keccak256, toHex, slice } = require('viem');
const { baseSepolia, USDC_BASE_SEPOLIA, TWA_SELECTOR } = require('../endpoint/gateway.js');

const USDC_MAINNET_BASE = '0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913';

(async () => {
  const assetArg = process.argv[2];
  const chainArg = process.argv[3];
  const asset = assetArg || USDC_BASE_SEPOLIA;
  const chainId = chainArg ? Number(chainArg) : 84532;
  const rpc = chainId === 8453 ? 'https://mainnet.base.org' : baseSepolia.rpcUrls.default.http[0];
  console.log('PROBE target: asset=' + asset + ' chainId=' + chainId);
  console.log('RPC: ' + rpc);
  console.log('transferWithAuthorization selector (derived): ' + TWA_SELECTOR);
  const client = createPublicClient({ chain: chainId === 8453 ? { id: 8453, name: 'Base', network: 'base', nativeCurrency: { name: 'Ether', symbol: 'ETH', decimals: 18 }, rpcUrls: { default: { http: [rpc] } } } : baseSepolia, transport: http() });
  try {
    const code = await client.getCode({ address: getAddress(asset) });
    const hex = code ? code.toLowerCase() : '0x';
    const selectorHex = TWA_SELECTOR.slice(2).toLowerCase();
    const found = hex.includes(selectorHex);
    const [name, version] = await Promise.all([
      client.readContract({ address: getAddress(asset), abi: [{ name: 'name', type: 'function', stateMutability: 'view', inputs: [], outputs: [{ name: '', type: 'string' }] }], functionName: 'name' }).catch(() => 'n/a'),
      client.readContract({ address: getAddress(asset), abi: [{ name: 'version', type: 'function', stateMutability: 'view', inputs: [], outputs: [{ name: '', type: 'string' }] }], functionName: 'version' }).catch(() => 'n/a'),
    ]);
    console.log('name: ' + name + ' version: ' + version);
    console.log('code bytes: ' + (hex.length > 2 ? (hex.length - 2) / 2 : 0));
    console.log('selector ' + TWA_SELECTOR + ' present in code: ' + (found ? 'YES' : 'NO'));
    console.log('SELECTED PATH: ' + (found ? 'eip3009 (transferWithAuthorization)' : 'eip2612 (permit + transferFrom)'));
  } catch (e) {
    console.log('PROBE ERROR: ' + String(e.message || e).slice(0, 300));
    process.exitCode = 1;
  }
})();