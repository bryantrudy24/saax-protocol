// AX Router — Day 9 live: FiatTokenV2 permit semantics probe (read-only).
// The Base Sepolia USDC implementation is FiatTokenV2 (EIP-2612 permit, no
// EIP-3009). Read PERMIT_TYPEHASH/name/version/DOMAIN_SEPARATOR/nonces so the
// replacement settle path matches the contract exactly.
const { createPublicClient, http } = require('viem');
const { baseSepolia } = require('viem/chains');
require('dotenv').config({ path: require('path').join(__dirname, '..', '.env') });

const RPC = process.env.AX_BASE_SEPOLIA_RPC || 'https://sepolia.base.org';
const USDC = '0x036CbD53842c5426634e7929541eC2318f3dCF7e';
const BUYER = '0x8DB70f40A7Aa4563FaB645cf325F55934EEad07a';
const client = createPublicClient({ chain: baseSepolia, transport: http(RPC) });
const fn = (name, inputs, outputs) => ({ name, type: 'function', stateMutability: 'view', inputs, outputs });

async function main() {
  const calls = {
    PERMIT_TYPEHASH: client.readContract({ address: USDC, abi: [fn('PERMIT_TYPEHASH', [], [{ name: '', type: 'bytes32' }])], functionName: 'PERMIT_TYPEHASH' }),
    name: client.readContract({ address: USDC, abi: [fn('name', [], [{ name: '', type: 'string' }])], functionName: 'name' }),
    version: client.readContract({ address: USDC, abi: [fn('version', [], [{ name: '', type: 'string' }])], functionName: 'version' }),
    DOMAIN_SEPARATOR: client.readContract({ address: USDC, abi: [fn('DOMAIN_SEPARATOR', [], [{ name: '', type: 'bytes32' }])], functionName: 'DOMAIN_SEPARATOR' }),
    nonces: client.readContract({ address: USDC, abi: [fn('nonces', [{ name: 'a', type: 'address' }], [{ name: '', type: 'uint256' }])], functionName: 'nonces', args: [BUYER] }),
  };
  for (const [k, p] of Object.entries(calls)) {
    try { console.log(k.padEnd(18), (await p).toString()); }
    catch (e) { console.log(k.padEnd(18), 'ERR', String(e.message || e).slice(0, 160)); }
  }
}
main().catch(e => { console.error('PROBE_ERROR', e.message || e); process.exit(1); });