// AX Router — Day 9 live test, Step 1: on-chain funding probe.
// Reads ETH and USDC balances for seller + buyer wallets directly from
// Base Sepolia RPC. Read-only; never signs or broadcasts anything.
// Usage: node scripts/probe-funding.js
const { createPublicClient, http, formatUnits, getAddress } = require('viem');
const { baseSepolia } = require('viem/chains');
require('dotenv').config({ path: require('path').join(__dirname, '..', '.env') });

const RPC = process.env.AX_BASE_SEPOLIA_RPC || 'https://sepolia.base.org';
const USDC = '0x036CbD53842c5426634e7929541eC2318f3dCF7e'; // Circle, Base Sepolia, 6 decimals

const SELLER = getAddress(process.env.AX_SELLER_ADDRESS || '0x6611Fadc959c323C4CDCDd54FBb415954d795fDF');
const BUYER = getAddress('0x8DB70f40A7Aa4563FaB645cf325F55934EEad07a');

const client = createPublicClient({ chain: baseSepolia, transport: http(RPC) });

const abi = [{ name: 'balanceOf', type: 'function', stateMutability: 'view', inputs: [{ name: 'a', type: 'address' }], outputs: [{ name: '', type: 'uint256' }] }];

async function main() {
  const block = await client.getBlockNumber();
  console.log(`RPC: ${RPC}`);
  console.log(`Block: #${block}`);

  async function balances(label, addr) {
    const [ethWei, usdcRaw] = await Promise.all([
      client.getBalance({ address: addr }),
      client.readContract({ address: USDC, abi, functionName: 'balanceOf', args: [addr] }),
    ]);
    console.log(`--- ${label} ${addr}`);
    console.log(`  ETH : ${formatUnits(ethWei, 18)} ETH (${ethWei.toString()} wei)`);
    console.log(`  USDC: ${formatUnits(usdcRaw, 6)} USDC (${usdcRaw.toString()} microUSDC)`);
    return { ethWei, usdcRaw };
  }

  const s = await balances('SELLER', SELLER);
  const b = await balances('BUYER ', BUYER);

  const ETH_REQ = 100000000000000n; // 0.0001 ETH (~10 settlement gas txns)
  const usdcFloatS = Number(formatUnits(s.usdcRaw, 6));
  const usdcFloatB = Number(formatUnits(b.usdcRaw, 6));

  const ok = (c, msg) => console.log(`${c ? 'PASS' : 'FAIL'}  ${msg}`);
  ok(s.ethWei >= ETH_REQ, `Seller ETH >= 0.0001 (got ${formatUnits(s.ethWei, 18)})`);
  ok(usdcFloatS > 0, `Seller USDC > 0 (got ${usdcFloatS})`);
  ok(usdcFloatB >= 0.15, `Buyer USDC >= 0.15 for 3x $0.05 tests (got ${usdcFloatB})`);

  // Machine-readable summary line
  console.log('JSON ' + JSON.stringify({ block: block.toString(), seller: { eth: formatUnits(s.ethWei, 18), usdc: usdcFloatS }, buyer: { usdc: usdcFloatB } }));
}

main().catch((e) => { console.error('PROBE_ERROR', e && e.message ? e.message : e); process.exit(1); });