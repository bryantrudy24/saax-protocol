// AX Router — live: all Permit events with owner=buyer in a tight range, to
// map nonce -> block and find which permits consumed which nonces.
const { createPublicClient, http, parseAbiItem, getAddress } = require('viem');
const { baseSepolia } = require('viem/chains');
const BUYER = getAddress('0x8DB70f40A7Aa4563FaB645cf325F55934EEad07a');
const USDC = '0x036CbD53842c5426634e7929541eC2318f3dCF7e';
const client = createPublicClient({ chain: baseSepolia, transport: http('https://sepolia.base.org') });
(async () => {
  const latest = await client.getBlockNumber();
  const from = latest - 800n;
  let count = 0;
  for (let b = from; b <= latest; b += 150n) {
    const to = b + 149n > latest ? latest : b + 149n;
    try {
      const logs = await client.getLogs({
        address: USDC,
        event: parseAbiItem('event Permit(address indexed owner,address indexed spender,uint256 value,uint256 nonce,uint256 deadline)'),
        fromBlock: b,
        toBlock: to,
        args: { owner: BUYER },
      });
      for (const l of logs) {
        count++;
        console.log('nonce', String(l.args.nonce), 'spender', String(l.args.spender).slice(0, 10), 'value', String(l.args.value), 'block', l.blockNumber.toString(), 'tx', l.transactionHash.slice(0, 18) + '...');
      }
    } catch (e) { console.log('range', b.toString(), 'ERR', String(e.message || e).slice(0, 60)); }
  }
  console.log('total:', count);
})().catch(e => { console.error('ERR', e.message || e); process.exit(1); });