// AX Router — live: fetch recent Permit + Transfer events involving the buyer
// and decode the spender/value to confirm the permit sets allowance for the
// SELLER (or a different spender), diagnosing the run-7 allowance revert.
const { createPublicClient, http, parseAbiItem, getAddress } = require('viem');
const { baseSepolia } = require('viem/chains');
const BUYER = getAddress('0x8DB70f40A7Aa4563FaB645cf325F55934EEad07a');
const USDC = '0x036CbD53842c5426634e7929541eC2318f3dCF7e';
const client = createPublicClient({ chain: baseSepolia, transport: http('https://sepolia.base.org') });

(async () => {
  const latest = await client.getBlockNumber();
  const from = latest - 200n; // ~recent blocks
  console.log('scanning blocks', from.toString(), '->', latest.toString());
  try {
    const permits = await client.getLogs({
      address: USDC,
      event: parseAbiItem('event Permit(address indexed owner, address indexed spender, uint256 value, uint256 nonce, uint256 deadline)'),
      fromBlock: from,
      toBlock: latest,
      args: { owner: BUYER },
    });
    console.log('Permit events for buyer:', permits.length);
    permits.slice(-8).forEach(p => console.log('  block', p.blockNumber.toString(), 'spender', p.args.spender, 'value', (p.args.value || 0n).toString(), 'nonce', (p.args.nonce || 0n).toString(), 'tx', p.transactionHash.slice(0, 18) + '...'));
  } catch (e) { console.log('Permit scan ERR', String(e.message || e).slice(0, 120)); }
  try {
    const transfers = await client.getLogs({
      address: USDC,
      event: parseAbiItem('event Transfer(address indexed from, address indexed to, uint256 value)'),
      fromBlock: from,
      toBlock: latest,
      args: { from: BUYER },
    });
    console.log('Transfers FROM buyer:', transfers.length);
    transfers.slice(-8).forEach(p => console.log('  block', p.blockNumber.toString(), 'to', p.args.to, 'value', (p.args.value || 0n).toString(), 'tx', p.transactionHash.slice(0, 18) + '...'));
  } catch (e) { console.log('Transfer scan ERR', String(e.message || e).slice(0, 120)); }
})().catch(e => { console.error('ERR', e.message || e); process.exit(1); });