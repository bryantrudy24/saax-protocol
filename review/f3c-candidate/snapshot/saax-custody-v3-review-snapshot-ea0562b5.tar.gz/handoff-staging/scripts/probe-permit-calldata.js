// AX Router — live: find the seller's permit txs (selector d505accf) in the
// run-7 window and DECODE the spender/value to see if the permit set allowance
// for the seller or a DIFFERENT spender.
const { createPublicClient, http, getAddress, decodeAbiParameters, parseAbiParameters } = require('viem');
const { baseSepolia } = require('viem/chains');
const SELLER = getAddress('0x6611Fadc959c323C4CDCDd54FBb415954d795fDF');
const USDC = '0x036CbD53842c5426634e7929541eC2318f3dCF7e';
const client = createPublicClient({ chain: baseSepolia, transport: http('https://sepolia.base.org') });

(async () => {
  const latest = await client.getBlockNumber();
  const from = latest - 400n;
  console.log('scan block range', from.toString(), latest.toString());
  let found = 0;
  for (let b = from; b <= latest; b += 20n) {
    const to = b + 19n > latest ? latest : b + 19n;
    try {
      const txs = await client.getBlock({ blockNumber: b, includeTransactions: true });
      // check each tx from seller to USDC with permit selector
      const relevant = (txs.transactions || []).filter(t => String(t.from).toLowerCase() === SELLER.toLowerCase() && String(t.to).toLowerCase() === USDC.toLowerCase() && t.input && t.input.startsWith('0xd505accf'));
      for (const tx of relevant) {
        found++;
        try {
          const args = decodeAbiParameters(parseAbiParameters('address,address,uint256,uint256,uint8,bytes32,bytes32'), '0x' + tx.input.slice(10));
          console.log('PERMIT tx', tx.hash.slice(0, 20) + '...', 'block', b.toString(), 'owner', args[0], 'spender', args[1], 'value', args[2].toString(), 'deadline', args[3].toString(), '> now?', args[3] > BigInt(Math.floor(Date.now()/1000)));
        } catch (e) { console.log('PERMIT tx', tx.hash.slice(0, 20) + '...', 'block', b.toString(), 'DECODE ERR', String(e.message || e).slice(0, 60)); }
      }
    } catch (e) { /* skip */ }
  }
  console.log('total permit txs from seller:', found);
})().catch(e => { console.error('ERR', e.message || e); process.exit(1); });