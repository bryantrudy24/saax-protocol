-- AX Router — Sprint 2 Item 3: tuning history + proposals (operator-gated)
--
-- The tuning job writes EVERY run to tuning_history (old weights, proposed new
-- weights, sample size, predictive powers, whether the change was applied).
-- Below the 100-transaction minimum it logs insufficient_data (status) and
-- proposes nothing.
--
-- Weight proposals land in tuning_proposals with status='pending' — a review
-- queue. The operator approves (UPDATE ... SET status='approved') and THEN
-- apply-weights.js --confirm updates the environment. NOTHING auto-applies.
--
-- Trade-secret protection: same posture as ranking_outcomes — RLS on, zero
-- policies, service_role-only grants. Weight proposals and outcome data never
-- leave this Postgres instance.

BEGIN;

-- Component decomposition column (Sprint 2, additive): the mandated outcome
-- schema stores composite supplier_scores + weights_used. Predictive-power
-- analysis needs each component (reputation/freshness/price) of the SELECTED
-- supplier per row — a 1-equation/3-unknowns problem from the composite
-- alone, so the ranker records the per-component breakdown here at ranking
-- time. Purely additive; the brief's columns are unchanged.
ALTER TABLE ax_router.ranking_outcomes ADD COLUMN IF NOT EXISTS component_scores jsonb;

CREATE TABLE IF NOT EXISTS ax_router.tuning_history (
  id                  uuid primary key default gen_random_uuid(),
  run_at              timestamptz not null default now(),
  old_weights         jsonb not null,
  new_weights         jsonb,                    -- null when insufficient_data
  sample_size         integer not null,
  predictive_powers   jsonb not null,
  applied             boolean not null default false,
  status              text not null default 'proposed',
                    -- 'proposed' | 'insufficient_data' | 'applied' | 'rejected'
  notes               text
);

CREATE TABLE IF NOT EXISTS ax_router.tuning_proposals (
  id                  uuid primary key default gen_random_uuid(),
  analysis_date       text not null,
  old_weights         jsonb not null,
  new_weights         jsonb not null,
  sample_size         integer not null,
  predictive_powers   jsonb not null,
  status              text not null default 'pending',
                    -- 'pending' -> operator review -> 'approved' | 'rejected'
                    -- apply-weights.js --confirm -> 'applied'
  created_at          timestamptz not null default now(),
  reviewed_at         timestamptz,
  reviewer            text,
  notes               text
);

CREATE INDEX IF NOT EXISTS tuning_history_run_at_idx    ON ax_router.tuning_history (run_at);
CREATE INDEX IF NOT EXISTS tuning_proposals_status_idx  ON ax_router.tuning_proposals (status);

ALTER TABLE ax_router.tuning_history    ENABLE ROW LEVEL SECURITY;
ALTER TABLE ax_router.tuning_proposals  ENABLE ROW LEVEL SECURITY;

GRANT SELECT, INSERT, UPDATE, DELETE ON ax_router.tuning_history   TO service_role;
GRANT SELECT, INSERT, UPDATE, DELETE ON ax_router.tuning_proposals TO service_role;

COMMIT;