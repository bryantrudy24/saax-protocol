// Migration verification: hit Docker PostgREST /rpc/acquire_idempotency with
// the service-role JWT from .env. Writes results to dump/verify-rpc.txt.
const fs = require('fs');
const path = require('path');

(async () => {
  const env = fs.readFileSync(path.join(__dirname, '..', '.env'), 'utf8');
  const key = (env.match(/^AX_POSTGREST_KEY=(.+)$/m) || [])[1]?.trim();
  if (!key) { fs.writeFileSync(path.join(__dirname, 'verify-rpc.txt'), 'NO KEY IN ENV'); process.exit(1); }
  const out = [];
  const base = 'http://localhost:3000';
  const h = { 'Content-Type': 'application/json', 'Accept-Profile': 'ax_router', 'Content-Profile': 'ax_router', 'Authorization': 'Bearer ' + key };

  // 1. first call: insert pending (fresh)
  const r1 = await fetch(base + '/rpc/acquire_idempotency', { method: 'POST', headers: h, body: JSON.stringify({ p_key: 'mig-probe-1', p_payload_hash: 'ph:probe', p_ttl_hours: 24 }) });
  out.push('CALL1 HTTP ' + r1.status + ' ' + (await r1.text()).slice(0, 200));

  // 2. same key same hash -> conflict (pending replay)
  const r2 = await fetch(base + '/rpc/acquire_idempotency', { method: 'POST', headers: h, body: JSON.stringify({ p_key: 'mig-probe-1', p_payload_hash: 'ph:probe', p_ttl_hours: 24 }) });
  out.push('CALL2 HTTP ' + r2.status + ' ' + (await r2.text()).slice(0, 200));

  // 3. same key DIFFERENT payload hash -> 422 (payload-hash mismatch via RAISE)
  const r3 = await fetch(base + '/rpc/acquire_idempotency', { method: 'POST', headers: h, body: JSON.stringify({ p_key: 'mig-probe-1', p_payload_hash: 'ph:DIFFERENT', p_ttl_hours: 24 }) });
  out.push('CALL3 HTTP ' + r3.status + ' ' + (await r3.text()).slice(0, 200));

  // 4. bare function-name resolution proof: /rpc/acquire_idempotency resolves
  //    (no schema-qualified name needed). Also prove table access + anon denied.
  const t1 = await fetch(base + '/idempotency_keys?select=key&key=eq.mig-probe-1', { headers: { 'Accept-Profile': 'ax_router', 'Authorization': 'Bearer ' + key } });
  out.push('TABLE GET HTTP ' + t1.status + ' ' + (await t1.text()).slice(0, 120));

  // cleanup probe row
  await fetch(base + '/idempotency_keys?key=eq.mig-probe-1', { method: 'DELETE', headers: { 'Accept-Profile': 'ax_router', 'Content-Profile': 'ax_router', 'Authorization': 'Bearer ' + key, Prefer: 'return=minimal' } });
  out.push('CLEANUP DELETE sent');

  fs.writeFileSync(path.join(__dirname, 'verify-rpc.txt'), out.join('\n'));
  console.log('done');
})().catch(e => { fs.writeFileSync(path.join(__dirname, 'verify-rpc.txt'), 'ERR ' + e.message); process.exit(1); });