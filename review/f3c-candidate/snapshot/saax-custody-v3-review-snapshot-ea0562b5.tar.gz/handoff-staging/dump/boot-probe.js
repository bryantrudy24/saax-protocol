// Start route-server with Docker env for 5s, capture its startup banner to prove
// whether the store client activates against Docker PostgREST.
const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');

const env = fs.readFileSync(path.join(__dirname, '..', '.env'), 'utf8');
const key = (env.match(/^AX_POSTGREST_KEY=(.+)$/m) || [])[1]?.trim();

const child = spawn(process.execPath, ['endpoint/route-server.js'], {
  cwd: path.join(__dirname, '..'),
  env: { ...process.env, POSTGREST_URL: 'http://localhost:3000', AX_POSTGREST_KEY: key, AX_PORT: '8499' },
  stdio: ['ignore', 'pipe', 'pipe'],
});
let out = '';
child.stdout.on('data', d => out += d);
child.stderr.on('data', d => out += d);
setTimeout(() => {
  child.kill();
  fs.writeFileSync(path.join(__dirname, 'boot-banner.txt'), out);
  console.log('captured');
}, 4000);