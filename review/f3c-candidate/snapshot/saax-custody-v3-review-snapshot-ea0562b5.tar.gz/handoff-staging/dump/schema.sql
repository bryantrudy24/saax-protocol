-- AX Router — Day 8 migration: schema.sql (ax_router schema on self-hosted Postgres)
-- Reconstructed from the live Supabase platform project via catalog inspection
-- (MCP connector), equivalent to `supabase db dump --schema` filtered output.
-- Includes: schema creation, tables, indexes, constraints, RLS + policies,
-- grants, sequence, and the acquire_idempotency RPC (with its execute grants).

BEGIN;

-- Schema ---------------------------------------------------------------
CREATE SCHEMA IF NOT EXISTS ax_router;

-- Tables -----------------------------------------------------------------
CREATE TABLE IF NOT EXISTS ax_router.agents (
    agent_id bigint NOT NULL,
    name text,
    description text,
    services jsonb DEFAULT '[]'::jsonb,
    supported_trust jsonb,
    active boolean DEFAULT true,
    owner text,
    token_uri text,
    block_number bigint,
    reputation_score bigint,
    feedback_count bigint,
    last_feedback_timestamp timestamptz,
    last_indexed timestamptz DEFAULT now(),
    CONSTRAINT agents_pkey PRIMARY KEY (agent_id)
);

CREATE TABLE IF NOT EXISTS ax_router.idempotency_keys (
    key text NOT NULL,
    status text NOT NULL DEFAULT 'pending'::text,
    payload_hash text,
    response_status integer,
    response_body text,
    created_at timestamptz NOT NULL DEFAULT now(),
    expires_at timestamptz NOT NULL DEFAULT (now() + '24:00:00'::interval),
    CONSTRAINT idempotency_keys_pkey PRIMARY KEY (key),
    CONSTRAINT idempotency_keys_status_check CHECK (status = ANY (ARRAY['pending'::text, 'verified'::text, 'settled'::text, 'failed'::text]))
);

CREATE TABLE IF NOT EXISTS ax_router.rate_limits (
    id bigint GENERATED ALWAYS AS IDENTITY NOT NULL,
    scope text NOT NULL,
    bucket_key text NOT NULL,
    ts timestamptz NOT NULL DEFAULT now(),
    expires_at timestamptz NOT NULL DEFAULT (now() + '00:05:00'::interval),
    CONSTRAINT rate_limits_pkey PRIMARY KEY (id),
    CONSTRAINT rate_limits_scope_check CHECK (scope = ANY (ARRAY['ip'::text, 'wallet'::text]))
);

-- Indexes ----------------------------------------------------------------
CREATE INDEX IF NOT EXISTS ax_router_agents_active_idx ON ax_router.agents USING btree (active);
CREATE INDEX IF NOT EXISTS ax_router_agents_name_idx ON ax_router.agents USING btree (lower(name));
CREATE INDEX IF NOT EXISTS rate_limits_scope_key_ts ON ax_router.rate_limits USING btree (scope, bucket_key, ts);

-- RLS (enabled + policies; service-role/owner bypasses RLS) ---------------
ALTER TABLE ax_router.agents ENABLE ROW LEVEL SECURITY;
ALTER TABLE ax_router.idempotency_keys ENABLE ROW LEVEL SECURITY;
ALTER TABLE ax_router.rate_limits ENABLE ROW LEVEL SECURITY;

-- agents: anon read policy (mirrors platform; the ranker/identity can read
-- the registry mirror without a service key). idempotency_keys and
-- rate_limits: ZERO policies (service-role only) — brief requirement.
DROP POLICY IF EXISTS agents_select_anon ON ax_router.agents;
CREATE POLICY agents_select_anon ON ax_router.agents FOR SELECT TO anon USING (true);

-- Grants ------------------------------------------------------------------
-- Authenticated/service-role write access per platform (kept minimal):
-- anon: SELECT agents; authenticated/service_role: idempotency_keys +
-- rate_limits DML. postgres (owner): all.
GRANT USAGE ON SCHEMA ax_router TO anon, authenticated, service_role;
GRANT SELECT ON ax_router.agents TO anon, authenticated, service_role;
GRANT SELECT, INSERT, UPDATE, DELETE ON ax_router.idempotency_keys TO authenticated, service_role;
GRANT SELECT, INSERT, UPDATE, DELETE ON ax_router.rate_limits TO authenticated, service_role;
GRANT USAGE, SELECT ON SEQUENCE ax_router.rate_limits_id_seq TO authenticated, service_role;

-- RPC: acquire_idempotency --------------------------------------------------
CREATE OR REPLACE FUNCTION ax_router.acquire_idempotency(p_key text, p_payload_hash text, p_ttl_hours integer)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
AS $function$
DECLARE
    row ax_router.idempotency_keys%ROWTYPE;
    key_hash bigint;
    outcome jsonb;
BEGIN
    key_hash := ('x' || substr(md5(p_key), 1, 16))::bit(64)::bigint;
    PERFORM pg_advisory_xact_lock(key_hash);
    SELECT * INTO row FROM ax_router.idempotency_keys WHERE key = p_key;
    IF row.key IS NULL THEN
        INSERT INTO ax_router.idempotency_keys (key, status, payload_hash, created_at, expires_at)
        VALUES (p_key, 'pending', p_payload_hash, now(), now() + make_interval(hours => p_ttl_hours));
        RETURN jsonb_build_object('conflict', false, 'status', 'pending');
    END IF;
    IF row.payload_hash IS NOT NULL AND row.payload_hash <> p_payload_hash THEN
        RAISE EXCEPTION 'payload hash mismatch: idempotency key reused for a different request';
    END IF;
    IF row.status = 'pending' THEN
        RETURN jsonb_build_object('conflict', true, 'status', 'pending');
    END IF;
    RETURN jsonb_build_object(
        'conflict', true,
        'status', row.status,
        'response_status', row.response_status,
        'response_body', row.response_body
    );
END;
$function$;

REVOKE ALL ON FUNCTION ax_router.acquire_idempotency(text, text, integer) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION ax_router.acquire_idempotency(text, text, integer) TO service_role;

-- The hourly TTL sweep: on Supabase platform this is a pg_cron job. In the
-- self-hosted container pg_cron isn't loaded; the in-process hourly
-- idempotency.sweepExpired()/ratelimit.sweepExpired() fallback covers it
-- (route-server starts the sweep when the store client is active). A
-- Postgres-side pg_cron can be added later if desired.

COMMIT;