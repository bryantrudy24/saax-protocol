// Run the four Day 8 harnesses against the Docker PostgREST store.
// Loads POSTGREST_URL + AX_POSTGREST_KEY from .env, spawns each harness with
// those env vars, captures output to dump/<suite>.txt. No code changes.
const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');

const env = fs.readFileSync(path.join(__dirname, '..', '.env'), 'utf8');
const key = (env.match(/^AX_POSTGREST_KEY=(.+)$/m) || [])[1]?.trim();
const postgrestUrl = (env.match(/^POSTGREST_URL=(.+)$/m) || [])[1]?.trim() || 'http://localhost:3000';
process.env.POSTGREST_URL = postgrestUrl;
process.env.AX_POSTGREST_KEY = key;

const suites = [
  { name: 'item1', file: 'endpoint/test-day8-item1.js' },
  { name: 'item2', file: 'endpoint/test-day8-item2.js' },
  { name: 'item3', file: 'endpoint/test-day8-item3.js' },
  { name: 'item4', file: 'endpoint/test-day8-item4.js' },
];

function runSuite(suite) {
  return new Promise((resolve) => {
    const child = spawn(process.execPath, [suite.file], {
      cwd: path.join(__dirname, '..'),
      env: {
        ...process.env,
        POSTGREST_URL: postgrestUrl,
        AX_POSTGREST_KEY: key,
        SUPABASE_URL: '', // force Docker path
        SUPABASE_SERVICE_ROLE_KEY: '',
      },
      stdio: ['ignore', 'pipe', 'pipe'],
    });
    let out = '';
    child.stdout.on('data', d => out += d);
    child.stderr.on('data', d => out += d);
    child.on('close', code => {
      fs.writeFileSync(path.join(__dirname, suite.name + '-docker.txt'), 'EXIT ' + code + '\n' + out);
      resolve({ name: suite.name, code });
    });
  });
}

(async () => {
  // Clean the store tables before the suites so cached rows from a previous
  // run never replay into a fresh test (mirrors a clean DB per run).
  const clean = require('../endpoint/store.js');
  const cli = clean.buildStoreClient();
  if (!cli) { console.log('WARN: no store client (env not loaded?) — suites will use in-memory'); return; }
  try { await cli.from('idempotency_keys').delete().gte('created_at', '2000-01-01T00:00:00Z'); } catch (e) { console.log('clean idem (skip): ' + e.message); }
  try { await cli.from('rate_limits').delete().gte('ts', '2000-01-01T00:00:00Z'); } catch (e) { console.log('clean rl (skip): ' + e.message); }
  console.log('store cleaned before suites');

  for (const s of suites) {
    const r = await runSuite(s);
    console.log(s.name + ' -> exit ' + r.code);
  }
  console.log('ALL DONE');
})().catch(e => { console.error('RUNNER FAILED', e); process.exit(1); });