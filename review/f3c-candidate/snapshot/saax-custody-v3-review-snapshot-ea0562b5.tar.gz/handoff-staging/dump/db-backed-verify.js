// DB-backed verification of Day 8 controls against Docker PostgREST.
// Revised: explicit exit, per-step try/catch so one failure never aborts the
// whole run before the report is written.
const fs = require('fs');
const path = require('path');

(async () => {
  const env = fs.readFileSync(path.join(__dirname, '..', '.env'), 'utf8');
  const key = (env.match(/^AX_POSTGREST_KEY=(.+)$/m) || [])[1]?.trim();
  process.env.POSTGREST_URL = 'http://localhost:3000';
  process.env.AX_POSTGREST_KEY = key;

  const out = [];
  const check = (n, c, d) => out.push((c ? 'PASS ' : 'FAIL ') + n + (d ? '  [' + d + ']' : ''));

  const idem = require('../endpoint/idempotency.js');
  const store = require('../endpoint/store.js');
  const rl = require('../endpoint/ratelimit.js');
  const ks = require('../endpoint/killswitch.js');
  const client = store.buildStoreClient();
  idem.setStoreClient(client);
  rl.setStoreClient(client);
  rl.ensureStoreMode(true);

  const k1 = 'db-verify-key-1';
  const h1 = 'ph:db-verify-1';

  // I1a fresh acquire
  try {
    const a1 = await idem.storeAcquire(k1, h1);
    check('I1 fresh acquire -> inserted/fresh', a1 === 'inserted' || (a1 && a1.conflict === false), JSON.stringify(a1));
  } catch (e) { check('I1 fresh acquire -> inserted/fresh', false, String(e.message || e)); }

  // I1b same key same hash -> conflict (pending)
  try {
    const a2 = await idem.storeAcquire(k1, h1);
    check('I1 pending acquire -> conflict (409 mapping)', a2 === 'conflict_pending' || (a2 && a2.conflict === true && a2.status === 'pending'), JSON.stringify(a2));
  } catch (e) { check('I1 pending acquire -> conflict (409 mapping)', false, String(e.message || e)); }

  // I1c different hash -> 422 mapping
  try {
    await idem.storeAcquire(k1, 'ph:DIFFERENT');
    check('I1 payload-hash mismatch -> 422 mapping', false, 'no throw');
  } catch (e) {
    check('I1 payload-hash mismatch -> 422 mapping', /payload hash mismatch/i.test(String(e.message || e)), String(e.message || e).slice(0, 80));
  }

  // I1d settle + replay -> cached response
  try {
    await client.from('idempotency_keys').update({ status: 'settled', response_status: 200, response_body: JSON.stringify({ status: 'ok', replay: true, txHash: 'mock-settled-1' }) }).eq('key', k1);
    const a3 = await idem.storeAcquire(k1, h1);
    check('I1 settled acquire -> cached response', a3 && a3.conflict === true && a3.status === 'settled' && a3.response_status === 200, JSON.stringify(a3));
  } catch (e) { check('I1 settled acquire -> cached response', false, String(e.message || e)); }

  // I2 rate-limit store
  try {
    await rl.supabaseRecord('ip', '203.0.113.99');
    const cntIp = await rl.supabaseCount('ip', '203.0.113.99', 60);
    check('I2 rate-limit store counts IP events', cntIp >= 1, 'cnt=' + cntIp);
  } catch (e) { check('I2 rate-limit store counts IP events', false, String(e.message || e)); }
  try {
    await rl.supabaseRecord('wallet', '0xDbVerifyWallet000000000000000000000000000001');
    const cntW = await rl.supabaseCount('wallet', '0xDbVerifyWallet000000000000000000000000000001', 60);
    check('I2 rate-limit store counts wallet events', cntW >= 1, 'cnt=' + cntW);
  } catch (e) { check('I2 rate-limit store counts wallet events', false, String(e.message || e)); }
  try {
    await rl.sweepExpired();
    check('I2 sweepExpired runs without error', true, '');
  } catch (e) { check('I2 sweepExpired runs without error', false, String(e.message || e)); }

  // I3 kill switch
  ks.setKillSwitch(true);
  const ksRes = ks.requireKillSwitch('live');
  check('I3 kill switch halts live with 503', ksRes.ok === false && ksRes.status === 503 && ksRes.body.reason === 'operator_kill_switch', JSON.stringify(ksRes.body));
  const ksMock = ks.requireKillSwitch('mock');
  check('I3 mock lane stays open under kill switch', ksMock.ok === true, JSON.stringify(ksMock));
  ks.setKillSwitch(null);

  // I4 bare-name RPC against Docker (mig probe; cleanup after)
  try {
    const rpcRes = await client.rpc('acquire_idempotency', { p_key: 'db-verify-rpc-probe', p_payload_hash: 'ph:rpc', p_ttl_hours: 24 });
    check('I4 bare rpc() resolves + inserts (no 404)', rpcRes.data && rpcRes.data.conflict === false && rpcRes.error === null, JSON.stringify(rpcRes.data || rpcRes.error));
  } catch (e) { check('I4 bare rpc() resolves + inserts (no 404)', false, String(e.message || e)); }

  // cleanup
  try { await client.from('idempotency_keys').delete().eq('key', k1); } catch (_) {}
  try { await client.from('idempotency_keys').delete().eq('key', 'db-verify-rpc-probe'); } catch (_) {}
  try { await client.from('rate_limits').delete().in('bucket_key', ['203.0.113.99', '0xDbVerifyWallet000000000000000000000000000001']); } catch (_) {}

  fs.writeFileSync(path.join(__dirname, 'db-backed-verify.txt'), out.join('\n'));
  process.exit(0);
})().catch(e => {
  try { fs.writeFileSync(path.join(__dirname, 'db-backed-verify.txt'), 'FATAL ' + (e.stack || e.message)); } catch (_) {}
  process.exit(1);
});