// Final store cleanup: empty idempotency_keys + rate_limits so the migrated
// store matches the source state (0 rows each). Test rows only.
const fs = require('fs');
const path = require('path');
(async () => {
  const env = fs.readFileSync(path.join(__dirname, '..', '.env'), 'utf8');
  const key = (env.match(/^AX_POSTGREST_KEY=(.+)$/m) || [])[1]?.trim();
  process.env.POSTGREST_URL = 'http://localhost:3000';
  process.env.AX_POSTGREST_KEY = key;
  const store = require('../endpoint/store.js');
  const cli = store.buildStoreClient();
  const r1 = await cli.from('idempotency_keys').delete().gte('created_at', '2000-01-01T00:00:00Z');
  const r2 = await cli.from('rate_limits').delete().gte('ts', '2000-01-01T00:00:00Z');
  console.log('idem delete error:', r1 && r1.error ? r1.error.message : 'none');
  console.log('rl delete error:', r2 && r2.error ? r2.error.message : 'none');
  process.exit(0);
})().catch(e => { console.error(e.message); process.exit(1); });