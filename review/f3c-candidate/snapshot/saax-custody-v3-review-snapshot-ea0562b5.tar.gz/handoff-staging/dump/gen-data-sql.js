// AX Router migration: emit dump/data.sql with full INSERT set from the local
// agents JSON. Run: node dump/gen-data-sql.js
const fs = require('fs');
const path = require('path');

const agents = JSON.parse(fs.readFileSync(path.join(__dirname, '..', 'data', 'agents-day1-named.json'), 'utf8'));
const cols = ['agent_id', 'name', 'description', 'services', 'supported_trust', 'active', 'owner', 'token_uri', 'block_number', 'reputation_score', 'feedback_count', 'last_feedback_timestamp', 'last_indexed'];

function lit(v) {
  if (v === null || v === undefined) return 'NULL';
  if (typeof v === 'boolean') return v ? 'TRUE' : 'FALSE';
  if (typeof v === 'object') return "'" + JSON.stringify(v).replace(/'/g, "''") + "'";
  if (typeof v === 'number') return String(v);
  return "'" + String(v).replace(/'/g, "''") + "'";
}

let out = `-- AX Router — Day 8 migration: data.sql (INSERT format)
-- Generated from data/agents-day1-named.json (runtime truth). Store tables
-- (idempotency_keys, rate_limits) are EMPTY at migration time (verified 0 rows
-- each; hourly cron swept test rows on the platform).
BEGIN;

INSERT INTO ax_router.agents (${cols.join(', ')}) VALUES
`;
const rows = agents.map(a => '(' + cols.map(c => lit(a[c])).join(', ') + ')');
out += rows.join(',\n') + ';\n\n';
out += `-- idempotency_keys + rate_limits: empty at migration time\n`;
out += `SELECT setval('ax_router.rate_limits_id_seq', 1, false);\nCOMMIT;\n`;

fs.writeFileSync(path.join(__dirname, 'data.sql'), out);
console.log('wrote dump/data.sql rows=' + rows.length + ' bytes=' + out.length);