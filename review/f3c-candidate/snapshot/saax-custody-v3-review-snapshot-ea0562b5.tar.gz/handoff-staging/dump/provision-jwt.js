// Provision AX_POSTGREST_KEY into .env without printing the JWT to the transcript.
// Reads POSTGREST_JWT_SECRET from .env, signs an HS256 JWT with role=service_role,
// and rewrites the AX_POSTGREST_KEY line in place.
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const envPath = path.join(__dirname, '..', '.env');
const env = fs.readFileSync(envPath, 'utf8');
const secret = (env.match(/^POSTGREST_JWT_SECRET=(.+)$/m) || [])[1]?.trim();
if (!secret) { console.error('NO SECRET'); process.exit(1); }

const header = Buffer.from(JSON.stringify({ alg: 'HS256', typ: 'JWT' })).toString('base64url');
const now = Math.floor(Date.now() / 1000);
const payload = Buffer.from(JSON.stringify({ role: 'service_role', iss: 'ax-router-selfhosted', iat: now, exp: now + 86400 * 365 })).toString('base64url');
const sig = crypto.createHmac('sha256', secret).update(header + '.' + payload).digest('base64url');
const jwt = header + '.' + payload + '.' + sig;

const patched = env.replace(/^AX_POSTGREST_KEY=.*$/m, 'AX_POSTGREST_KEY=' + jwt);
fs.writeFileSync(envPath, patched);
// verify it wrote (never print the value)
const after = fs.readFileSync(envPath, 'utf8');
const written = (after.match(/^AX_POSTGREST_KEY=(.+)$/m) || [])[1];
console.log('JWT provisioned:', written ? 'yes (' + written.split('.').length + ' parts, len ' + written.length + ')' : 'NO');