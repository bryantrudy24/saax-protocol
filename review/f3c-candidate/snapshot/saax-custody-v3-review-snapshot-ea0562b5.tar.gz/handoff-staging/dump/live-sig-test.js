// Live endpoint test (run from ax-router/): node --env-file=.env dump/live-sig-test.js
const http = require('http');
const x402 = require('../endpoint/x402.js');

const PORT = 8080;
const body = JSON.stringify({ capability: 'security scan', budget: 500, deadline: '2026-10-08' });

function makeSig() {
  const req = {
    scheme: 'exact',
    amount: x402.rawUnits(0.05),
    asset: x402.USDC_ADDRESS.base.toLowerCase(),
    networkName: 'base',
    network: x402.NETWORK_CAIP2.base,
    payTo: (process.env.AX_X402_PAYTO || '0x0000000000000000000000000000000000000001').toLowerCase(),
    maxTimeoutSeconds: 60,
  };
  const payload = x402.signMockPayload(req);
  return Buffer.from(JSON.stringify(payload)).toString('base64');
}

function request(headers) {
  return new Promise((resolve, reject) => {
    const req = http.request({ host: 'localhost', port: PORT, method: 'POST', path: '/route', headers }, res => {
      let data = '';
      res.on('data', c => data += c);
      res.on('end', () => resolve({ status: res.statusCode, body: data }));
    });
    req.on('error', reject);
    req.write(body);
    req.end();
  });
}

(async () => {
  const sig = makeSig();
  console.log('sig length:', sig.length);
  const noHeader = await request({ 'Content-Type': 'application/json' });
  console.log('no header ->', noHeader.status, noHeader.body.slice(0, 120));
  const withHeader = await request({ 'Content-Type': 'application/json', 'payment-signature': sig });
  console.log('with header ->', withHeader.status);
  console.log('body:', withHeader.body.slice(0, 600));
  process.exit(0);
})().catch(e => { console.error('FAIL', e); process.exit(1); });