// AX Router — Day 4/5 + Day 8 + Day 11: Demand Intake Endpoint (mock x402 mode)
//
// HTTP POST /route
//   Accepts:  { capability, budget, deadline }
//   Returns:  x402 v2 payment challenge (402) without a valid payment header,
//             or ranked + ROUTED supplier matches with settlement receipts
//             when a valid payment signature is presented.
//
// DAY 5 — PAYMENT ROUTING LOGIC (MOCK MODE)
//   - After ranking, every matched supplier is routed through the decision
//     tree (endpoint/router.js): x402 (payTo + USDC on base/polygon/solana) |
//     mpp (fiat/Stripe-native) | unsupported (excluded from the match list).
//   - x402 suppliers are settled through the mock signing/verification path
//     (endpoint/x402.js, exact scheme for fixed-price, upto for usage-based),
//     returning receipts whose structure matches the documented LIVE receipt
//     structure field-for-field.
//   - MPP suppliers are stubbed: { rail: "mpp", status: "stubbed", reason:
//     "Sprint 1 mock mode" }. mppx is NOT installed; Stripe rails are NOT
//     configured (Day 7+ items).
//   - AX_X402_VERIFY_MODE=mock (default) accepts mock signatures; "live" re-
//     verifies the real ECDSA signature (inert until the wallet is connected).
//
// PRE-DAY 5 FIX 1: payment header validation is no longer "accept anything":
//   a PAYMENT-SIGNATURE header (base64 x402 V2 payload) is parsed structurally
//   and verified through the mock branch; the legacy x-x402-mock: mock header
//   is still accepted for compatibility and is also run through verification.
//
// PRE-DAY 5 FIX 2 (flag only, no build): buyer reputation input trusts the
//   x-mock-buyer-rep client header in Sprint 1. Live, it MUST come from a
//   verified source: (a) x402 payment payload signature resolving to an
//   on-chain agent identity, or (b) a signed request from the buyer's wallet.
//   Day 7 checklist item. See daily-logs/day7-wallet-checklist.md.
//
// SECURITY GATE (operator constraint, non-negotiable):
//   All demand request text is UNTRUSTED INPUT. The capability field is
//   sanitized at the HTTP boundary BEFORE any specialist/ranking logic sees
//   it. If sanitization empties the field, the request is rejected (422).
//   Payment payloads are untrusted input: parsed structurally, never executed.
//   Supplier payTo addresses fail format validation -> supplier excluded.
//
// DAY 8 — PRE-LIVE SECURITY CONTROLS (see daily-logs/day8-log.md):
//   GATE ORDER (new, strictly earliest-first):
//     1. KILL SWITCH  (endpoint/killswitch.js)   — AX_KILL_SWITCH / AX_KILL_SWITCH_FILE
//        Runs FIRST, before EVERYTHING (idempotency, rate limit, sanitization,
//        signature, on-chain, amount). Live verify + switch ON -> 503 halted.
//        Mock lane stays open (kill switch stops LIVE processing, not mock
//        testing).
//     2. RATE LIMIT   (endpoint/ratelimit.js)    — AX_RATE_LIMIT_{IP,WALLET}[,_WINDOW]
//        Two-tier sliding window (ip 60/min, wallet 30/min) BEFORE sanitization.
//        429 + Retry-After. No exemptions.
//     3. IDEMPOTENCY  (endpoint/idempotency.js)  — Idempotency-Key header or
//        deterministic derived key. verified/settled -> cached response;
//        pending -> 409; different payload hash -> 422. TTL 24h, hourly sweep.
//     4. SANITIZATION (existing gate, unchanged) — 422 on empty/injection.
//     5. PAYMENT VERIFICATION (existing x402 path, unchanged).
//     6. BUYER REPUTATION (endpoint/identity.js) — live: from the verified x402
//        signer address via IdentityRegistry reverse lookup + ReputationRegistry
//        (Path (a), operator-confirmed); mock: x-mock-buyer-rep header kept as
//        a stand-in. Live mode IGNORES the header. See §9/§6 of the checklist.
//     7. RANKING -> ROUTING -> SETTLEMENT (unchanged).
//
//   Regression contract (NOT optional): Day 5 unit 26/26, Day 5 E2E 17/17,
//   Day 6 unit 21/21, Day 7 E2E 4/4 must all still pass.
//
// Hosting: local station HTTP server (Vercel reauth pending). Reproduce with:
//   node endpoint/route-server.js            (port 8080 default, AX_PORT to override)
//   curl -X POST localhost:8080/route -H "Content-Type: application/json" -d "{\"capability\":\"security scan\",\"budget\":500,\"deadline\":\"2026-10-08\"}"
const http = require('http');
const fs = require('fs');
const path = require('path');
const { JsonRpcProvider, Contract } = require('ethers');

const x402 = require('./x402.js');
const gateway = require('./gateway.js'); // Day 9: self-hosted x402 gateway (AX_X402_MODE=self)
// Day 11 (Item 3/4): commitment lifecycle leaf modules (loaded through the
// gateway facade so the rail registry is a single seam — see gateway.js).
const commitmentMod = require('./commitment.js');
const requirementMod = require('./requirement.js');
const receiptMod = require('./receipt.js');
const railsMod = require('./rails/index.js');
const railsX402 = require('./rails/x402.js');
const router = require('./router.js');
const settle = require('./settle.js');
const killswitch = require('./killswitch.js');
const ratelimit = require('./ratelimit.js');
const idempotency = require('./idempotency.js');
const identity = require('./identity.js');
const store = require('./store.js');
const outcomeLog = require('./outcome-log.js');

// ---- Config (mirrors rank-suppliers.js; single swap point for Day 5) ------
const PORT = Number(process.env.AX_PORT || 8080);
const AX_PRICE_SCORE_DEFAULT = Number(process.env.AX_PRICE_SCORE_DEFAULT || 50);
const AX_FRESHNESS_STRATEGY  = process.env.AX_FRESHNESS_STRATEGY || 'count_proxy';
const AX_CAPABILITY_FLOOR    = Number(process.env.AX_CAPABILITY_FLOOR || 0.4);
const RPC = process.env.AX_RPC_URL || 'https://base-rpc.publicnode.com';
const REPUTATION_REGISTRY = process.env.AX_REPUTATION_REGISTRY || '0x8004BAa17C55a88189AE136b182e5fdA19dE9b63';

// ---- Day 9: self-hosted gateway mode ----------------------------------------
// AX_X402_MODE=self selects the self-hosted x402 gateway (verify + settle
// against Base Sepolia directly). Default mock keeps the existing lane.
const SELF_MODE = gateway.getMode() === 'self';

// ---- Day 8: persistent store wiring ------------------------------------------
// Supabase when configured (SUPABASE_URL + service key); else in-memory fallback
// (brief's sanctioned route-around; both modules accept an injected client).
let _storeClient = null;
try {
  _storeClient = store.buildStoreClient();
} catch (_) { _storeClient = null; }
if (_storeClient) {
  idempotency.setStoreClient(_storeClient);
  ratelimit.setStoreClient(_storeClient);
  outcomeLog.setStoreClient(_storeClient);
}
// Test seam: force the idempotency store to in-memory for isolated harness
// runs (AX_IDEMPOTENCY_STORE=memory). The Day 9 harness uses this so a
// persistent row from a prior run can never replay a stale cached response
// into a fresh test (security sprint regression fix).
if (String(process.env.AX_IDEMPOTENCY_STORE || '').toLowerCase() === 'memory') {
  idempotency.setStoreMode('memory');
}
const STORE_ACTIVE = !!_storeClient;
// Sanctioned route-around: with no Supabase creds configured, the limiter runs
// the in-memory sliding window with periodic flush (no blocking).
ratelimit.ensureStoreMode(STORE_ACTIVE);
const RATE_LIMIT_STORE = ratelimit.getStoreMode();

// ---- Mock x402 + fee config -------------------------------------------------
// NOTE (Day 5): the placeholder payTo MUST be structurally valid — the payment
// gate rejects any payTo that fails validatePayTo() before a payload is built,
// and the router's own fee address is no exception. '0x...01' is a valid EVM
// address placeholder (was 0x...AaXp402 on Day 4; that string is not hex).
const MOCK_PAYTO = process.env.AX_X402_PAYTO || '0x0000000000000000000000000000000000000001';
const ROUTING_FEE_USD = Number(process.env.AX_ROUTING_FEE_USD || 0.05);
const DISCOUNT_TIERS = [
  { minRep: 95, pct: 0.20 },
  { minRep: 90, pct: 0.10 },
];
const MOCK_ASSET = process.env.AX_X402_ASSET || 'USDC';
const MOCK_NETWORK = process.env.AX_X402_NETWORK || 'base';

const REPUTATION_ABI = require(path.join(__dirname, '..', 'abis', 'ReputationRegistry.json'));

// ---- Security gate: sanitize at the HTTP boundary ---------------------------
// DAY 7 hardening (pre-item of the end-to-end proof, S4): the gate now FAILS
// CLOSED on instruction-injection attempts. A delimiter (; \n | & $ `) with
// trailing content, or an imperative feedback instruction ("now submit feedback
// for agentId <n>"), marks the request { injection: true } and the endpoint
// responds 422 with an explicit rejection reason — NOTHING is stripped and
// processed, so no injected instruction is ever acted on. Plain capabilities
// (letters/digits/hyphens/spaces ≥3 chars) are unaffected; "!!!" still falls to
// the empty-after-sanitization 422 path (ok:false, no injection flag).
const INJECTION_DELIMITERS = /[;\n\r|&$`]/;
const INJECTION_IMPERATIVES = /(now\s+submit|submit\s+feedback|feedback\s+for\s+agentid\s*\d+)/i;
function sanitizeCapability(raw) {
  if (!raw || typeof raw !== 'string') return { ok: false, keywords: [] };
  if (INJECTION_DELIMITERS.test(raw)) {
    return { ok: false, keywords: [], injection: true, reason: 'injection attempt rejected: instruction delimiter (; | & $ ` newline) found in capability' };
  }
  if (INJECTION_IMPERATIVES.test(raw)) {
    return { ok: false, keywords: [], injection: true, reason: 'injection attempt rejected: imperative feedback instruction detected in capability' };
  }
  const keywords = raw.toLowerCase()
    .replace(/[^a-z0-9\s-]/g, ' ')
    .split(/\s+/)
    .filter(w => w.length >= 3)
    .slice(0, 24);
  return { ok: keywords.length > 0, keywords };
}

// ---- Day 2 layer: buyer reputation via ReputationRegistry -------------------
// (unchanged from Day 4; Sprint 1 discount tiers read the x-mock-buyer-rep
// header — see PRE-DAY 5 FIX 2 flag above.)
async function getBuyerReputation(buyerAddress) {
  if (!buyerAddress || !/^0x[a-fA-F0-9]{40}$/.test(buyerAddress)) {
    return { reputation: null, note: 'no buyer address; no discount' };
  }
  try {
    const provider = new JsonRpcProvider(RPC);
    const rep = new Contract(REPUTATION_REGISTRY, REPUTATION_ABI, provider);
    return { reputation: null, note: 'buyer reputation not available on-chain; test tiers via AX_MOCK_BUYER_REP' };
  } catch (e) {
    return { reputation: null, note: 'rep lookup failed: ' + String(e) };
  }
}

// ---- Discount decision path (loggable) ---------------------------------------
function computeFee(buyerRep, log) {
  const decision = { baseFeeUsd: ROUTING_FEE_USD, discountPct: 0, finalFeeUsd: ROUTING_FEE_USD };
  if (buyerRep && buyerRep.reputation != null) {
    for (const tier of DISCOUNT_TIERS) {
      if (buyerRep.reputation >= tier.minRep) {
        decision.discountPct = tier.pct;
        break;
      }
    }
    if (decision.discountPct > 0) {
      decision.finalFeeUsd = Math.round(ROUTING_FEE_USD * (1 - decision.discountPct) * 1e6) / 1e6;
      decision.log = `buyer rep ${buyerRep.reputation} >= ${decision.discountPct === 0.2 ? 95 : 90} -> ${Math.round(decision.discountPct * 100)}% off`;
    } else {
      decision.log = `buyer rep ${buyerRep.reputation} below 90 -> no discount`;
    }
  } else {
    decision.log = buyerRep && buyerRep.note ? buyerRep.note : 'no buyer reputation data -> no discount';
  }
  if (log) log.push(decision.log);
  return decision;
}

// ---- x402 v2 challenge ---------------------------------------------------------
function buildChallenge() {
  return {
    error: '402 Payment Required',
    scheme: 'x402',
    network: MOCK_NETWORK,
    accepts: [{
      scheme: 'x402',
      network: MOCK_NETWORK,
      maxAmountRequired: ROUTING_FEE_USD,
      payTo: MOCK_PAYTO,
      asset: MOCK_ASSET,
      resource: 'urn:ax-router:route:v1',
      schemes: ['exact', 'upto'], // Day 5: fixed-price (exact) + usage-based (upto)
    }],
  };
}

// ---- Payload validation --------------------------------------------------------
function parsePayload(body) {
  let raw;
  try { raw = JSON.parse(body); }
  catch (_) { return { error: 'invalid json' }; }
  if (!raw || typeof raw !== 'object') return { error: 'body must be a JSON object' };
  const capability = raw.capability || '';
  const budget = raw.budget;
  const deadline = raw.deadline;
  if (typeof capability !== 'string') return { error: 'capability must be a string' };
  // Demand request fields are sanitized at the HTTP boundary (security sprint
  // Item 2). budget must be a finite number or numeric string (or absent);
  // deadline must be a valid ISO/YYYY-MM-DD date or a numeric timestamp (or
  // absent). Anything else -> 422, before any ranking/idempotency logic sees it.
  if (budget !== undefined && budget !== null) {
    const isNum = (typeof budget === 'number' && Number.isFinite(budget)) ||
      (typeof budget === 'string' && /^\d+(\.\d+)?$/.test(budget.trim()));
    if (!isNum) return { error: 'budget must be a finite number' };
  }
  if (deadline !== undefined && deadline !== null) {
    const isDate = typeof deadline === 'string' && (
      /^\d{4}-\d{2}-\d{2}$/.test(deadline) ||
      !isNaN(Date.parse(deadline))
    );
    const isTs = (typeof deadline === 'number' && Number.isFinite(deadline)) ||
      (typeof deadline === 'string' && /^\d{10,13}$/.test(deadline.trim()));
    if (!isDate && !isTs) return { error: 'deadline must be a valid date or timestamp' };
  }
  return { capability, budget, deadline };
}

// ---- Ranking (imports Day 3 engine; sanitization is re-applied inside) ------
const { buildRanker } = require(path.join(__dirname, '..', 'scripts', 'rank-suppliers.js'));

function loadLocal() {
  const agents = JSON.parse(fs.readFileSync(path.join(__dirname, '..', 'data', 'agents-day1-named.json'), 'utf8'));
  let rep;
  try { rep = JSON.parse(fs.readFileSync(path.join(__dirname, '..', 'data', 'reputation-day3.json'), 'utf8')); }
  catch (_) { rep = JSON.parse(fs.readFileSync(path.join(__dirname, '..', 'data', 'reputation-day2.json'), 'utf8')); }
  const repMap = {};
  for (const r of (Array.isArray(rep) ? rep : Object.values(rep))) repMap[r.agent_id] = r;
  let leaderboard = [];
  try { leaderboard = JSON.parse(fs.readFileSync(path.join(__dirname, '..', 'data', 'leaderboard-suppliers-day3.json'), 'utf8')); } catch (_) {}
  for (const agent of leaderboard) {
    if (agent.reputation_probe && !repMap[agent.agent_id]) {
      repMap[agent.agent_id] = { agent_id: agent.agent_id, clients: agent.reputation_probe.clients || 0, count: agent.reputation_probe.count || 0, avgX100: agent.reputation_probe.avgX100 };
    }
  }
  return { agents, repMap, leaderboard };
}

const state = loadLocal();
const ranker = buildRanker({ agents: state.agents, repMap: state.repMap, leaderboard: state.leaderboard });
const registrations = router.loadRegistrations();

// ---- Day 11 (Item 3): register the x402 rail once ----------------------------
// The rail registry is the settlement-method-neutral seam: x402 is registered
// now; mpp/entitlement stubs exist with complete interfaces but are NOT
// registered (registration is the operator's explicit opt-in for a live rail).
try {
  railsMod.register('x402', railsX402);
} catch (e) {
  console.error('rails.register(x402) failed: ' + (e.message || e));
}

// ---- Day 12 (Item 3): register the MPP rail once -----------------------------
// MPP is the second registered settlement rail: the mppx-backed implementation
// (endpoint/rails/mpp.js). When mppx is installed this registers the live rail
// so the dual-challenge gateway advertises both x402 and MPP; a missing mppx
// (or a broken install) degrades to x402-only rather than crashing the server.
if (!railsMod.resolve('mpp')) {
  try {
    // eslint-disable-next-line global-require
    const railsMpp = require('./rails/mpp.js');
    railsMod.register('mpp', railsMpp);
    let mppxVersion = '?';
    try { mppxVersion = require('mppx/package.json').version; } catch (e) { /* exports map blocks the subpath; fall back to a static read */ }
    console.error('rails.register(mpp) OK — MPP rail live (mppx ' + mppxVersion + ')');
  } catch (e) {
    console.error('rails.register(mpp) failed (x402-only mode): ' + (e.message || e));
  }
}

// ---- Server ----------------------------------------------------------------------
function clientIp(req) {
  // Only trust X-Forwarded-For when a trusted proxy is explicitly configured
  // (AX_TRUST_PROXY=true). Otherwise a client can spoof the header to rotate
  // identities and bypass the per-IP rate limit (security sprint Item 3).
  if (process.env.AX_TRUST_PROXY === 'true' || process.env.AX_TRUST_PROXY === '1') {
    const xff = req.headers['x-forwarded-for'];
    if (xff) {
      const first = String(xff).split(',')[0].trim();
      if (first) return first;
    }
  }
  return (req.socket && req.socket.remoteAddress) || '127.0.0.1';
}

// Wallet address from the x402 payload (or legacy mock header), used for the
// per-wallet rate-limit tier AND for reputation resolution.
function walletFromReq(req) {
  const legacy = (req.headers['x-x402-mock'] || '').trim();
  if (legacy === 'mock') {
    return process.env.AX_X402_MOCK_FROM || '0x0000000000000000000000000000000000000001';
  }
  const sig = (req.headers['payment-signature'] || '').trim();
  if (!sig) return null;
  const parsed = (gateway.getMode() === 'self' ? gateway : x402).parsePaymentSignatureHeader(sig);
  if (!parsed.ok || !parsed.payload || !parsed.payload.payload) return null;
  const auth = parsed.payload.payload.authorization || {};
  return String(auth.from || '').toLowerCase() || null;
}

async function handleRoute(req, res, body) {
  const log = [];

  // ---- DAY 8 GATES (earliest-first; the kill switch is THE first gate) -------
  // 1. KILL SWITCH — before BODY PARSING, before idempotency, before rate
  //    limiting, before sanitization, before signature/on-chain/amount. Live
  //    verify + switch ON -> 503 halted; mock lane stays open (kill switch
  //    stops live processing, not mock testing). A halted server answers 503
  //    even to a malformed body — no request content is processed or echoed.
  const verifyModeNow = x402.getVerifyMode();
  // Day 9: in self mode settlement is REAL (broadcast to Base Sepolia) — the
  // kill switch must treat it as live, not as the mock testing lane.
  const ksMode = SELF_MODE ? 'live' : verifyModeNow;
  const ks = killswitch.requireKillSwitch(ksMode);
  if (!ks.ok) {
    log.push('KILL SWITCH: ' + JSON.stringify(ks.body) + ' (verify mode=' + verifyModeNow + ', gateway mode=' + gateway.getMode() + ')');
    res.writeHead(ks.status, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify(ks.body));
    return;
  }
  if (ks.note) log.push(ks.note);

  // Body parse happens AFTER the kill switch (the emergency brake must never
  // have to wait on request parsing). budget/deadline are sanitized at the
  // HTTP boundary here, before any ranking/idempotency logic sees them
  // (security sprint Item 2: demand request fields sanitized; empty or
  // injection-containing fields return 422).
  const payload = parsePayload(body);
  if (payload.error) {
    res.writeHead(400, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ error: payload.error }));
    return;
  }

  // 2. RATE LIMIT — two-tier sliding window BEFORE sanitization and payment
  //    verification. 429 + Retry-After. No exemptions (the operator's own
  //    test wallet obeys; raise the limit, never exempt).
  const ipNow = clientIp(req);
  const walletNow = walletFromReq(req);
  const rl = await ratelimit.checkAndRecord(ipNow, walletNow);
  if (!rl.ok) {
    log.push('RATE LIMIT: ' + rl.limitType + ' tier exceeded (' + rl.counts[rl.limitType] + ' in window) -> 429, retry-after ' + rl.retryAfterSeconds);
    res.writeHead(429, { 'Content-Type': 'application/json', 'Retry-After': String(rl.retryAfterSeconds) });
    res.end(JSON.stringify({
      error: 'too many requests',
      limitType: rl.limitType,
      retryAfterSeconds: rl.retryAfterSeconds,
      limit: ratelimit.limitsFor(rl.limitType).limit,
    }));
    return;
  }
  if (rl.errors && rl.errors.length) log.push('RATE LIMIT store warning (fail-open): ' + rl.errors.join('; '));

  // 3. IDEMPOTENCY — key from header or derived deterministic key; checked
  //    BEFORE payment verification. verified/settled -> cached response,
  //    pending -> 409, payload-hash mismatch -> 422.
  //
  //    IMPORTANT (Day 8 fix): a request with NO payment signature (bare 402
  //    challenge probe) has nothing to duplicate — acquiring a key for it would
  //    poison the key with a 'pending' row that never settles and 409s the next
  //    legitimate attempt. The idempotency gate therefore only activates when a
  //    payment header (or legacy mock header) is PRESENT. This preserves the
  //    brief's ordering (idempotency BEFORE verification) while keeping the
  //    challenge path idempotency-neutral.
  const hasPaymentHeader = !!(req.headers['payment-signature'] || req.headers['x-x402-mock'] === 'mock');
  // Day 9 (Item 4): in self mode the idempotency key is bound to the EIP-3009
  // nonce — hash(nonce) — so a re-presented signed authorization under ANY
  // request identifier collides with the settled/pending row (replay-safe).
  // The nonce is extracted from the payment header BEFORE the idempotency gate.
  let nonceBoundKeyOverride = null;
  if (SELF_MODE && req.headers['payment-signature']) {
    const parsedNonce = gateway.parsePaymentSignatureHeader(req.headers['payment-signature']);
    if (parsedNonce.ok && parsedNonce.payload && parsedNonce.payload.payload &&
        parsedNonce.payload.payload.authorization && parsedNonce.payload.payload.authorization.nonce) {
      nonceBoundKeyOverride = gateway.nonceIdempotencyKey(parsedNonce.payload.payload.authorization.nonce);
    }
  }
  const idemCtx = {
    payload,
    buyerAddress: walletNow,
    nonce: (payload.deadline ? String(payload.deadline) : '') + ':' + (payload.budget === undefined ? '' : String(payload.budget)),
    // Fee-affecting input: the mock buyer-rep header changes the response fee,
    // so it must be part of the derived-key identity (regression fix — without
    // it, a rep-bearing retry would replay a no-rep cached response).
    extra: req.headers['x-mock-buyer-rep'] ? String(req.headers['x-mock-buyer-rep']).trim() : '',
  };
  let idem = { ok: true, key: null, fresh: false, derived: false };
  if (hasPaymentHeader) {
    // Day 9 (Item 4): when a nonce-bound key was derived above, it OVERRIDES
    // the client-supplied/derived key so replay protection is anchored to the
    // EIP-3009 nonce, not to an attacker-supplied header. Pass it via a
    // synthetic header the gate prefers (nonce-bound keys are authoritative in
    // self mode — see gateway.nonceIdempotencyKey).
    if (nonceBoundKeyOverride) {
      idem = await idempotency.idempotencyGate({
        ...req,
        headers: { ...req.headers, 'idempotency-key': nonceBoundKeyOverride },
      }, idemCtx);
      idem.derived = true; // nonce-bound keys are server-derived, not client-supplied
    } else {
      idem = await idempotency.idempotencyGate(req, idemCtx);
    }
  } else {
    log.push('IDEMPOTENCY: no payment header -> challenge probe, idempotency-neutral');
  }
  if (!idem.ok) {
    if (idem.status === 409) {
      log.push('IDEMPOTENCY: key ' + idem.key + ' in flight -> 409');
      res.writeHead(409, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: 'conflict', idempotencyKey: idem.key, reason: idem.reason || 'request with this idempotency key is still in flight' }));
      return;
    }
    if (idem.status === 422) {
      log.push('IDEMPOTENCY: key ' + idem.key + ' payload hash mismatch -> 422');
      res.writeHead(422, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: 'unprocessable', idempotencyKey: idem.key, reason: idem.reason || 'idempotency key reused with a different payload' }));
      return;
    }
    if (idem.status === 503) {
      // Store unavailable -> fail open with warning (no blocking). Still derive
      // a deterministic key for logging.
      log.push('IDEMPOTENCY store unavailable (fail-open): ' + (idem.reason || ''));
    } else if (idem.cached) {
      log.push('IDEMPOTENCY: key ' + idem.key + ' replayed -> cached response ' + idem.cached.status);
      res.writeHead(idem.cached.status || 200, { 'Content-Type': 'application/json' });
      res.end(idem.cached.body || JSON.stringify({ status: 'ok', replay: true, idempotencyKey: idem.key }));
      return;
    } else {
      log.push('IDEMPOTENCY: unexpected gate result for ' + idem.key + ' -> ' + JSON.stringify(idem));
    }
  }
  const idemKeyNow = idem.key || null;
  if (idem.fresh) log.push('IDEMPOTENCY: fresh key ' + idemKeyNow + (idem.derived ? ' (derived deterministically)' : ' (client-supplied)'));

  // SECURITY GATE: sanitize capability at the boundary. Reject if empty OR if
  // an injection attempt is detected (Day 7: fail closed, nothing stripped and
  // processed — see sanitizeCapability).
  const sanitized = sanitizeCapability(payload.capability);
  if (sanitized.injection) {
    log.push('SECURITY GATE: ' + sanitized.reason + ' -> 422');
    res.writeHead(422, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ error: 'security gate: ' + sanitized.reason }));
    return;
  }
  if (!sanitized.ok) {
    log.push('SECURITY GATE: capability field empty after sanitization -> 422');
    res.writeHead(422, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ error: 'capability field empty after sanitization' }));
    return;
  }

  // ---- DAY 11 (Item 4): GOVERNED COMMITMENT FLOW ---------------------------
  // The commitment (Trade Manifest) is issued BEFORE any payment challenge.
  // It binds the TERMS (capability, price, acceptance criteria, deadline,
  // cancel condition) and carries NO rail, NO credential, NO settlement
  // reference — the settlement method S that realises the neutral requirement
  // R is resolved at execution time (IETF draft, R/S separation; x402 is no
  // longer mandatory). All Day 8 controls above (kill switch -> rate limit ->
  // idempotency -> sanitization) remain in force and in the same order.
  //
  // buyer: from the verified payment signature when present, else the legacy
  // mock header, else a per-request placeholder. seller: the router's fee
  // address (the commitment is issued for the DEMAND — the seller wallet is
  // resolved at settlement time from the rail).
  const commitmentBuyer = walletFromReq(req) || (process.env.AX_X402_MOCK_FROM || '0x0000000000000000000000000000000000000001').toLowerCase();
  let commitmentFlowCtx = null;
  try {
    commitmentFlowCtx = gateway.commitmentFlow.issueFromPayload({
      buyer: commitmentBuyer,
      seller: SELF_MODE ? (gateway.getSellerAddress() || MOCK_PAYTO) : MOCK_PAYTO,
      capability: payload.capability,
      deadline: payload.deadline || '2026-10-05T12:00:00Z',
      amountRaw: String(x402.rawUnits(ROUTING_FEE_USD)),
      currency: 'USDC',
    });
    log.push('COMMITMENT: issued manifest ' + commitmentFlowCtx.manifest.commitmentId + ' (manifestHash=' + commitmentFlowCtx.manifest.manifestHash + ', R.eta=' + commitmentFlowCtx.requirement.eta + ')');
  } catch (e) {
    // A commitment that cannot be issued fails CLOSED (500) — no payment
    // challenge is ever presented without a governing commitment.
    log.push('COMMITMENT FAILED: ' + (e.message || e));
    res.writeHead(500, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ error: 'commitment issuance failed', reason: String(e.message || e).slice(0, 300) }));
    return;
  }

  // Payment signature present? (Day 5: PAYMENT-SIGNATURE base64 header, or the
  // legacy x-x402-mock: mock header). Both run through the verification path.
  const sigHeader = req.headers['payment-signature'] || '';
  const legacyMock = req.headers['x-x402-mock'] || '';
  let paymentVerified = false;
  let paymentMode = null;
  let paymentPayload = null;
  let paymentRejectReason = null;

  // ---- DAY 12 (Item 3): MPP credential detection ----------------------------
  // The dual-challenge gateway accepts EITHER credential format:
  //   x402:  PAYMENT-SIGNATURE header (existing branch below)
  //   MPP:   Authorization: Payment <base64url JSON credential>
  // MPP credentials are routed to the mpp rail's validate() against the
  // neutral requirement R (the same R every rail realises). The x402 branch
  // remains fully intact for PAYMENT-SIGNATURE (and the x-x402-mock compat).
  const authzHeader = req.headers['authorization'] || '';
  let mppCredential = null;
  if (!paymentVerified && railsMod.resolve('mpp') && authzHeader && /^payment\s/i.test(authzHeader)) {
    const railsMpp = railsMod.resolve('mpp');
    mppCredential = railsMpp.parseCredentialHeader(authzHeader);
    if (!mppCredential) {
      paymentRejectReason = 'Malformed MPP credential (Authorization: Payment)';
      log.push('MPP credential malformed: ' + paymentRejectReason);
    } else {
      // Validate against the requirement R (which carries amt/cur/payee). In
      // the commitment flow, R is the neutral requirement; otherwise we build
      // a synthetic one from the route fee defaults (same shape as x402).
      const R = (commitmentFlowCtx && commitmentFlowCtx.requirement) || {
        amt: gateway.rawUnits(ROUTING_FEE_USD),
        cur: 'USDC',
        payee: gateway.getSellerAddress() || MOCK_PAYTO,
        scheme: 'Payment',
        eta: 'eta_' + Date.now(),
        t_exp: new Date(Date.now() + 120000).toISOString(),
      };
      try {
        const ok = await railsMpp.validate(mppCredential, R);
        if (ok === true) {
          paymentVerified = true;
          paymentMode = 'mpp';
          paymentPayload = mppCredential;
          log.push('MPP credential verified through mpp rail (challenge=' + (mppCredential.challenge && mppCredential.challenge.id || '?') + ')');
        } else {
          paymentRejectReason = 'MPP credential validation failed';
          log.push('MPP credential rejected: ' + paymentRejectReason);
        }
      } catch (verr) {
        paymentRejectReason = 'MPP credential validation error: ' + String(verr.message || verr).slice(0, 160);
        log.push('MPP credential validation error: ' + paymentRejectReason);
      }
    }
  }

  if (!paymentVerified && legacyMock === 'mock') {
    paymentVerified = true;
    paymentMode = 'mock';
    log.push('legacy x-x402-mock header accepted (compat; verified=true in mock mode)');
  } else if (!paymentVerified && gateway.getMode() === 'self' && sigHeader) {
    // ---- DAY 9 SELF-HOSTED GATEWAY BRANCH (AX_X402_MODE=self) --------------
    // Full EIP-712/EIP-3009 verification via viem against Base Sepolia. The
    // seller wallet must be provisioned (AX_SELLER_PRIVATE_KEY/ADDRESS); the
    // challenge is built from the gateway (network eip155:84532, USDC Base
    // Sepolia, payTo seller wallet, scheme exact, facilitator self).
    const parsed = gateway.parsePaymentSignatureHeader(sigHeader);
    if (!parsed.ok) {
      paymentRejectReason = parsed.reason;
      log.push('payment signature malformed (self): ' + parsed.reason);
    } else {
      const reqForVerify = {
        scheme: 'exact',
        usd: ROUTING_FEE_USD,
        amount: gateway.rawUnits(ROUTING_FEE_USD),
        asset: gateway.USDC_BASE_SEPOLIA,
        network: gateway.NETWORK_CAIP2_BASE_SEPOLIA,
        networkName: 'base-sepolia',
        payTo: gateway.getSellerAddress() || MOCK_PAYTO,
        maxTimeoutSeconds: 60,
      };
      // Day 10 (dual-path): resolve the signature path for this asset+chain
      // BEFORE verification and log the selector evidence. The gateway's
      // verifyAuthorization re-resolves internally (cached), and the result
      // rides the verified payload so the settlement log records it too.
      const pathInfo = await gateway.getSignaturePath({ asset: gateway.USDC_BASE_SEPOLIA, chainId: gateway.BASE_SEPOLIA_CHAIN_ID });
      log.push('SIGNATURE PATH: ' + pathInfo.path + ' (' + (pathInfo.evidence && pathInfo.evidence.source) + ')');
      const v = await gateway.verifyAuthorization(parsed.payload, reqForVerify);
      if (v.verified) {
        paymentVerified = true;
        paymentMode = 'self';
        paymentPayload = parsed.payload;
        log.push('PAYMENT-SIGNATURE verified through self-hosted gateway (' + (v.signaturePath || 'eip2612') + ', signer=' + v.recoveredAddress + ')');
        if (v.pathEvidence) {
          log.push('PAYMENT-SIGNATURE path evidence: ' + JSON.stringify(v.pathEvidence));
        }
      } else {
        paymentRejectReason = v.reason;
        log.push('PAYMENT-SIGNATURE rejected (self): ' + v.reason);
      }
    }
  } else if (!paymentVerified && sigHeader) {
    const parsed = x402.parsePaymentSignatureHeader(sigHeader);
    if (!parsed.ok) {
      paymentRejectReason = parsed.reason;
      log.push('payment signature malformed: ' + parsed.reason);
    } else {
      // Build a synthetic requirement (fee + route defaults) to verify against.
      const reqForVerify = {
        scheme: 'exact',
        amount: x402.rawUnits(ROUTING_FEE_USD),
        asset: x402.USDC_ADDRESS[MOCK_NETWORK],
        networkName: MOCK_NETWORK,
        network: x402.NETWORK_CAIP2[MOCK_NETWORK],
        payTo: MOCK_PAYTO,
        maxTimeoutSeconds: 60,
      };
      const v = x402.verifyPaymentPayload(parsed.payload, reqForVerify);
      if (v.verified) {
        paymentVerified = true;
        paymentMode = v.mode;
        paymentPayload = parsed.payload;
        log.push('PAYMENT-SIGNATURE verified through ' + v.mode + ' branch');
      } else {
        paymentRejectReason = v.reason;
        log.push('PAYMENT-SIGNATURE rejected: ' + v.reason);
      }
    }
  }

  if (!paymentVerified) {
    // A payment header was present but verification failed: mark the idempotency
    // key FAILED (terminal/retryable) so it never lingers as a poison 'pending'
    // row. A failed prior attempt with the same key is retryable (gate logic).
    if (idemKeyNow && idem.fresh) {
      const challengeBody = buildChallenge();
      challengeBody.accepts[0].maxAmountRequired = ROUTING_FEE_USD;
      if (paymentRejectReason) challengeBody.rejectReason = paymentRejectReason;
      await idempotency.markFailed(idemKeyNow, 402, JSON.stringify(challengeBody));
      log.push('IDEMPOTENCY: key ' + idemKeyNow + ' marked failed (payment rejected 402)');
    }
    log.push('no valid payment signature -> 402 challenge');

    let challenge, headers = { 'Content-Type': 'application/json' };
    if (SELF_MODE) {
      // Day 9 (Item 2): self-hosted challenge — PAYMENT-REQUIRED header carries
      // base64 JSON: { network: eip155:84532, asset: USDC Base Sepolia,
      //   payTo: seller wallet, amount: routing fee raw units, facilitator: 'self',
      //   scheme: 'exact' }.
      challenge = gateway.buildChallenge({
        amountUsd: ROUTING_FEE_USD,
        payTo: gateway.getSellerAddress() || MOCK_PAYTO,
        network: gateway.NETWORK_CAIP2_BASE_SEPOLIA,
        asset: gateway.USDC_BASE_SEPOLIA,
      });
      headers[gateway.HEADERS.PAYMENT_REQUIRED] = gateway.buildPaymentRequiredHeader({
        amountRaw: gateway.rawUnits(ROUTING_FEE_USD),
        network: gateway.NETWORK_CAIP2_BASE_SEPOLIA,
        asset: gateway.USDC_BASE_SEPOLIA,
        payTo: gateway.getSellerAddress() || MOCK_PAYTO,
        facilitator: 'self',
        scheme: 'exact',
        resource: 'urn:ax-router:route:v1',
      });
    } else {
      challenge = buildChallenge();
      challenge.accepts[0].maxAmountRequired = ROUTING_FEE_USD;
      if (paymentRejectReason) challenge.rejectReason = paymentRejectReason;
    }
    if (paymentRejectReason && !challenge.rejectReason) challenge.rejectReason = paymentRejectReason;

    // ---- DAY 11 (Item 4): bind the 402 to the governing commitment ---------
    // The payment challenge ALWAYS references the issued commitment and its
    // neutral requirement R. This is the R/S separation on the wire: the
    // challenge declares the requirement; the settlement method (S) that
    // realises it is chosen by the buyer when they present a credential.
    if (commitmentFlowCtx) {
      challenge.commitment = {
        commitmentId: commitmentFlowCtx.manifest.commitmentId,
        manifestHash: commitmentFlowCtx.manifest.manifestHash,
      };
      challenge.requirement = {
        amt: commitmentFlowCtx.requirement.amt,
        cur: commitmentFlowCtx.requirement.cur,
        payee: commitmentFlowCtx.requirement.payee,
        eta: commitmentFlowCtx.requirement.eta,
        scheme: commitmentFlowCtx.requirement.scheme,
        t_exp: commitmentFlowCtx.requirement.t_exp,
      };
      // MPP is advertised alongside x402 when applicable (aegis-router
      // dual-rail pattern) — the buyer may settle via either method.
      if (railsMod.resolve('mpp')) {
        // SELF_MODE challenges (gateway.buildChallenge) have no `accepts`
        // array (the x402 challenge shape differs); ensure it exists before
        // advertising the MPP method alongside it.
        if (!challenge.accepts || !Array.isArray(challenge.accepts)) challenge.accepts = [];
        challenge.accepts.push({
          scheme: 'mpp',
          method: 'mpp',
          note: 'MPP rail registered; settlement accepted via mpp credential',
        });
      }
    }
    // ---- DAY 12 (Item 3): MPP challenge emission ----------------------------
    // When the MPP rail is registered, emit the MPP challenge in the
    // WWW-Authenticate: Payment header alongside the x402 PAYMENT-REQUIRED
    // header. Per the mppx compatibility pattern: "the server emits both MPP
    // and x402 Challenges, accepts either Credential format, and returns the
    // matching Receipt header." The buyer chooses the rail by the credential
    // format they present on retry.
    if (railsMod.resolve('mpp')) {
      const R = (commitmentFlowCtx && commitmentFlowCtx.requirement) || {
        amt: gateway.rawUnits(ROUTING_FEE_USD),
        cur: 'USDC',
        payee: gateway.getSellerAddress() || MOCK_PAYTO,
        scheme: 'Payment',
        eta: 'eta_' + Date.now(),
        t_exp: new Date(Date.now() + 120000).toISOString(),
      };
      try {
        const railsMpp = railsMod.resolve('mpp');
        const mppChallenge = await railsMpp.realise(R);
        const wwwAuth = railsMpp.emitChallengeHeader(mppChallenge);
        // MPP advertises the challenge in WWW-Authenticate; x402 keeps
        // PAYMENT-REQUIRED. Both headers present = dual challenge.
        headers['WWW-Authenticate'] = wwwAuth;
        log.push('MPP challenge emitted (WWW-Authenticate: Payment, challenge=' + (mppChallenge.id || '?') + ')');
      } catch (mpperr) {
        // MPP challenge generation failure must NOT break the x402 challenge:
        // degrade to x402-only for this request and log.
        log.push('MPP challenge emission failed (x402-only for this request): ' + String(mpperr.message || mpperr).slice(0, 160));
      }
    }
    res.writeHead(402, headers);
    res.end(JSON.stringify(challenge));
    return;
  }
  // Payment verified: mark the key 'verified' (brief state machine) — the final
  // settle happens at response time (markSettled below).
  if (idemKeyNow && idem.fresh) {
    await idempotency.markVerified(idemKeyNow);
    log.push('IDEMPOTENCY: key ' + idemKeyNow + ' verified (payment accepted)');
  }

  // ---- DAY 9 (Item 4): nonce replay guard -----------------------------------
  // A verified EIP-3009 authorization whose nonce has ALREADY been settled
  // must be rejected BEFORE routing (no duplicate charge, no duplicate work).
  // The nonce-bound idempotency key above makes the HTTP-layer replay safe;
  // this in-process guard is defense in depth against a nonce reused across
  // DIFFERENT idempotency keys (the attacker's fresh-key trick).
  if (SELF_MODE && paymentMode === 'self' && paymentPayload &&
      paymentPayload.payload && paymentPayload.payload.authorization) {
    const authNonce = paymentPayload.payload.authorization.nonce;
    const prior = gateway.getNonce(authNonce);
    if (prior && prior.status === 'settled') {
      log.push('DAY 9 NONCE GUARD: nonce ' + authNonce + ' already settled -> 402 rejected (no duplicate charge)');
      paymentRejectReason = 'nonce already settled (replay rejected)';
      const nonceGuardChallenge = { error: '402 Payment Required', rejectReason: paymentRejectReason };
      if (commitmentFlowCtx) {
        nonceGuardChallenge.commitment = { commitmentId: commitmentFlowCtx.manifest.commitmentId, manifestHash: commitmentFlowCtx.manifest.manifestHash };
        nonceGuardChallenge.requirement = {
          amt: commitmentFlowCtx.requirement.amt, cur: commitmentFlowCtx.requirement.cur,
          payee: commitmentFlowCtx.requirement.payee, eta: commitmentFlowCtx.requirement.eta,
          scheme: commitmentFlowCtx.requirement.scheme, t_exp: commitmentFlowCtx.requirement.t_exp,
        };
      }
      res.writeHead(402, { 'Content-Type': 'application/json', [gateway.HEADERS.PAYMENT_REQUIRED]: gateway.buildPaymentRequiredHeader({
        amountRaw: gateway.rawUnits(ROUTING_FEE_USD),
        network: gateway.NETWORK_CAIP2_BASE_SEPOLIA,
        asset: gateway.USDC_BASE_SEPOLIA,
        payTo: gateway.getSellerAddress() || MOCK_PAYTO,
        facilitator: 'self',
        scheme: 'exact',
      }) });
      res.end(JSON.stringify(nonceGuardChallenge));
      return;
    }
    if (prior && prior.status === 'pending') {
      log.push('DAY 9 NONCE GUARD: nonce ' + authNonce + ' in flight -> 409');
      res.writeHead(409, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: 'conflict', reason: 'authorization nonce is still being processed' }));
      return;
    }
    gateway.setNonce(authNonce, 'pending');
  }

  // Valid payment: run the ranking engine (demand text already sanitized).
  const result = ranker(payload.capability, { topN: 5 });


  // ---- DAY 8, ITEM 4: buyer reputation from the x402 signature (live) -------
  // Mock mode keeps the x-mock-buyer-rep header as a stand-in for testing.
  // LIVE mode IGNORES the header entirely: reputation derives from the verified
  // signer address (authorization.from) via IdentityRegistry reverse lookup +
  // ReputationRegistry (Path (a), operator-confirmed).
  const mockBuyerRep = req.headers['x-mock-buyer-rep'];
  const liveModeNow = String(verifyModeNow).toLowerCase() === 'live';
  const selfModeNow = SELF_MODE && paymentMode === 'self';
  let buyerRep = { reputation: null, note: 'no buyer address; no discount' };
  let repLog = null;
  if (liveModeNow || selfModeNow) {
    // Sanitization-gated: the payload was already structurally verified above
    // (paymentVerified true). Recover signer from the verified payload.
    const auth = (paymentPayload && paymentPayload.payload && paymentPayload.payload.authorization) || {};
    const buyer = String(auth.from || '').toLowerCase();
    if (buyer) {
      const resolved = await identity.resolveReputationFromSignature(paymentPayload, {
        recoveredAddress: buyer, // x402 verification already bound recovered == from
        mode: selfModeNow ? 'self' : verifyModeNow,
      });
      if (!resolved.ok) {
        // 401: recovered signer != authorization.from (signature invalid/tampered)
        log.push('REPUTATION: signer mismatch -> 401');
        res.writeHead(401, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'unauthorized', reason: resolved.reason }));
        return;
      }
      buyerRep = resolved.buyerRep;
      repLog = resolved.log;
    }
  } else {
    if (mockBuyerRep && !isNaN(Number(mockBuyerRep))) {
      const m = identity.reputationFromMockHeader(mockBuyerRep);
      if (m) {
        buyerRep = m.buyerRep;
        repLog = m.log;
      }
    } else if (req.headers['x-buyer-address']) {
      buyerRep = getBuyerReputation(req.headers['x-buyer-address']);
    }
  }
  const fee = computeFee(buyerRep, log);
  // ---- SPRINT 2, ITEM 1: outcome logging — every ranked result inserts a
  // row into ax_router.ranking_outcomes (weights_used snapshot + shrinkage
  // flag + per-component scores for tuning analysis). request_id is the
  // idempotency key when present, else a deterministic per-run id. Rows are
  // never exposed in API responses (trade-secret posture).
  if (result && result.status === 'ok') {
    const outcomeRow = {
      request_id: (idemKeyNow && idemKeyNow.slice(0, 120)) || ('req_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2, 10)),
      capability: payload.capability,
      supplier_ids: result.candidates.map(c => String(c.agent_id)),
      supplier_scores: result.candidates.map(c => c.score),
      selected_supplier: result.candidates[0] ? String(result.candidates[0].agent_id) : null,
      weights_used: result.weights_used || {},
      shrinkage_applied: !!result.shrinkage_applied,
      component_scores: {
        rows: result.candidates.map(c => ({
          agent_id: String(c.agent_id),
          reputation: c.components ? c.components.reputation : null,
          freshness: c.components ? c.components.freshness : null,
          price: c.components ? c.components.price : null,
          category: c.category || null,
          feedback_count: c.feedback_count || 0,
          shrunken: c.shrinkage ? true : false,
        })),
      },
      routing_fee_usd: fee ? fee.finalFeeUsd || fee.baseFeeUsd : null,
      settlement_rail: null, // resolved at settlement observation time
    };
    await outcomeLog.logOutcome(outcomeRow);
    log.push('OUTCOME LOG: ranking result logged (request_id=' + outcomeRow.request_id + ', suppliers=' + outcomeRow.supplier_ids.length + ', shrinkage=' + outcomeRow.shrinkage_applied + ')');
  }
  if (repLog) log.push('REPUTATION: ' + JSON.stringify(repLog));
  if (liveModeNow && mockBuyerRep && !isNaN(Number(mockBuyerRep))) {
    log.push('REPUTATION: x-mock-buyer-rep header IGNORED in live mode (source=signature only)');
  }

  if (result.status !== 'ok') {
    const respBody = JSON.stringify({
      status: result.status,
      capability: payload.capability,
      budget: payload.budget,
      deadline: payload.deadline,
      fee,
      payment: { mode: paymentMode, verified: paymentVerified },
      ...(result.status === 'no_match' ? { reason: result.reason } : {}),
    }, null, 2);
    if (idemKeyNow && idem.fresh) {
      await idempotency.markSettled(idemKeyNow, 200, respBody);
      log.push('IDEMPOTENCY: key ' + idemKeyNow + ' marked settled (cached response)');
    }
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(respBody);
    return;
  }

  // DAY 5: route every matched supplier -> exclude unsupported -> settle.
  const { routed, excluded, decisionLog } = router.routeMatches(result.candidates, payload.capability, registrations);
  const { settlements } = settle.runPayments(routed, excluded, payload.capability);
  const allDecisions = [...decisionLog, ...log];

  // ---- DAY 9 (Item 2): SELF-HOSTED SETTLEMENT ------------------------------
  // After routing logic succeeds, broadcast the buyer's signed EIP-3009
  // transferWithAuthorization to Base Sepolia. The seller wallet (authorization
  // 'to' holder) pays gas for the broadcast. Wait for 1 confirmation, then
  // return a PAYMENT-RESPONSE header { transactionHash, status: "settled" }.
  // On broadcast failure: mark the nonce failed, return 502 (no partial
  // charge: the funds never move if the broadcast reverts).
  let selfSettlement = null;
  let selfSettlementError = null;
  // ---- DAY 11 (Item 4): consume the requirement nonce on gate commit -------
  // Exactly one R is issued per commitment; the eta nonce is CONSUMED on
  // successful gate commit and never becomes fresh again. A replay of the
  // same nonce (same R) is rejected by consumeNonce -> ok:false.
  let nonceConsumed = null;
  if (commitmentFlowCtx && commitmentFlowCtx.requirement) {
    nonceConsumed = gateway.commitmentFlow.consumeRequirement(commitmentFlowCtx.requirement);
    if (!nonceConsumed.ok) {
      log.push('COMMITMENT: requirement nonce rejected on gate commit (' + nonceConsumed.reason + ') -> 409');
      res.writeHead(409, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: 'conflict', reason: 'requirement nonce already consumed (replay rejected)' }));
      return;
    }
    log.push('COMMITMENT: requirement eta ' + commitmentFlowCtx.requirement.eta + ' consumed (single-use)');
  }

  if (SELF_MODE && paymentMode === 'self' && paymentPayload) {
    try {
      const auth = paymentPayload.payload.authorization;
      const sig = paymentPayload.payload.signature;
      selfSettlement = await gateway.settleAuthorization(auth, sig);
      gateway.setNonce(auth.nonce, 'settled', selfSettlement);
      log.push('DAY 9 SETTLEMENT: broadcast ' + selfSettlement.txHash + ' status=' + selfSettlement.status +
        ' signaturePath=' + (selfSettlement.signaturePath || 'eip2612') +
        (selfSettlement.pathEvidence ? ' evidence=' + (selfSettlement.pathEvidence.selector || '') + (selfSettlement.pathEvidence.found ? ' (eip3009 selector present)' : ' (no eip3009 selector -> eip2612)') : '') +
        (selfSettlement.dryRun ? ' (DRY RUN — no real tx broadcast)' : ' block=' + selfSettlement.blockNumber));
    } catch (e) {
      selfSettlementError = String(e.message || e);
      if (paymentPayload.payload.authorization) {
        gateway.setNonce(paymentPayload.payload.authorization.nonce, 'failed');
      }
      log.push('DAY 9 SETTLEMENT FAILED: ' + selfSettlementError);
      if (idemKeyNow && idem.fresh) {
        await idempotency.markFailed(idemKeyNow, 502, JSON.stringify({ error: 'settlement failed' }));
      }
      res.writeHead(502, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: 'settlement failed', reason: selfSettlementError.slice(0, 300) }));
      return;
    }
  }

  // ---- DAY 12 (Item 3/4): MPP settlement ------------------------------------
  // When the buyer presented an MPP credential (Authorization: Payment), the
  // gateway settles via the mpp rail's settle() — which calls mppx's
  // broadcastCredential and our custom dual-path settler — and records the
  // rail reference for the Spend Receipt. The MPP receipt header (Payment-
  // Receipt) is emitted on the final response; x402 keeps PAYMENT-RESPONSE.
  let mppSettlement = null;
  let mppSettlementError = null;
  if (paymentMode === 'mpp' && mppCredential && railsMod.resolve('mpp')) {
    try {
      const railsMpp = railsMod.resolve('mpp');
      const railRef = await railsMpp.settle(mppCredential);
      mppSettlement = {
        reference: railRef,
        status: 'settled',
        method: 'mpp',
      };
      log.push('MPP SETTLEMENT: railReference=' + railRef + ' status=settled (method=mpp)');
    } catch (e) {
      mppSettlementError = String(e.message || e);
      log.push('MPP SETTLEMENT FAILED: ' + mppSettlementError);
      if (idemKeyNow && idem.fresh) {
        await idempotency.markFailed(idemKeyNow, 502, JSON.stringify({ error: 'mpp settlement failed' }));
      }
      res.writeHead(502, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: 'mpp settlement failed', reason: mppSettlementError.slice(0, 300) }));
      return;
    }
  }

  // ---- DAY 11 (Item 4/5): Spend Receipt binding settlement -> commitment ----
  // The receipt carries ONLY the public railReference (transaction identifier)
  // — never the credential, signature, or authorization (non-leakage rule).
  // Built from the rail's settle() output (x402 mock receipts, or the
  // self-hosted gateway settlement txHash).
  let spendReceipt = null;
  if (commitmentFlowCtx) {
    const primarySettlement = (settlements && settlements.find(s => s && s.status === 'settled')) || null;
    const txRef = {
      payer: commitmentBuyer,
      payee: commitmentFlowCtx.requirement.payee,
      amount: primarySettlement ? String(primarySettlement.amount || commitmentFlowCtx.requirement.amt) : commitmentFlowCtx.requirement.amt,
      currency: primarySettlement && primarySettlement.asset ? String(primarySettlement.asset) : commitmentFlowCtx.requirement.cur,
      // DAY 12: rail-agnostic binding — x402 settlements bind the txHash, MPP
      // settlements bind the MPP railReference. Both are public transaction
      // identifiers; the credential never appears in the receipt.
      rail: (mppSettlement && 'mpp') || ((selfSettlement && SELF_MODE) ? 'x402' : (primarySettlement && primarySettlement.rail) || 'x402'),
      railReference: (mppSettlement && mppSettlement.reference) || (selfSettlement && selfSettlement.txHash) || (primarySettlement && primarySettlement.txHash) || null,
    };
    spendReceipt = gateway.commitmentFlow.buildSpendReceipt({
      manifest: commitmentFlowCtx.manifest,
      R: commitmentFlowCtx.requirement,
      txRef,
    });
    log.push('RECEIPT: spend receipt ' + spendReceipt.receiptId + ' rail=' + spendReceipt.rail +
      ' railReference=' + spendReceipt.railReference + ' noManifest=' + spendReceipt.noManifest);
  }

  const matches = routed.map(sup => {
    const s = settlements.find(x => x.agentId === sup.agent_id);
    return {
      agent_id: sup.agent_id,
      name: sup.name,
      match: sup.match,
      score: sup.score,
      payTo: sup.payTo,
      selectedRail: sup.selectedRail,
      railDetail: sup.railDetail,
      settlement: s || null,
    };
  });

  const respBody = JSON.stringify({
    status: 'ok',
    capability: payload.capability,
    budget: payload.budget,
    deadline: payload.deadline,
    payment: { mode: paymentMode, verified: paymentVerified },
    ...(spendReceipt ? {
      commitment: {
        commitmentId: spendReceipt.commitmentId,
        manifestHash: spendReceipt.manifestHash,
        receiptId: spendReceipt.receiptId,
        rail: spendReceipt.rail,
        railReference: spendReceipt.railReference,
        settledAt: spendReceipt.settledAt,
      },
      // The full receipt object (noManifest + COSE signature) rides the
      // response for audit; the rail credential NEVER appears anywhere.
      spendReceipt,
    } : {}),
    fee: { baseUsd: fee.baseFeeUsd, discountPct: fee.discountPct, finalUsd: fee.finalFeeUsd, decision: fee.log },
    reputation: repLog,
    matches,
    excluded: excluded.map(e => ({ agent_id: e.agent_id, name: e.name, excludedReason: e.excludedReason })),
    decisionLog: allDecisions,
  }, null, 2);
  if (idemKeyNow && idem.fresh) {
    await idempotency.markSettled(idemKeyNow, 200, respBody);
    log.push('IDEMPOTENCY: key ' + idemKeyNow + ' marked settled (cached response)');
  }
  const respHeaders = { 'Content-Type': 'application/json' };
  if (selfSettlement) {
    // Item 2 receipt: PAYMENT-RESPONSE header with the on-chain settlement.
    respHeaders[gateway.HEADERS.PAYMENT_RESPONSE] = Buffer.from(JSON.stringify({
      transactionHash: selfSettlement.txHash,
      status: 'settled',
      ...(selfSettlement.dryRun ? { dryRun: true } : {}),
    })).toString('base64');
  }
  // DAY 12 (Item 3): MPP receipt header — Payment-Receipt, the MPP counterpart
  // to x402's PAYMENT-RESPONSE. Returns the rail reference (public tx id) only;
  // the credential never appears in any header or body.
  if (mppSettlement && railsMod.resolve('mpp')) {
    const railsMpp = railsMod.resolve('mpp');
    respHeaders['Payment-Receipt'] = railsMpp.buildReceiptHeader({
      method: 'mpp',
      status: 'success',
      reference: mppSettlement.reference,
      chainId: gateway.BASE_SEPOLIA_CHAIN_ID,
    });
  }
  res.writeHead(200, respHeaders);
  res.end(respBody);
}

const server = http.createServer((req, res) => {
  const url = new URL(req.url, 'http://localhost');
  if (req.method === 'POST' && url.pathname === '/route') {
    let body = '';
    req.on('data', c => { body += c; if (body.length > 64 * 1024) req.destroy(); });
    req.on('end', () => handleRoute(req, res, body));
  } else if (req.method === 'GET' && url.pathname === '/health') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({
      ok: true,
      mode: SELF_MODE ? 'self' : 'mock',
      verifyMode: x402.VERIFY_MODE,
      x402Mode: gateway.getMode(),
      seller: SELF_MODE ? (gateway.getSellerAddress() || null) : null,
      killSwitch: killswitch.isKillSwitchOn(),
      store: STORE_ACTIVE ? 'supabase' : 'in-memory',
      rateLimitStore: RATE_LIMIT_STORE,
      rails: railsMod.list(), // Day 11: registered settlement rails (x402)
      port: PORT,
      at: new Date().toISOString(),
    }));
  } else {
    res.writeHead(404, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ error: 'not found' }));
  }
});

server.listen(PORT, 'localhost', () => {
  console.log(`AX Router — Day 8 demand intake endpoint (MOCK MODE, verify=${x402.VERIFY_MODE})`);
  console.log(`POST http://localhost:${PORT}/route`);
  console.log(`fee: ${ROUTING_FEE_USD} USDC | payTo: ${MOCK_PAYTO} | floor: ${AX_CAPABILITY_FLOOR}`);
  console.log(`AX_PRICE_SCORE_DEFAULT=${AX_PRICE_SCORE_DEFAULT} | AX_FRESHNESS_STRATEGY=${AX_FRESHNESS_STRATEGY}`);
  console.log(`DAY 8 GATES: killSwitch=${killswitch.isKillSwitchOn()} | store=${STORE_ACTIVE ? 'supabase' : 'in-memory'} | rateLimitStore=${RATE_LIMIT_STORE}`);
});
// ---- Day 8: hourly TTL sweep (in-process fallback; Supabase side also sweeps
// via the pg_cron job). Started only when the store client is live.
if (STORE_ACTIVE) {
  const sweepIdem = () => idempotency.sweepExpired().catch(() => {});
  const sweepRl = () => ratelimit.sweepExpired().catch(() => {});
  setInterval(sweepIdem, idempotency.SWEEP_INTERVAL_MS).unref();
  setInterval(sweepRl, ratelimit.SWEEP_INTERVAL_MS).unref();
}

module.exports = {
  buildChallenge,
  computeFee,
  sanitizeCapability,
  parsePayload,
  handleRoute,
  router,
  settle,
  x402,
  killswitch,
  ratelimit,
  idempotency,
  identity,
  store,
  STORE_ACTIVE,
  clientIp,
  walletFromReq,
  // Day 11: commitment lifecycle modules (for tests/harness)
  commitmentMod,
  requirementMod,
  receiptMod,
  railsMod,
};