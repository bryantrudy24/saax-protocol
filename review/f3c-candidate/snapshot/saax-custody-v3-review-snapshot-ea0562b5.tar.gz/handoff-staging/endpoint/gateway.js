// AX Router — Day 9, Item 2: Self-hosted x402 payment gateway (viem)
//
// Replaces the Nevermined facilitator with a DIRECT Base-Sepolia integration.
// No third-party facilitator. The AX Router operator controls verification and
// settlement. The full flow:
//
//   402 challenge  ->  PAYMENT-REQUIRED header (base64 JSON) with network,
//                      asset, payTo (seller wallet), amount, facilitator:"self",
//                      scheme:"exact"
//   payment        ->  PAYMENT-SIGNATURE header (base64 JSON) carrying the
//                      EIP-3009 transferWithAuthorization signed by the buyer
//                      over the x402 EIP-712 domain + message
//   verify         ->  EIP-712 typed-data signature recovery (viem
//                      verifyTypedData); binds signer, recipient, amount,
//                      scheme, network, asset, validity window, nonce
//   settle         ->  AFTER routing logic succeeds, broadcast the signed
//                      transferWithAuthorization to Base Sepolia via
//                      wallet.sendRawTransaction using the signed authorization
//                      (seller wallet pays gas); wait for 1 confirmation
//   receipt        ->  PAYMENT-RESPONSE header { transactionHash, status:"settled" }
//
// SELECTION: AX_X402_MODE=self (new) vs mock (existing). Default mock keeps the
// existing local-testing lane (no wallet needed). When AX_X402_MODE=self, the
// gateway requires the seller wallet (AX_SELLER_PRIVATE_KEY) to be provisioned.
//
// SECURITY GATES (payment layer — all inherited and enforced here):
//   - Every field of the signed authorization is type-checked and bound.
//   - The signature must recover to authorization.from (EIP-712 typed-data).
//   - to must equal the seller wallet (payTo), value must equal the required
//     amount (raw 6-dp units), scheme exact, network eip155:84532, asset the
//     Base Sepolia USDC contract.
//   - validAfter/validBefore window is enforced against wall clock.
//   - nonce reuse is rejected via the nonce-bound idempotency store (Item 4).
//   - Nothing in a payment payload is ever executed/evaluated/echoed.
//   - Trade secrets (ranking weights, outcome data, seller key) never leave the
//     process; only plan/transaction metadata is emitted in headers.
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const {
  createWalletClient,
  createPublicClient,
  http,
  defineChain,
  encodeAbiParameters,
  parseAbiParameters,
  verifyTypedData,
  toHex,
  hexToBigInt,
  isAddress,
  getAddress,
} = require('viem');

// ---- Chain / asset constants --------------------------------------------------
// Base Sepolia (caip-2 eip155:84532). USDC contract per Circle's published
// testnet list (developers.circle.com/stablecoins/usdc-contract-addresses):
//   0x036CbD53842c5426634e7929541eC2318f3dCF7e
const BASE_SEPOLIA_CHAIN_ID = 84532;
const baseSepolia = defineChain({
  id: BASE_SEPOLIA_CHAIN_ID,
  name: 'Base Sepolia',
  network: 'base-sepolia',
  nativeCurrency: { name: 'Ether', symbol: 'ETH', decimals: 18 },
  rpcUrls: {
    default: {
      http: [process.env.AX_BASE_SEPOLIA_RPC || 'https://sepolia.base.org'],
    },
  },
  blockExplorers: {
    default: { name: 'BaseScan', url: 'https://base-sepolia.blockscout.com' },
  },
});
const NETWORK_CAIP2_BASE_SEPOLIA = 'eip155:84532';
const USDC_BASE_SEPOLIA = '0x036CbD53842c5426634e7929541eC2318f3dCF7e';
const USDC_DECIMALS = 6;

// DUAL-PATH (Day 10, mainnet readiness): the settlement signature scheme is
// selected ON-CHAIN per asset+chain — probe the token contract for the
// EIP-3009 transferWithAuthorization function selector:
//   - selector PRESENT -> EIP-3009 path: verify + broadcast a single
//     transferWithAuthorization (e.g. Base MAINNET USDC).
//   - selector ABSENT  -> EIP-2612 path: verify Permit, broadcast permit then
//     transferFrom (e.g. Base SEPOLIA USDC = FiatTokenV2, verified on-chain
//     Day 9 via probe-usdc-state.js + probe-permit-semantics.js).
// Every settlement logs which path was selected, with the selector evidence.
// Default is 'auto' (probe); override with AX_X402_SIGNATURE_PATH.
// permit(address owner,address spender,uint256 value,uint256 nonce,uint256 deadline)
const PERMIT_SELECTOR = '0xd505accf';
// transferFrom(address from,address to,uint256 value) — spender pulls the funds
const TRANSFER_FROM_SELECTOR = '0x23b872dd';

// ---- EIP-3009 selectors + types (dual-path, Day 10) --------------------------
// The transferWithAuthorization selector is DERIVED from the canonical ABI
// signature at runtime (keccak-256 first 4 bytes) so there is no magic
// constant to drift: EIP-3009
//   transferWithAuthorization(address from,address to,uint256 value,uint256
//     validAfter,uint256 validBefore,bytes32 nonce,uint8 v,bytes32 r,bytes32 s)
// The same derivation runs in scripts/probe-signature-path.js and produces the
// evidence logged per settlement.
const { keccak256, slice } = require('viem');
const TRANSFER_WITH_AUTH_SIG =
  'transferWithAuthorization(address,address,uint256,uint256,uint256,bytes32,uint8,bytes32,bytes32)';
const TWA_SELECTOR = slice(keccak256(toHex(TRANSFER_WITH_AUTH_SIG)), 0, 4);

// EIP-712 typed-data types for the EIP-3009 TransferWithAuthorization struct.
// Domain is the standard token EIP-712 domain (name/version/chainId/
// verifyingContract) — the same domain used for EIP-2612 Permit on the same
// contract. NOTE: the EIP-3009 struct nonce is bytes32, unlike the EIP-2612
// uint256 counter — both are validated and signed exactly per their spec.
const EIP3009_TRANSFER_TYPES = {
  TransferWithAuthorization: [
    { name: 'from', type: 'address' },
    { name: 'to', type: 'address' },
    { name: 'value', type: 'uint256' },
    { name: 'validAfter', type: 'uint256' },
    { name: 'validBefore', type: 'uint256' },
    { name: 'nonce', type: 'bytes32' },
  ],
};

// ---- Signature-path selection config ------------------------------------------
// AX_X402_SIGNATURE_PATH: 'auto' (default; on-chain probe per asset+chain,
// cached) | 'eip3009' (force transferWithAuthorization path) | 'eip2612'
// (force permit path). The force flags exist so MAINNET activation can pin
// the EIP-3009 path without waiting on a probe, and so tests can exercise
// either branch deterministically. Never auto-probe mainnet without the
// override documented in day7-wallet-checklist.md §mainnet.
const PATH_ENV = 'AX_X402_SIGNATURE_PATH';
const PATH_TTL_MS = Number(process.env.AX_SIGNATURE_PATH_TTL_SECONDS || 600) * 1000;
const _pathCache = new Map(); // key asset|chainId -> { path, evidence, ts }

// ---- Mode selection ------------------------------------------------------------
// AX_X402_MODE: 'mock' (default) | 'self' (self-hosted gateway).
function getMode() {
  return String(process.env.AX_X402_MODE || 'mock').trim().toLowerCase();
}
function setMode(m) { process.env.AX_X402_MODE = m; }
const MODE = getMode();

// ---- Config ---------------------------------------------------------------------
const SELLER_KEY_ENV = 'AX_SELLER_PRIVATE_KEY';
const SELLER_ADDR_ENV = 'AX_SELLER_ADDRESS';
const DEFAULT_FEE_USD = Number(process.env.AX_ROUTING_FEE_USD || 0.05);
const DEFAULT_MAX_TIMEOUT_SECONDS = 60;

let _viemProbe = null; // memoized { publicClient, walletClient } after first use

function loadSellerKey() {
  const k = String(process.env[SELLER_KEY_ENV] || '').trim();
  if (!k) return null;
  return k.startsWith('0x') ? k : '0x' + k;
}

function getSellerAddress() {
  const addr = String(process.env[SELLER_ADDR_ENV] || '').trim();
  if (addr && isAddress(addr)) return getAddress(addr);
  return null;
}

// Public + wallet clients (created lazily; the wallet client pays gas for the
// transferWithAuthorization broadcast — mandatory in EIP-3009: the 'to' holder
// submits the signed authorization).
function clients() {
  if (_viemProbe) return _viemProbe;
  const publicClient = createPublicClient({ chain: baseSepolia, transport: http() });
  let walletClient = null;
  const key = loadSellerKey();
  if (key) {
    const { privateKeyToAccount } = require('viem/accounts');
    const account = privateKeyToAccount(key);
    walletClient = createWalletClient({ account, chain: baseSepolia, transport: http() });
  }
  _viemProbe = { publicClient, walletClient, account: walletClient ? walletClient.account : null };
  return _viemProbe;
}

// ---- Dual-path on-chain probe (Day 10) ----------------------------------------
// Probe the token contract's CODE for the transferWithAuthorization function
// selector (0xe3ee160e — derived from the EIP-3009 9-arg ABI signature above)
// — the EIP-3009 entry point. Returns the selected path
// + the selector evidence. Cached per asset|chainId for PATH_TTL_MS.
async function probeSignaturePath({ asset, chainId, force }) {
  const key = String(asset || USDC_BASE_SEPOLIA).toLowerCase() + '|' + String(chainId || BASE_SEPOLIA_CHAIN_ID);
  const cached = _pathCache.get(key);
  if (cached && !force && Date.now() - cached.ts < PATH_TTL_MS) return { path: cached.path, evidence: cached.evidence, cached: true };

  // If the token was explicitly pinned by the operator (env override), honor
  // it WITHOUT an RPC probe (mainnet privacy: no premature mainnet reads).
  const pinned = String(process.env[PATH_ENV] || '').trim().toLowerCase();
  if (pinned === 'eip3009') {
    const ev = { method: 'env', selector: TWA_SELECTOR, source: 'AX_X402_SIGNATURE_PATH=eip3009 (operator pin)' };
    _pathCache.set(key, { path: 'eip3009', evidence: ev, ts: Date.now() });
    return { path: 'eip3009', evidence: ev, cached: false };
  }
  if (pinned === 'eip2612') {
    const ev = { method: 'env', selector: PERMIT_SELECTOR, source: 'AX_X402_SIGNATURE_PATH=eip2612 (operator pin)' };
    _pathCache.set(key, { path: 'eip2612', evidence: ev, ts: Date.now() });
    return { path: 'eip2612', evidence: ev, cached: false };
  }

  // On-chain probe: read the contract code and search for the selector bytes.
  const { publicClient } = clients();
  const addr = asset || USDC_BASE_SEPOLIA;
  const code = await publicClient.getCode({ address: addr });
  const hex = code ? code.toLowerCase() : '0x';
  const selectorHex = TWA_SELECTOR.toLowerCase().slice(2);
  const found = hex.includes(selectorHex);
  const evidence = {
    method: 'onchain',
    selector: TWA_SELECTOR,
    selectorHex,
    asset: addr,
    chainId: chainId || BASE_SEPOLIA_CHAIN_ID,
    codeBytes: hex.length > 2 ? (hex.length - 2) / 2 : 0,
    found,
    source: found ? 'eth_getCode contains transferWithAuthorization selector' : 'eth_getCode does NOT contain transferWithAuthorization selector -> EIP-2612 (permit) fallback',
  };
  const path = found ? 'eip3009' : 'eip2612';
  _pathCache.set(key, { path, evidence, ts: Date.now() });
  return { path, evidence, cached: false };
}

// Resolve the signature path for an asset (env pin first, else cached probe,
// else live probe). Logger-friendly; never throws on probe failure (falls
// back to EIP-2612 with the probe error in evidence — the conservative path).
async function getSignaturePath({ asset, chainId, force } = {}) {
  try {
    const r = await probeSignaturePath({ asset, chainId, force });
    return { path: r.path, evidence: r.evidence, cached: !!r.cached };
  } catch (e) {
    return {
      path: 'eip2612',
      evidence: { method: 'probe-failed', selector: PERMIT_SELECTOR, source: 'probe error: ' + String(e.message || e).slice(0, 160) + '; conservative EIP-2612 fallback' },
      cached: false,
    };
  }
}

// Short human-readable evidence for log lines (per-settlement path log).
function pathEvidenceForAsset({ asset, chainId } = {}) {
  const key = String(asset || USDC_BASE_SEPOLIA).toLowerCase() + '|' + String(chainId || BASE_SEPOLIA_CHAIN_ID);
  const cached = _pathCache.get(key);
  if (!cached) return { path: 'unknown', evidence: null };
  return { path: cached.path, evidence: cached.evidence };
}

// ---- EIP-712 domain + types for the x402 EIP-3009 authorization ----------------
// The domain is the standard EIP-2612/EIP-3009 token domain (chainId, verifying
// contract, name, version). Parameters verified ON-CHAIN via
// scripts/probe-usdc-domain.js: name "USDC", symbol "USDC", decimals 6,
// version "2", and the EIP-712 DOMAIN_SEPARATOR matches the local keccak
// reconstruction (match: YES). The message is the transferWithAuthorization
// struct per EIP-3009 (from, to, value, validAfter, validBefore, nonce).
//
// The exact EIP-712 recovery is done with viem's verifyTypedData, which
// reconstructs the digest exactly as the token contract's
// DOMAIN_SEPARATOR + transferWithAuthorization would.
function domainFor(assetAddress, chainId, tokenName, tokenVersion) {
  return {
    name: tokenName || 'USDC',
    version: tokenVersion || '2',
    chainId: chainId || BASE_SEPOLIA_CHAIN_ID,
    verifyingContract: assetAddress || USDC_BASE_SEPOLIA,
  };
}

// FiatTokenV2 EIP-2612 Permit struct — verified ON-CHAIN via
// PERMIT_TYPEHASH = keccak("Permit(address owner,address spender,uint256
// value,uint256 nonce,uint256 deadline)") == 0x6e71edae... (probe-permit-semantics.js).
// Base Sepolia USDC is FiatTokenV2 (permit-only); EIP-3009 selectors are absent.
const EIP3009_TYPES = {
  Permit: [
    { name: 'owner', type: 'address' },
    { name: 'spender', type: 'address' },
    { name: 'value', type: 'uint256' },
    { name: 'nonce', type: 'uint256' },
    { name: 'deadline', type: 'uint256' },
  ],
};

// ---- Wells: parse + validate the PAYMENT-SIGNATURE header ----------------------
// Header carries base64 JSON { version: 2, resource, accepted, payload:
// { signature, authorization: {...} } } — the wire shape from x402 v2 (same
// structural contract x402.js uses, extended with the EIP-3009 fields).
function parsePaymentSignatureHeader(headerValue) {
  const raw = String(headerValue || '').trim();
  if (!raw) return { ok: false, payload: null, reason: 'missing PAYMENT-SIGNATURE header' };
  let decoded;
  try { decoded = Buffer.from(raw, 'base64').toString('utf8'); }
  catch (_) { return { ok: false, payload: null, reason: 'header is not valid base64' }; }
  let obj;
  try { obj = JSON.parse(decoded); }
  catch (_) { return { ok: false, payload: null, reason: 'header does not decode to JSON' }; }
  return { ok: true, payload: obj, reason: null };
}

// Build the PAYMENT-REQUIRED header value (base64 JSON) — x402 v2 challenge.
function buildPaymentRequiredHeader({ amountRaw, network, asset, payTo, facilitator, scheme, resource }) {
  const challenge = {
    network,
    asset,
    amount: String(amountRaw),
    payTo,
    facilitator: facilitator || 'self',
    scheme: scheme || 'exact',
    resource: resource || 'urn:ax-router:route:v1',
    maxTimeoutSeconds: DEFAULT_MAX_TIMEOUT_SECONDS,
  };
  return Buffer.from(JSON.stringify(challenge)).toString('base64');
}

// ---- Structural validation of the decoded payload ------------------------------
function structurallyValid(payload) {
  if (!payload || typeof payload !== 'object') return { ok: false, reason: 'payload is not an object' };
  if (payload.version !== undefined && payload.version !== 2 && String(payload.version) !== '2') {
    // tolerate x402Version key too; require 2
    const v = payload.x402Version !== undefined ? payload.x402Version : payload.version;
    if (String(v) !== '2') return { ok: false, reason: 'x402 version must be 2' };
  }
  const accepted = payload.accepted;
  if (!accepted || typeof accepted !== 'object') return { ok: false, reason: 'missing accepted' };
  if (accepted.scheme !== 'exact') return { ok: false, reason: 'scheme must be exact (fixed price)' };
  if (accepted.amount === undefined || accepted.amount === null || !/^\d+$/.test(String(accepted.amount))) {
    return { ok: false, reason: 'accepted.amount must be a numeric string' };
  }
  if (!accepted.asset) return { ok: false, reason: 'missing asset' };
  if (!accepted.network) return { ok: false, reason: 'missing network' };
  if (!accepted.payTo) return { ok: false, reason: 'missing payTo' };
  const p = payload.payload;
  if (!p || typeof p !== 'object') return { ok: false, reason: 'missing payload' };
  if (!p.signature || !/^0x[0-9a-fA-F]{130}$/.test(p.signature)) return { ok: false, reason: 'signature must be 65-byte hex' };
  const auth = p.authorization;
  if (!auth || typeof auth !== 'object') return { ok: false, reason: 'missing authorization' };
  if (!auth.from || !/^0x[a-fA-F0-9]{40}$/.test(auth.from)) return { ok: false, reason: 'authorization.from must be an address' };
  return { ok: true, reason: null };
}

// ---- EIP-712 verification -------------------------------------------------------
// Returns { verified, reason, recoveredAddress, authorization } and NEVER throws
// on a bad signature (returns verified:false with the reason).
async function verifyAuthorization(payload, requirements) {
  const structural = structurallyValid(payload);
  if (!structural.ok) return { verified: false, reason: structural.reason };

  const accepted = payload.accepted;
  const p = payload.payload;
  const auth = p.authorization;

  // ---- Type + range checks on the EIP-3009/EIP-2612 authorization fields
  // (security sprint Item 2). Every field is verified as a typed, bounded
  // value BEFORE it is used in BigInt construction or the EIP-712 digest;
  // anything malformed is rejected here with an explicit reason (never
  // allowed to surface as a confusing verify exception or reach calldata).
  const NUM_STR = /^\d+$/;                 // non-negative integer string
  const ADDR_RE = /^0x[a-fA-F0-9]{40}$/;
  if (typeof auth.from !== 'string' || !ADDR_RE.test(auth.from)) {
    return { verified: false, reason: 'authorization.from must be an address' };
  }
  if (auth.to === undefined || auth.to === null || typeof auth.to !== 'string' || !ADDR_RE.test(auth.to)) {
    return { verified: false, reason: 'authorization.to must be an address' };
  }
  if (auth.value === undefined || auth.value === null || !NUM_STR.test(String(auth.value))) {
    return { verified: false, reason: 'authorization.value must be a non-negative integer string' };
  }
  if (auth.validAfter === undefined || auth.validAfter === null ||
      !NUM_STR.test(String(auth.validAfter))) {
    return { verified: false, reason: 'authorization.validAfter must be a non-negative integer string' };
  }
  if (auth.validBefore === undefined || auth.validBefore === null ||
      !NUM_STR.test(String(auth.validBefore))) {
    return { verified: false, reason: 'authorization.validBefore must be a non-negative integer string' };
  }
  // nonce format is PATH-DEPENDENT: EIP-2612 counter = decimal string,
  // EIP-3009 = bytes32 hex. Presence is checked here; the format + range is
  // validated after the signature path is resolved (Day 10 dual-path).
  if (auth.nonce === undefined || auth.nonce === null) {
    return { verified: false, reason: 'authorization.nonce is required' };
  }
  // Range-safety: the EIP-2612 value and the validity window must be sane
  // (reject absurd magnitudes before they reach BigInt/calldata).
  if (String(auth.value).length > 30) {
    return { verified: false, reason: 'authorization.value out of safe range' };
  }
  const va = Number(auth.validAfter), vb = Number(auth.validBefore);
  const nowSec = Math.floor(Date.now() / 1000);
  if (!Number.isSafeInteger(va) || !Number.isSafeInteger(vb)) {
    return { verified: false, reason: 'authorization validity window out of safe range' };
  }
  if (va > nowSec + 86400) {
    return { verified: false, reason: 'authorization validAfter too far in the future' };
  }
  if (vb > nowSec + 30 * 86400) {
    return { verified: false, reason: 'authorization validBefore too far in the future (max 30 days)' };
  }

  // DUAL-PATH (Day 10): the signed typed-data struct depends on the token's
  // signature scheme, resolved via the on-chain probe (selector evidence) or
  // the operator pin. Both paths use the SAME EIP-712 token domain; only the
  // primary type + message shape + nonce encoding differ.
  //
  //   EIP-3009 path (transferWithAuthorization — e.g. mainnet USDC):
  //     authorization.from        -> struct.from   (the buyer/signer)
  //     authorization.to          -> struct.to     (the seller/gateway)
  //     authorization.value       -> struct.value
  //     authorization.validAfter  -> struct.validAfter
  //     authorization.validBefore -> struct.validBefore
  //     authorization.nonce       -> struct.nonce  (bytes32 hex)
  //
  //   EIP-2612 path (permit — Base Sepolia USDC = FiatTokenV2):
  //     authorization.from        -> permit.owner   (the buyer/signer)
  //     authorization.to          -> permit.spender (the seller/gateway)
  //     authorization.value       -> permit.value
  //     authorization.nonce       -> permit.nonce   (uint256 counter)
  //     authorization.validBefore -> permit.deadline
  //     validAfter enforced locally (start-of-validity, not in the struct).
  const from = String(auth.from || '').toLowerCase();
  const to = String(auth.to || '').toLowerCase();
  const expectedTo = String(requirements.payTo || getSellerAddress() || '').toLowerCase();
  if (!/^0x[a-f0-9]{40}$/.test(from)) return { verified: false, reason: 'authorization.from must be an address' };
  if (!/^0x[a-f0-9]{40}$/.test(to)) return { verified: false, reason: 'authorization.to must be an address' };
  if (expectedTo && to !== expectedTo) return { verified: false, reason: 'recipient binding violated: to != payTo' };
  if (String(to).toLowerCase() === String(from).toLowerCase()) return { verified: false, reason: 'self-transfer forbidden' };

  // Resolve the signature path for this asset+chain (probe/pin; cached).
  const chainId = parseChainId(accepted.network);
  const pathResult = await getSignaturePath({ asset: accepted.asset, chainId });
  const sigPath = pathResult.path;
  let recovered = null;         // recovered signer (== authorization.from when verified)
  let lastPathEvidence = null;  // selector evidence for the per-settlement log

  if (sigPath === 'eip3009') {
    // ---- EIP-3009 (transferWithAuthorization) verification ------------------
    // nonce is bytes32: must be a 0x + 64 hex string. validAfter/validBefore
    // are part of the signed struct (unlike EIP-2612 where validAfter is
    // local-only) — both are already numeric-string validated above; the
    // struct carries validAfter directly.
    if (!/^0x[a-fA-F0-9]{64}$/.test(String(auth.nonce))) {
      return { verified: false, reason: 'authorization.nonce must be a bytes32 hex string (EIP-3009)' };
    }
    const twaMsg = {
      from,
      to,
      value: BigInt(auth.value),
      validAfter: BigInt(auth.validAfter),
      validBefore: BigInt(auth.validBefore),
      nonce: auth.nonce, // bytes32 (hex string → viem encodes directly)
    };
    try {
      const ok = await verifyTypedData({
        address: from,
        domain: domainFor(accepted.asset, chainId),
        types: EIP3009_TRANSFER_TYPES,
        primaryType: 'TransferWithAuthorization',
        message: twaMsg,
        signature: p.signature,
      });
      if (!ok) return { verified: false, reason: 'signature does not verify for authorization.from (EIP-3009)' };
    } catch (e) {
      return { verified: false, reason: 'signature verification failed (EIP-3009): ' + String(e.message || e).slice(0, 160) };
    }
    recovered = from;
    // Path evidence for the per-settlement log.
    lastPathEvidence = pathResult.evidence;
  } else {
    // ---- EIP-2612 (permit) verification — the Base Sepolia path -------------
    if (!NUM_STR.test(String(auth.nonce))) {
      return { verified: false, reason: 'authorization.nonce must be a non-negative integer string (EIP-2612 counter)' };
    }
    const permitMsg = {
      owner: from,
      spender: to,
      value: BigInt(auth.value),
      nonce: BigInt(auth.nonce),          // EIP-2612 counter (uint256)
      deadline: BigInt(auth.validBefore), // permit deadline = validBefore
    };
    try {
      const ok = await verifyTypedData({
        address: from,
        domain: domainFor(accepted.asset, chainId),
        types: EIP3009_TYPES,
        primaryType: 'Permit',
        message: permitMsg,
        signature: p.signature,
      });
      if (!ok) return { verified: false, reason: 'signature does not verify for authorization.from' };
    } catch (e) {
      return { verified: false, reason: 'signature verification failed: ' + String(e.message || e).slice(0, 160) };
    }
    recovered = from;
    // Path evidence for the per-settlement log.
    lastPathEvidence = pathResult.evidence;
  }

  // 2. Amount binding — value must equal the required raw amount (checked as
  //    string equality on the validated numeric string; no coercion surprises).
  const requiredAmount = String(requirements.amount || (requirements.usd ? rawUnits(requirements.usd) : ''));
  if (!requiredAmount) return { verified: false, reason: 'no required amount supplied' };
  if (String(auth.value) !== requiredAmount) {
    return { verified: false, reason: 'value mismatch: authorization.value ' + auth.value + ' != required ' + requiredAmount };
  }

  // 3. Scheme/network/asset binding.
  if (accepted.scheme !== 'exact') return { verified: false, reason: 'scheme must be exact' };
  if (String(accepted.network) !== String(requirements.network)) {
    return { verified: false, reason: 'network mismatch: ' + accepted.network + ' != ' + requirements.network };
  }
  if (String(accepted.asset).toLowerCase() !== String(requirements.asset).toLowerCase()) {
    return { verified: false, reason: 'asset mismatch: ' + accepted.asset + ' != ' + requirements.asset };
  }

  // 4. Validity window — validAfter <= now < deadline (wall clock, seconds).
  const now = Math.floor(Date.now() / 1000);
  const validAfter = Number(auth.validAfter);
  const deadline = Number(auth.validBefore);
  if (!Number.isFinite(validAfter) || !Number.isFinite(deadline)) {
    return { verified: false, reason: 'authorization validity window malformed' };
  }
  if (validAfter > deadline) return { verified: false, reason: 'authorization window inverted (validAfter > validBefore)' };
  if (now < validAfter) return { verified: false, reason: 'authorization not yet valid (validAfter in future)' };
  if (now >= deadline) return { verified: false, reason: 'authorization expired (validBefore passed)' };

  // 5. Nonce format re-check (path-aware). EIP-2612 = decimal counter;
  //    EIP-3009 = bytes32 hex (already validated in the path branch above).
  if (sigPath === 'eip2612') {
    if (!NUM_STR.test(String(auth.nonce))) {
      return { verified: false, reason: 'authorization.nonce must be a non-negative integer (EIP-2612 counter)' };
    }
  }

  return { verified: true, reason: null, recoveredAddress: recovered, authorization: auth, signaturePath: sigPath, pathEvidence: lastPathEvidence };
}

// ---- Nonce hash -> idempotency key (Item 4) ------------------------------------
// Deterministic, replay-safe: the same nonce always maps to the same key, so a
// re-presented signed authorization under a fresh request identifier collides
// with the settled/pending row and cannot double-charge.
function nonceIdempotencyKey(nonce) {
  const raw = String(nonce || '').toLowerCase();
  const digest = crypto.createHash('sha256').update(raw, 'utf8').digest('hex');
  return 'nnonce:' + digest;
}

// ---- Settlement ----------------------------------------------------------------
// Broadcast the signed transferWithAuthorization to Base Sepolia. The SELLER
// wallet (authorization.to) submits and pays gas (EIP-3009).
// Wait for 1 confirmation after the tx is mined.
async function settleAuthorization(auth, signature, { confirmations = 1 } = {}) {
  // ---- Untrusted-field revalidation (security sprint Item 4). The settlement
  // path re-checks EVERY field immediately before broadcast, independent of
  // the verification layer, so a caller that skips verify (or a race between
  // verify and settle) can never broadcast a tampered authorization. The
  // seller can only ever be induced to pay gas for the exact verified permit
  // + transferFrom of the verified amount to itself — no arbitrary approvals
  // or third-party recipients (gas-abuse prevention).
  const ADDR_RE = /^0x[a-fA-F0-9]{40}$/;
  const NUM_STR = /^\d+$/;
  if (!auth || typeof auth !== 'object') throw new Error('settlement: missing authorization');
  if (typeof auth.from !== 'string' || !ADDR_RE.test(auth.from)) throw new Error('settlement: from must be an address');
  if (typeof auth.to !== 'string' || !ADDR_RE.test(auth.to)) throw new Error('settlement: to must be an address');
  if (!NUM_STR.test(String(auth.value)) || String(auth.value).length > 30) throw new Error('settlement: value must be a bounded non-negative integer string');
  if (!NUM_STR.test(String(auth.validBefore))) throw new Error('settlement: validBefore must be a non-negative integer string');
  if (!NUM_STR.test(String(auth.validAfter))) throw new Error('settlement: validAfter must be a non-negative integer string');
  // nonce format is PATH-DEPENDENT: EIP-2612 decimal counter vs EIP-3009
  // bytes32 hex. Validate per the resolved signature path below (Day 10).
  const seller = getSellerAddress();
  if (seller && String(auth.to).toLowerCase() !== seller.toLowerCase()) {
    throw new Error('settlement: recipient is not the seller wallet (to != seller)');
  }
  if (String(auth.from).toLowerCase() === String(auth.to).toLowerCase()) {
    throw new Error('settlement: self-transfer forbidden');
  }
  const vb = Number(auth.validBefore), va = Number(auth.validAfter);
  const now = Math.floor(Date.now() / 1000);
  if (!Number.isSafeInteger(va) || !Number.isSafeInteger(vb)) throw new Error('settlement: validity window out of range');
  if (va > vb) throw new Error('settlement: validity window inverted');
  if (now < va) throw new Error('settlement: authorization not yet valid');
  if (now >= vb) throw new Error('settlement: authorization expired');

  // Test seam (Item 5 harness, no-funds mode): AX_GATEWAY_DRY_RUN=1 returns a
  // marked synthetic receipt WITHOUT touching the chain. The dry-run marker in
  // the txHash ('dryrun_') makes it unambiguous in logs that no real tx was
  // broadcast. The real broadcast path below is untouched by this flag.
  if (process.env.AX_GATEWAY_DRY_RUN === '1') {
    return {
      txHash: 'dryrun_' + crypto.randomUUID(),
      blockNumber: '0',
      status: 'settled',
      dryRun: true,
    };
  }
  const { publicClient, walletClient, account } = clients();
  if (!walletClient || !account) {
    throw new Error('self-hosted settlement requires AX_SELLER_PRIVATE_KEY (seller wallet pays gas)');
  }

  // ---- Dual-path settlement dispatch (Day 10) -----------------------------
  // Resolve the signature path (probe/pin; cached). EIP-3009 (selector
  // present): a SINGLE transferWithAuthorization broadcast moves the funds.
  // EIP-2612 (selector absent — Base Sepolia FiatTokenV2): permit +
  // transferFrom, the tested Day 9 rail. The path + selector evidence rides
  // on the receipt and is logged per settlement.
  const sigPath = (await getSignaturePath({ asset: USDC_BASE_SEPOLIA, chainId: BASE_SEPOLIA_CHAIN_ID })).path;
  const pathInfo = await getSignaturePath({ asset: USDC_BASE_SEPOLIA, chainId: BASE_SEPOLIA_CHAIN_ID });
  if (sigPath === 'eip3009') {
    if (!/^0x[a-fA-F0-9]{64}$/.test(String(auth.nonce))) {
      throw new Error('settlement: nonce must be a bytes32 hex string (EIP-3009)');
    }
    const r = await settleEip3009(auth, signature, { confirmations });
    r.signaturePath = 'eip3009';
    r.pathEvidence = pathInfo.evidence;
    return r;
  }
  // EIP-2612 (permit + transferFrom)
  if (!NUM_STR.test(String(auth.nonce)) || String(auth.nonce).length > 30) {
    throw new Error('settlement: nonce must be a bounded non-negative integer string (EIP-2612 counter)');
  }
  const r = await settleEip2612(auth, signature, { confirmations });
  r.signaturePath = 'eip2612';
  r.pathEvidence = pathInfo.evidence;
  return r;
}

// ---- EIP-2612 settlement: broadcast the signed Permit, then transferFrom ----
// Base Sepolia FiatTokenV2 rail (Day 9 tested). The seller wallet pays gas for
// both steps. Returns { txHash, permitTxHash, blockNumber, status }.
async function settleEip2612(auth, signature, { confirmations = 1 } = {}) {
  const { publicClient, walletClient, account } = clients();
  if (!walletClient || !account) {
    throw new Error('self-hosted settlement requires AX_SELLER_PRIVATE_KEY (seller wallet pays gas)');
  }
  const owner = String(auth.from).toLowerCase();   // permit.owner / transferFrom.from
  const spender = String(auth.to).toLowerCase();   // permit.spender / transferFrom.to == seller
  const valueRaw = auth.value;
  const deadline = auth.validBefore;

  // Step 1 — broadcast the signed Permit (owner authorizes spender). EIP-2612
  // permits may be submitted by ANYONE (the spender pays gas), which fits the
  // self-hosted model: the seller wallet pays gas for both steps.
  // FiatTokenV2 permit(owner,spender,value,deadline,v,r,s) — 8 args, NO nonce:
  // the contract reads nonces[owner] from storage. The EIP-712 SIGNED struct
  // includes nonce (Permit(owner,spender,value,nonce,deadline)); the CALDATA
  // does not.
  const permitCalldata = encodeAbiParameters(
    parseAbiParameters('address,address,uint256,uint256,uint8,bytes32,bytes32'),
    [
      owner,
      spender,
      BigInt(valueRaw),
      BigInt(deadline),
      parseInt(signature.slice(130, 132), 16), // v
      ('0x' + signature.slice(2, 66)),         // r
      ('0x' + signature.slice(66, 130)),       // s
    ]
  );

  const permitTxData = PERMIT_SELECTOR + permitCalldata.slice(2);
  const permitReq = await walletClient.prepareTransactionRequest({
    account,
    to: USDC_BASE_SEPOLIA,
    data: permitTxData,
    chain: baseSepolia,
  });
  let permitTxHash;
  try {
    permitTxHash = await walletClient.sendTransaction(permitReq);
  } catch (e) {
    throw new Error('permit broadcast failed: ' + String(e.message || e).slice(0, 200));
  }
  // Wait for permit confirmation (1 block).
  let permitReceipt = null;
  for (let i = 0; i < 40; i++) {
    try {
      permitReceipt = await publicClient.getTransactionReceipt({ hash: permitTxHash });
      if (permitReceipt && permitReceipt.blockNumber) break;
    } catch (_) { /* not mined yet */ }
    await new Promise(r => setTimeout(r, 3000));
  }
  if (!permitReceipt || !permitReceipt.blockNumber) {
    throw new Error('permit submitted but not confirmed in time: ' + permitTxHash);
  }
  if (permitReceipt.status !== 'success') {
    throw new Error('permit transaction reverted: ' + permitTxHash);
  }

    // Step 2 — transferFrom(owner, spender, value): the spender (seller) pulls
    // the permitted amount into its own wallet. Same gas payer (seller).
  // HARDENING (Day 9 live): the RPC node may serve a slightly stale allowance
  // view right after the permit confirms (eventual consistency). Poll
  // allowance[owner][spender] until it is >= value (or timeout), then send the
  // transferFrom. This eliminates the intermittent "transfer amount exceeds
  // allowance" estimate failure seen when broadcast followed confirm too fast.
  const allowAbi = [{ name: 'allowance', type: 'function', stateMutability: 'view', inputs: [{ name: 'o', type: 'address' }, { name: 's', type: 'address' }], outputs: [{ name: '', type: 'uint256' }] }];
  let allowanceReady = false;
  for (let i = 0; i < 12; i++) {
    try {
      const allow = await publicClient.readContract({ address: USDC_BASE_SEPOLIA, abi: allowAbi, functionName: 'allowance', args: [owner, spender] });
      if (allow >= BigInt(valueRaw)) { allowanceReady = true; break; }
    } catch (_) { /* retry */ }
    await new Promise(r => setTimeout(r, 1500));
  }
  if (!allowanceReady) {
    throw new Error('settlement allowance not visible after permit broadcast (permit allowed=' + allowanceReady + '); aborting before transferFrom');
  }
  const pullCalldata = encodeAbiParameters(
    parseAbiParameters('address,address,uint256'),
    [owner, spender, BigInt(valueRaw)]
  );
  const pullTxData = TRANSFER_FROM_SELECTOR + pullCalldata.slice(2);
  const pullReq = await walletClient.prepareTransactionRequest({
    account,
    to: USDC_BASE_SEPOLIA,
    data: pullTxData,
    chain: baseSepolia,
  });
  let pullTxHash;
  try {
    pullTxHash = await walletClient.sendTransaction(pullReq);
  } catch (e) {
    throw new Error('transferFrom broadcast failed: ' + String(e.message || e).slice(0, 200));
  }
  // Wait for transferFrom confirmation.
  let pullReceipt = null;
  for (let i = 0; i < 40; i++) {
    try {
      pullReceipt = await publicClient.getTransactionReceipt({ hash: pullTxHash });
      if (pullReceipt && pullReceipt.blockNumber) break;
    } catch (_) { /* not mined yet */ }
    await new Promise(r => setTimeout(r, 3000));
  }
  if (!pullReceipt || !pullReceipt.blockNumber) {
    throw new Error('transferFrom submitted but not confirmed in time: ' + pullTxHash);
  }
  if (pullReceipt.status !== 'success') {
    throw new Error('transferFrom transaction reverted: ' + pullTxHash);
  }
  // Return the transferFrom tx hash as THE settlement receipt (the funds moved
  // in this transaction); the permit's hash is recorded as permitTxHash.
  return {
    txHash: pullTxHash,
    permitTxHash,
    blockNumber: String(pullReceipt.blockNumber),
    status: 'settled',
  };
}

// ---- EIP-3009 settlement: broadcast transferWithAuthorization (single tx) ----
// EIP-3009: the 'to' holder (seller) submits the signed authorization and pays
// gas; the transfer moves from->to directly (no allowance step). Returns
// { txHash, blockNumber, status }.
async function settleEip3009(auth, signature, { confirmations = 1 } = {}) {
  const { publicClient, walletClient, account } = clients();
  if (!walletClient || !account) {
    throw new Error('self-hosted settlement requires AX_SELLER_PRIVATE_KEY (seller wallet pays gas)');
  }
  const owner = String(auth.from).toLowerCase();
  const spender = String(auth.to).toLowerCase();
  const valueRaw = auth.value;
  // transferWithAuthorization(from,to,value,validAfter,validBefore,nonce,v,r,s)
  const calldata = encodeAbiParameters(
    parseAbiParameters('address,address,uint256,uint256,uint256,bytes32,uint8,bytes32,bytes32'),
    [
      owner,
      spender,
      BigInt(valueRaw),
      BigInt(auth.validAfter),
      BigInt(auth.validBefore),
      auth.nonce,                              // bytes32 hex (already validated)
      parseInt(signature.slice(130, 132), 16), // v
      ('0x' + signature.slice(2, 66)),         // r
      ('0x' + signature.slice(66, 130)),       // s
    ]
  );
  const txData = TWA_SELECTOR + calldata.slice(2);
  const req = await walletClient.prepareTransactionRequest({
    account,
    to: USDC_BASE_SEPOLIA,
    data: txData,
    chain: baseSepolia,
  });
  let txHash;
  try {
    txHash = await walletClient.sendTransaction(req);
  } catch (e) {
    throw new Error('transferWithAuthorization broadcast failed: ' + String(e.message || e).slice(0, 200));
  }
  let receipt = null;
  for (let i = 0; i < 40; i++) {
    try {
      receipt = await publicClient.getTransactionReceipt({ hash: txHash });
      if (receipt && receipt.blockNumber) break;
    } catch (_) { /* not mined yet */ }
    await new Promise(r => setTimeout(r, 3000));
  }
  if (!receipt || !receipt.blockNumber) {
    throw new Error('transferWithAuthorization submitted but not confirmed in time: ' + txHash);
  }
  if (receipt.status !== 'success') {
    throw new Error('transferWithAuthorization transaction reverted: ' + txHash);
  }
  return {
    txHash,
    blockNumber: String(receipt.blockNumber),
    status: 'settled',
  };
}

// ---- Challenge constructor (PAYMENT-REQUIRED) ----------------------------------
function buildChallenge({ amountUsd, payTo, network, asset }) {
  const amountRaw = rawUnits(amountUsd === undefined ? DEFAULT_FEE_USD : amountUsd);
  const seller = payTo || getSellerAddress() || '';
  const net = network || NETWORK_CAIP2_BASE_SEPOLIA;
  const ass = asset || USDC_BASE_SEPOLIA;
  return {
    error: '402 Payment Required',
    scheme: 'x402',
    network: net,
    asset: ass,
    payTo: seller,
    amount: amountRaw,
    facilitator: 'self',
    scheme: 'exact',
    maxTimeoutSeconds: DEFAULT_MAX_TIMEOUT_SECONDS,
  };
}

// Fee helper (same API as x402.rawUnits).
function rawUnits(usdAmount) {
  return String(Math.round(Number(usdAmount) * 10 ** USDC_DECIMALS));
}

// ---- Nonce storage for the gateway (in-process fallback + injected store) ------
// The gateway keeps its own nonce->{status,response} map so replay protection
// works even when the PostgREST store is not configured (test/offline mode).
const nonceStore = new Map(); // nonceLower -> { status: 'settled'|'pending'|'failed', response?... }
// Bound the in-process nonce map (memory-DoS guard, security sprint Item 4):
// cap the number of retained entries and evict the oldest settled/failed ones
// beyond that. Pending entries are never evicted (they are in-flight), but a
// settled entry older than the cap is safe to drop — its replay protection is
// already durably enforced by the nonce-bound idempotency store.
const NONCE_STORE_MAX = 100000;
function setNonce(nonce, status, response) {
  if (nonceStore.size >= NONCE_STORE_MAX && !nonceStore.has(String(nonce).toLowerCase())) {
    const oldest = nonceStore.keys().next().value;
    nonceStore.delete(oldest);
  }
  nonceStore.set(String(nonce).toLowerCase(), { status, response: response || null });
}
function getNonce(nonce) {
  return nonceStore.get(String(nonce).toLowerCase()) || null;
}
function clearNonces() { nonceStore.clear(); }

// ---- Header names (documented contract) ----------------------------------------
const HEADERS = {
  PAYMENT_REQUIRED: 'payment-required',
  PAYMENT_SIGNATURE: 'payment-signature',
  PAYMENT_RESPONSE: 'payment-response',
};

function parseChainId(network) {
  const m = /^eip155:(\d+)$/.exec(String(network || ''));
  return m ? Number(m[1]) : BASE_SEPOLIA_CHAIN_ID;
}

// ============================================================================
// DAY 11, ITEM 4 — RAIL-AGNOSTIC COMMITMENT LIFECYCLE WIRING
// ----------------------------------------------------------------------------
// The gateway now issues a GOVERENED COMMITMENT (Trade Manifest) BEFORE any
// payment challenge, and a SETTLEMENT-METHOD-NEUTRAL requirement R derived
// from it. The settlement method S that realises R is resolved at execution
// time through the rail registry — x402 is no longer mandatory.
//
//   request -> manifest (commitment) -> R (neutral) -> 402 (x402 + mpp
//   challenges) -> credential -> rail.validate(R) -> route -> rail.settle()
//   -> Spend Receipt (commitment <-> railReference)
//
// The modules below are leaf modules (no require-back into gateway.js), so
// this wiring cannot create a circular-require trap.
const commitmentMod = require('./commitment.js');
const requirementMod = require('./requirement.js');
const receiptMod = require('./receipt.js');
const railsMod = require('./rails/index.js');

// Commitment-flow facade consumed by route-server.js. Also proves the schema,
// R issuance, registry and receipt modules load and expose their interfaces.
const commitmentFlow = {
  // Issue the governed commitment from a demand payload, then issue exactly
  // one settlement-method-neutral requirement R derived from it.
  issueFromPayload({ buyer, seller, capability, deadline, amountRaw, currency }) {
    const manifest = commitmentMod.buildManifest({
      commitmentId: commitmentMod.newCommitmentId(),
      buyerAgentId: buyer,
      sellerAgentId: seller,
      capability,
      price: { amount: String(amountRaw), currency: currency || 'USDC', decimals: 6 },
      acceptanceCriteria: { type: 'hash', value: 'sha256:ax-router-phase1' },
      deadline,
      cancelCondition: 'buyer-cancel-before-delivery',
    });
    const R = requirementMod.issueRequirement({
      commitmentId: manifest.commitmentId,
      payee: seller,
      amt: String(manifest.price.amount),
      cur: manifest.price.currency,
      ttlSeconds: 300,
    });
    // Enforce the manifest binding at ISSUE time too: R must carry exactly the
    // manifest's amount + currency (critical rule: a spend bound to a manifest
    // is denied when amount or currency differs).
    const binding = commitmentMod.checkSpendBinding(manifest, { amount: R.amt, currency: R.cur });
    if (!binding.ok) {
      throw new Error('commitment flow: R diverged from manifest: ' + binding.reason);
    }
    return { manifest, requirement: R };
  },

  // Consume the R nonce on successful gate commit (single-use, replay-rejected).
  consumeRequirement(R) {
    if (!R || !R.eta) return { ok: false, reason: 'no requirement eta provided' };
    return requirementMod.consumeNonce(R.eta);
  },

  requirementStatus(nonce) { return requirementMod.nonceStatus(nonce); },

  // Build the Spend Receipt binding the settlement (railReference) to the
  // commitment. NEVER receives the credential — only the public tx reference.
  buildSpendReceipt({ manifest, R, txRef, settledAt }) {
    const shape = {
      commitmentId: (manifest && manifest.commitmentId) || (R && R.commitmentId) || '',
      manifestHash: (manifest && manifest.manifestHash) || null,
      payer: txRef && txRef.payer,
      payee: (txRef && txRef.payee) || (R && R.payee),
      amount: (txRef && txRef.amount) || (R && R.amt) || '',
      currency: (txRef && txRef.currency) || (R && R.cur) || '',
      rail: (txRef && txRef.rail) || 'x402',
      railReference: txRef && txRef.railReference,
      settledAt: settledAt || new Date().toISOString(),
      noManifest: !manifest, // spend not bound to a verified manifest -> true
    };
    return receiptMod.buildReceipt(shape);
  },
};

module.exports = {
  commitmentFlow,
  commitmentMod,
  requirementMod,
  receiptMod,
  railsMod,
  MODE,
  BASE_SEPOLIA_CHAIN_ID,
  NETWORK_CAIP2_BASE_SEPOLIA,
  USDC_BASE_SEPOLIA,
  USDC_DECIMALS,
  PERMIT_SELECTOR,
  TRANSFER_FROM_SELECTOR,
  TRANSFER_WITH_AUTH_SIG,
  TWA_SELECTOR,
  EIP3009_TYPES,
  EIP3009_TRANSFER_TYPES,
  PATH_ENV,
  probeSignaturePath,
  getSignaturePath,
  pathEvidenceForAsset,
  SELLER_KEY_ENV,
  SELLER_ADDR_ENV,
  DEFAULT_FEE_USD,
  DEFAULT_MAX_TIMEOUT_SECONDS,
  getMode,
  setMode,
  loadSellerKey,
  getSellerAddress,
  clients,
  domainFor,
  EIP3009_TYPES,
  parsePaymentSignatureHeader,
  buildPaymentRequiredHeader,
  buildChallenge,
  structurallyValid,
  verifyAuthorization,
  nonceIdempotencyKey,
  settleAuthorization,
  rawUnits,
  nonceStore,
  setNonce,
  getNonce,
  clearNonces,
  HEADERS,
  parseChainId,
  baseSepolia,
};