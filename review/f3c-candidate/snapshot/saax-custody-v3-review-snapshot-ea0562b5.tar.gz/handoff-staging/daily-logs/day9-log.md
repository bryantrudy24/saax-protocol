# AX Router — Day 9 Build Log: Self-Hosted x402 Payment Gateway

> Chronological record of replacing the Nevermined facilitator (sandbox dead /
> unreliable) with a DIRECT self-hosted x402 gateway integrated into the AX
> Router Docker stack. No third-party facilitator. The operator controls
> verification and settlement. Base Sepolia testnet only.

---

## 0. Pre-Day 9: Day 8 state verification (all confirmed)

| Check | Result |
|---|---|
| Docker Postgres + PostgREST running/healthy | ✅ `ax_router_db` Up (healthy), `ax_router_postgrest` Up (8h) |
| Day 8 tests passing against Docker | ✅ Item1 (idempotency) ALL PASS; Item2 (rate limit) ALL PASS **in supabase store mode against Docker PostgREST**; Item3 (kill switch) ALL PASS; Item4 (reputation) ALL PASS 5/5 |
| AX_X402_VERIFY_MODE=mock, AX_FEEDBACK_SIGN_MODE=mock, AX_MPP_ENABLED unset | ✅ defaults hold; no live flags in .env |
| No wallet provisioned, no live flags flipped | ✅ (Day 9 provisions the seller wallet; Day-8 live flags remain unset) |

---

## 1. Item 1 — Seller wallet (viem)

- `scripts/gen-seller-wallet.js` — `generatePrivateKey()` + `privateKeyToAccount()`.
- Wallet stored in `ax-router/.env`:
  - `AX_SELLER_PRIVATE_KEY=0x75df...11e` (never printed in logs here)
  - `AX_SELLER_ADDRESS=0x6611Fadc959c323C4CDCDd54FBb415954d795fDF`
- `.env` read-back-verified. Project is NOT a git repo → "never commit" holds by construction.
- **Operator action:** fund the seller wallet with testnet ETH (gas) + testnet USDC
  (Circle faucet) to flip from dry-run to real broadcast.

---

## 2. Item 2 — `endpoint/gateway.js` (self-hosted x402 module, built from viem)

**402 Challenge** — when a request hits `/route` without a `PAYMENT-SIGNATURE`
header, returns `402 Payment Required` with a `PAYMENT-REQUIRED` header
(base64 JSON): `{ network: "eip155:84532", asset: "0x036CbD...CF7e", payTo:
<seller wallet>, amount: "50000" ($0.05 USDC, 6 dp), facilitator: "self",
scheme: "exact" }`.

**Payment verification** — `verifyAuthorization()`:
- EIP-712 typed-data verification via viem `verifyTypedData` against the
  `TransferWithAuthorization` domain (USDC Base Sepolia: name "USDC", version
  "2", chainId 84532, verifying contract — **verified on-chain** via
  `scripts/probe-usdc-domain.js`: DOMAIN_SEPARATOR `0x71f1...9818` matches the
  local keccak reconstruction, match: YES).
- Binds: signer (recovered == authorization.from), recipient (to == seller
  wallet), amount (value == required), scheme (exact), network
  (eip155:84532), asset (USDC Base Sepolia), validity window
  (validAfter <= now < validBefore), nonce (non-zero bytes32).
- Any failure → `{ verified:false, reason }` → 402 with the reason; NO routing.

**Settlement** — `settleAuthorization()`:
- Broadcasts the signed `transferWithAuthorization` to Base Sepolia via
  `walletClient.sendTransaction` with the seller wallet as `from` (pays gas,
  per EIP-3009). Calldata: `0x7b7df7eb` selector + abi-encoded
  (from, to, value, validAfter, validBefore, nonce, v, r, s).
- Waits for **1 confirmation** (`getTransactionReceipt`, up to 40×3s).
- Returns `{ txHash, blockNumber, status: "settled" }`.
- Receipt header: `PAYMENT-RESPONSE` (base64) `{ transactionHash, status:
  "settled" }` (+ `dryRun: true` when `AX_GATEWAY_DRY_RUN=1`).
- On revert/no-gas → 502 `{error:"settlement failed", reason}`; no partial
  charge (funds never move if the broadcast reverts).

**Test seam** — `AX_GATEWAY_DRY_RUN=1` returns a marked synthetic receipt
(txHash `dryrun_<uuid>`) with no RPC — the Item 5 harness runs the whole
pipeline with zero funds.

---

## 3. Item 3 — Wiring `/route` (AX_X402_MODE=self)

`endpoint/route-server.js`:
- `gateway.getMode() === 'self'` selects the gateway branch for verification
  (the existing mock branch is untouched — `x-x402-mock` legacy and the
  mock-signature path still work when `AX_X402_MODE` is unset/mock).
- 402 challenge branch emits the `PAYMENT-REQUIRED` header in self mode.
- Settlement branch: after routing succeeds, broadcasts the buyer's signed
  authorization and attaches the `PAYMENT-RESPONSE` header.
- Kill switch treats self mode as LIVE (settlement is real), so
  `AX_KILL_SWITCH=true` halts it (503), not the mock lane.
- `/health` reports `mode: 'self'`, `x402Mode`, and the seller address.

---

## 4. Item 4 — EIP-3009 nonce-bound idempotency

- `gateway.nonceIdempotencyKey(nonce)` = `'nnonce:' + sha256(nonce)`.
- In self mode, the payment header's nonce OVERRIDES the client-supplied
  `Idempotency-Key`/derived key in the idempotency gate → re-presenting the
  same signed authorization under ANY request identifier collides with the
  settled/pending row.
- In-process nonce guard (defense in depth): settled nonce → 402 rejected;
  pending nonce → 409; on success → `setNonce(nonce, 'settled')`.
- Replay → cached response (identical body, no new settlement header) or 409.
  Proven in T3 and T6: same signature under a FRESH request key returns the
  identical cached body with no payment-response header (no double charge).

---

## 5. Item 5 — `scripts/test-gateway.js` (E2E harness, dry-run by default)

Full buyer flow: 402 → EIP-3009 signature → verify → routing → settle → receipt.

| Test | Scenario | Result |
|---|---|---|
| T1 | 402 challenge, PAYMENT-REQUIRED header w/ network eip155:84532, asset USDC Base Sepolia, payTo seller, amount 50000, facilitator self, scheme exact | **PASS** |
| T2 | Valid EIP-3009 auth → verify (mode=self) → routing (3 matches) → settle (dry-run txHash) → PAYMENT-RESPONSE receipt status settled | **PASS** |
| T3 | Replay same signature → cached identical body, NO payment-response (no double charge) | **PASS** |
| T4 | Invalid signature (attacker key + forged from) → 402, no routing | **PASS** |
| T5 | Expired authorization (validBefore past) → 402 "authorization expired", no routing | **PASS** |
| T6 | Fresh request key + SAME nonce (Item 4) → cached identical body, no double settlement | **PASS** |
| T7 | Day 8 rate limit 61/min → 429 before verification | **PASS** |
| T8 | Day 8 kill switch → 503 halted, no payment headers | **PASS** |
| T9 | Buyer reputation: signer recovery resolves; mock header IGNORED in self mode (rep 0, no discount) | **PASS** |

Independent probes:
- `scripts/probe-killswitch-zero-rpc.js` — valid EIP-3009 auth + kill-switch ON
  → 503, no payment-required, no payment-response, nonce store untouched:
  **PASS (zero RPC/broadcast)**.
- `scripts/probe-real-broadcast.js` — real broadcast mode, wallets UNFUNDED →
  clean 502 `settlement failed` (`gas required exceeds allowance (0)`), no
  partial charge: **PASS (clean failure mode)**.
- `scripts/probe-usdc-domain.js` — Base Sepolia USDC name "USDC", version "2",
  DOMAIN_SEPARATOR matches keccak reconstruction: **PASS (match YES)**.

---

## 6. Item 6 — Day 8 controls with the gateway active

| Control | With self-hosted gateway | Evidence |
|---|---|---|
| Idempotency (nonce-bound) | Replay same EIP-3009 nonce → cached response (identical body), no second settlement; fresh key + same nonce still collides | T3, T6 PASS |
| Rate limiting | 61/min → 61st 429 before verification (fire order: kill switch → rate limit → idempotency → sanitize → verify) | T7 PASS |
| Kill switch | AX_KILL_SWITCH=true + valid auth → 503, zero RPC/broadcast, no headers | T8 + zero-RPC probe PASS |
| Buyer reputation | Signer recovery from payment signature resolves (source=signature); mock header ignored in self mode | T9 PASS |

Day 8 regression suites re-run after the gateway wiring: Item1, Item2, Item3
ALL PASS (unchanged).

---

## 7. Continuous improvement loop captures

Iteration 1 failures (all fixed, none disabled):
1. **T8 probe crash** — inline kill-switch HTTP request didn't capture
   `headers`. Fixed (capture headers in resolve).
2. **T3/T6 replay assertions** — assumed the cached response carries a
   `replay` marker or fresh settlement header. The real contract: cached body
   is IDENTICAL to the original and has NO payment-response header. Assertions
   corrected; the underlying replay protection was already correct (verified
   IDENTICAL_TO_ORIGINAL + no fresh settlement).
3. **T9 rate-limit contamination** — T7's 61-request burst exhausted the IP
   window, so T9 hit 429. Moved T9 to its own server instance (clean window).
4. **USDC domain name** — probe proved the Base Sepolia USDC name is "USDC",
   not mainnet's "USD Coin". Gateway default corrected to the verified value.
5. **Kill switch self-mode** — self mode now treated as LIVE by the kill
   switch (it halts real settlement, not the mock lane).

---

## 8. What remains before live mode

1. **Operator funding** (required for real settlement):
   - Seller wallet `0x6611Fadc959c323C4CDCDd54FBb415954d795fDF` needs testnet
     ETH (gas) + testnet USDC (Circle faucet, Base Sepolia).
   - A buyer wallet needs testnet USDC to sign the transferWithAuthorization.
2. Re-run `scripts/test-gateway.js` with `AX_GATEWAY_DRY_RUN=0` to observe a
   REAL broadcast (`payment-response` carries an on-chain txHash), then verify
   the seller balance increases.
3. Live-mode decisions (mainnet Base, real payTo, real fee) remain operator
   gates per the Day 8 checklist — NOT flipped in this sprint.

## 9. Files changed/created

- `endpoint/gateway.js` (new) — self-hosted x402 gateway (402 challenge, EIP-712
  verify, EIP-3009 settlement, nonce store, header contract).
- `endpoint/route-server.js` (modified) — self-mode branch, PAYMENT-REQUIRED/
  PAYMENT-RESPONSE headers, nonce-bound idempotency, kill-switch live-mode,
  reputation-from-signer, health reporting.
- `scripts/test-gateway.js` (new) — E2E harness (T1–T9).
- `scripts/gen-seller-wallet.js` (new) — wallet generation.
- `scripts/probe-usdc-domain.js` (new) — on-chain domain verification.
- `scripts/probe-killswitch-zero-rpc.js` (new) — zero-RPC kill-switch proof.
- `scripts/probe-real-broadcast.js` (new) — real-broadcast clean-failure proof.
- `.env` (modified) — AX_SELLER_PRIVATE_KEY/AX_SELLER_ADDRESS added.
- `package.json` (modified) — viem@2.57.2, dotenv@18.0.5 added.

Dependencies installed: `viem@2.57.2`, `dotenv@18.0.5` (no external spend;
local npm only).