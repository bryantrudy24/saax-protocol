# AX Router — Day 5 Log: Payment Routing Logic (Mock Mode)

Date: 2026-10-01 (run 742f8931)

## PRE-DAY 5 FIXES

### Fix 1 — x402 Payment Verification Path: Mock + Live branches (APPLIED)
- **Config flag (the single swap point):** `AX_X402_VERIFY_MODE=mock|live`, default `mock` (Sprint 1). Documented in `daily-logs/day7-wallet-checklist.md` §1 with the exact wallet-time steps.
- **Branch structure** (`endpoint/x402.js`):
  - `verifyPaymentPayload(payload, requirements)` — the mock-vs-live decision point. Reads the mode at call time (`getVerifyMode()`), so flipping the env var is the ONLY change needed.
  - **Mock branch:** structural validation + `extra.mock===true` marker from `signMockPayload()`. No keys.
  - **Live branch (inert until wallet):** real ECDSA `verifyMessage` recovering `authorization.from` + full exact/upto requirement checks (authorized max vs settle amount, recipient binding via `auth.to`/`value`, validity window, network/asset match). Without `AX_X402_PRIVATE_KEY` it returns `verified:false, "live verification requires AX_X402_PRIVATE_KEY"` — wired, not stubbed.
- **Function signatures (documented):**
  - `signMockPayload(requirements) -> PaymentPayload` — structurally valid x402 V2 payload, 65-byte zero signature (valid length, cryptographically fake)
  - `signLivePayload(requirements) -> Promise<PaymentPayload>` — real EIP-191 signature over the canonical message (throws without the wallet key)
  - `verifyPaymentPayload(payload, requirements) -> { verified, mode, reason }`
  - `parsePaymentSignatureHeader(header) -> { ok, payload, reason }` — base64 JSON structural parse
  - `validatePayTo(payTo, network) -> { ok, address, reason }` — EVM 0x+40 hex / Solana base58
  - `settleX402Mock(payload) -> receipt` — mock settlement, live-shaped receipt
- **Mock-vs-live proof (test 4):** mock branch accepts the mock payload; live branch REJECTS the same payload (`r must be 0 < r < CURVE.n`) and ACCEPTS a genuinely-signed payload — the live branch is real crypto, unit-tested in isolation.
- **Note (Day 4 → Day 5 correction):** the Day 4 placeholder `0x0000...AaXp402` is not valid hex; the new payTo gate rejects it. Replaced with `0x0000...0001` (structurally valid placeholder). The fee address now passes the same gate suppliers must pass.

### Fix 2 — Buyer Reputation Authentication Dependency (FLAGGED, not built)
- **Flagged in the Day 5 log and in** `day7-wallet-checklist.md` §2: the discount tiers currently trust the client-supplied `x-mock-buyer-rep` header. Live, buyer reputation MUST come from a verified source, not a client header.
- **Two candidate approaches (named, not built):**
  - (a) x402 payment payload signature resolving to an on-chain agent identity (recovered `authorization.from` → ERC-8004 Identity Registry → ReputationRegistry)
  - (b) signed request from the buyer's wallet (SIWX/CAIP-122-style signer → reputation key)
- **Day 7 checklist item:** yes — §2 carries the swap steps; `computeFee` stays unchanged (only the source swaps).
- **No behavior change:** mock header stays for Sprint 1 testing.

## DAY 5 — PAYMENT ROUTING LOGIC (MOCK MODE)

### Routing decision tree (`endpoint/router.js`)
For each matched supplier, inspect its registration file (`endpoint/supplier-registrations.json`):

```
registration.rails
├── x402: payTo advertised AND asset USDC AND network in [base|polygon|solana]
│        AND payTo passes validatePayTo()
│        └──> rail = x402  (detail: scheme exact|upto, payTo, asset, network, maxTimeoutSeconds)
├── mpp:  fiat rails / Stripe-native settlement required
│        └──> rail = mpp  (settlement STUBBED in Sprint 1)
└── neither
        └──> rail = unsupported → EXCLUDED from returned match list (never silently routed)
```

Rules enforced:
- **No silent rails.** A supplier that advertises neither x402 nor MPP is excluded with reason `unsupported`.
- **payTo gate before payload construction.** Invalid payTo → supplier excluded, never paid.
- **exact vs upto:** fixed-price suppliers route `exact`; usage-based suppliers route `upto` (per registration `pricing`/`scheme` — SYBIL `exact`, Apex Leviathan `upto`).

### x402 settlement path (`endpoint/x402.js` + `endpoint/settle.js`)
- `exact` scheme (fixed-price): EIP-3009-style payload — `payload.payload.signature` + `authorization { from, to, value, validAfter, validBefore, nonce }`, `value === accepted.amount`.
- `upto` scheme (usage-based): max-amount authorization (`permit2` method shape), settle-time actual ≤ authorized max (mock metering settles 60% in tests).
- Mock signing: structurally valid payload, fake signature. Mock verification branch accepts; live branch rejects.
- Receipt (mock) — **field-for-field identical to the documented live receipt:**
  `{ rail: "x402", scheme: "exact"|"upto", amount: "<raw units>", asset, network, payTo, txHash: "mock_<uuid>", status: "settled" }`
  Downstream logging needs no change when live flips on.

### MPP path — stub only
- Router selects MPP when the supplier advertises fiat/Stripe-native rails.
- Settlement logs `{ rail: "mpp", status: "stubbed", reason: "Sprint 1 mock mode" }`.
- `mppx` NOT installed; Stripe rails NOT configured — both deferred to Day 7+ (wallet live + a real MPP supplier exists in the index). See section ROUTE-AROUND.

### Security gate (confirmed on the payment path)
- Demand-text sanitization at the HTTP boundary **remains in force** (422 on empty) — not loosened for the payment layer. Verified E2E 5.
- Payment payloads are **untrusted input**: parsed structurally (`parsePaymentSignatureHeader` + `structurallyValid`), fields coerced, nothing executed/evaluated/echoed.
- Supplier payTo **format validation** before any payment payload construction (`validatePayTo`) — EVM 0x+40 hex, Solana base58 range.
- E2E 4 confirms a malformed PAYMENT-SIGNATURE is rejected with 402 + `rejectReason`.

## TEST OUTPUTS (all five required)

### T1. Security scan through the full endpoint → x402 for SYBIL + Apex Leviathan, mock receipt returned
```
POST /route {"capability":"security scan",...} + PAYMENT-SIGNATURE (base64 mock payload)
HTTP 200
SYBIL          rail=x402 scheme=exact status=settled txHash=mock_<uuid>
Apex Leviathan rail=x402 scheme=upto status=settled amount=30000 (<= 50000 authorized)
Surf AI        rail=mpp  status=stubbed reason="Sprint 1 mock mode"
Captain Dackie/Agent 2290 excluded (unsupported)
decisionLog: 5 entries (x402,x402,mpp,unsupported,unsupported)
```
PASS (endpoint E2E + unit).

### T2. MPP-only supplier → MPP selected, stubbed, NO x402 attempt
```
Surf AI (51085) -> rail=mpp, railDetail=null (no x402 payload built),
settlement={ rail:"mpp", status:"stubbed", reason:"Sprint 1 mock mode" }
```
PASS (unit).

### T3. No-rail supplier → excluded with reason unsupported
```
Captain Dackie/Agent 2290 -> excluded: ["supplier advertises neither x402 nor MPP rail"],
routed=[], decisionLog selectedRail=unsupported
```
PASS (unit).

### T4. AX_X402_VERIFY_MODE=mock accepts mock signature; live branch rejects the same payload
```
mock branch:  { verified:true,  mode:"mock" }
live branch:  { verified:false, mode:"live", reason:"signature verification failed: r must be 0 < r < CURVE.n" }
live genuine: { verified:true,  mode:"live" }   (proves the live branch is real crypto, not a stub)
```
PASS (unit, throwaway key only).

### T5. Mock receipt structure === documented live receipt structure
```
{ rail:"x402", scheme, amount, asset, network, payTo, txHash:"mock_<uuid>", status:"settled" }
```
Field-for-field match; receipt carries every documented live field. PASS.

### Endpoint-level (additional)
- No payment header → HTTP 402 x402 v2 challenge (`error: 402 Payment Required`, `accepts[0].scheme: x402`, `schemes: [exact, upto]`). PASS.
- Legacy `x-x402-mock: mock` still routes (Day 4 compat). PASS.
- Malformed `payment-signature` → 402 + rejectReason. PASS.
- `capability:"!!!"` → 422 security gate. PASS.

## MOCKED vs STUBBED vs REAL vs NEXT

| Layer | State |
|---|---|
| **Real** | Ranking engine (124 agents, on-chain reputation), capability match + floor, ReputationRegistry fetch layer, sanitization gate, RLS policy, **the live verification branch itself (real ECDSA, unit-tested)** |
| **Mocked** | x402 signing (`signMockPayload`, fake signature), verification branch selection (`AX_X402_VERIFY_MODE=mock`), settlement (mock receipts), buyer-rep discount input (header) |
| **Stubbed** | MPP settlement (`mppx` not installed; Stripe rails not configured — Day 7+), upto settle-time metering (60% simulation) |
| **Next** | Day 6; Day 7 wallet wiring flips `AX_X402_VERIFY_MODE=live` + adds `AX_X402_PRIVATE_KEY`, buyer-rep auth source, MPP real flow |

## BUYER REPUTATION AUTHENTICATION DEPENDENCY (Day 7 checklist item)
Restated for the Day 7 checklist (`daily-logs/day7-wallet-checklist.md` §2):
1. Choose (a) x402-signature→on-chain identity or (b) signed buyer request.
2. Remove `x-mock-buyer-rep` from the fee path.
3. Verify identity on the payment path BEFORE applying discounts.
4. Keep `computeFee` unchanged — swap only the reputation SOURCE.

## ROUTE-AROUNDS / BLOCKERS
- **mppx / MPP dependency** deferred per route-around protocol: no install (would be an external dependency + Stripe config requiring spend/keys). Logged as stubbed with exact deferred dependency: `mppx` client package + Stripe rails (Day 7+, when wallet is live and a real MPP supplier exists in the index). No sprint blockage.
- **Vercel reauth pending** → local station HTTP server (inherited from Day 4). No impact on Day 5.
- Vercel/Stripe/Make.com keys — no external spend anywhere on the payment path in Sprint 1.

## DAILY SUMMARY (5 lines)
- Built: routing decision tree (x402 | mpp | unsupported per supplier registration), x402 mock settlement path (exact + upto schemes, live-shaped receipts), MPP stub, PAYMENT-SIGNATURE structural verification behind the single `AX_X402_VERIFY_MODE` flag; applied both pre-Day-5 fixes.
- Tested: all 5 required outputs + 3 extra endpoint checks — 24 unit + 13 E2E assertions, all PASS; live branch proven to reject mock signatures and accept genuine ECDSA.
- Broke: nothing (Day 4 placeholder payTo corrected — it was not valid hex, so the new gate correctly rejected it; replaced with a valid placeholder).
- Mocked: signing, mock verify branch, settlement, buyer-rep header; stubbed: MPP; real: live verify branch, ranking, reputation layer, security gates.
- Next: Day 6 — no progression until Day 5 is accepted by the operator.