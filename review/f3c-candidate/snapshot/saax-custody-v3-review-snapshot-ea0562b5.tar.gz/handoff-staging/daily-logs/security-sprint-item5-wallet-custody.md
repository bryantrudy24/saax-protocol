# AX Router — Wallet Custody Hardening (Security Sprint Item 5)

Status: DONE — risk documented, mitigation proposed, testnet key rotated, no
.env in any deliverable.

## 1. Documented custody risk

The current seller wallet is a **single viem-generated private key** stored in
plaintext in `ax-router/.env` (`AX_SELLER_PRIVATE_KEY`). On mainnet this is a
single point of failure:

- The key controls ALL seller funds (every x402 settlement pays into this
  address; the same key signs every broadcast).
- It resides in a file that any process with read access to the project could
  read (no HSM, no KMS, no hardware boundary).
- It is used for BOTH the settlement signer and the gas payer (fee payer).
  Per the Private Key Adapter guidance: "A fee payer, background automation
  signer, and emergency admin signer should not share one private key."

Operational reality today: **testnet only** (Base Sepolia). No mainnet value
is at risk with the current key, which is why the rotation below is safe to
perform now. The risk becomes material AT mainnet activation.

## 2. Proposed mitigation (for operator sign-off before mainnet)

Options, with trade-offs:

| Option | Trade-off | Verdict |
|---|---|---|
| **A. Multi-signature wallet** (e.g. Safe) as the seller | Settlements require M-of-N signatures; a single stolen key cannot move funds. Higher latency (multi-sig round-trip per settlement), contract deployment cost, and the gateway must hold the Safe's executable signature set. | Best long-term for a custody-heavy settlement flow. |
| **B. Hardware wallet (Ledger/Trezor)** holding the seller key | Key never leaves the device; the gateway signs via USB/HID or a signing service. Requires physical presence for each settlement (or a signing daemon), which conflicts with 24/7 autonomous settlement unless the device stays connected. | Good for the *emergency admin* key; awkward for high-frequency autonomous signing. |
| **C. KMS (AWS KMS / GCP KMS / HashiCorp Vault)** | Key material in a managed HSM; signing via API with IAM-scoped grants; auditable; supports separation of roles (fee payer vs signer). Adds cloud dependency + per-call cost. | Recommended for autonomous settlement: key stays encrypted at rest, never on disk, signer role scoped. |

**Recommended path before mainnet:** split roles — (1) a **fee-payer/gas
wallet** (hot, low balance, refilled periodically), (2) a **settlement signer**
via KMS or Safe, (3) an **emergency admin signer** (hardware) that can rotate
the others or halt via the kill switch. At minimum, adopt Option C (KMS) for
the automated signer and keep the kill-switch file on a path only the admin
can touch. This is recorded for operator acceptance; no code change is
required to adopt it at activation time.

## 3. Testnet key rotation (executed this sprint)

- Generated a fresh testnet seller wallet via `scripts/rotate-seller-wallet.js`.
- Old address: `0x6611Fadc959c323C4CDCDd54FBb415954d795fDF` (archived).
- New address: `0xAd57875a7fdf2cA6F6b3B43D5226790c4A4468fb` (active in `.env`).
- Old key archived to `daily-logs/archived-keys/seller-wallet-ARCHIVED-<ts>.txt`
  with an explicit TESTNET-ONLY, DO-NOT-USE-ON-MAINNET banner.
- No testnet funds were moved (the old wallet is testnet-only; leftover test
  USDC/ETH may remain there — irrelevant to mainnet safety).
- The archive path is excluded from any handoff zip (daily-logs/archived-keys/)
  and is NOT part of the source tree the partner receives.

## 4. .env never committed — verification

- Project has **no .git** directory (confirmed) — nothing to accidentally push.
- `handoff-staging/` contains **no .env** (verified absent).
- The delivered zip `ax-router-handoff-2026-10-04.zip` contains only
  `.env.example` (placeholders), never `.env` (verified in the archive listing).

## 5. Residual risk (accepted for testnet, must be closed for mainnet)

- Single-key custody remains in place on testnet (acceptable: zero value).
- The gateway pays gas from the same key that receives funds (acceptable on
  testnet; split roles before mainnet per §2).
- .env is plaintext on disk (acceptable locally; KMS/hardware removes this at
  mainnet).