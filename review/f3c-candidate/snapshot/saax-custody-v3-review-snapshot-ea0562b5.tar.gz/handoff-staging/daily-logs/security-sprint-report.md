# AX Router — Security Hardening Sprint Report

Date: 2026-10-04
Scope: 8 security test items over the AX Router codebase (self-hosted x402
gateway, payment verification, wallet custody). Continuous loop executed:
test -> fix root cause -> re-run -> repeat until all items green.

---

## Item 1 — Dependency Vulnerability Scan — PASS

- `npm audit`: **0 critical / 0 high / 0 moderate / 0 low** (all severities).
- Installed: dotenv 18.0.5, ethers 6.17.0, viem 2.57.2.
- **Version pinning fixed**: package.json used `^` ranges (`^18.0.5`,
  `^6.17.0`, `^2.57.2`). Changed to **exact pinning** (`18.0.5`, `6.17.0`,
  `2.57.2`). package-lock.json regenerated (`npm install --package-lock-only`)
  and verified all three top-level deps are locked to the exact versions.
- No vulnerable package requires a patch — nothing to remediate beyond pinning.
- Residual risk: none.
- Regression after pinning: all Day 5/6/7/8/9 suites still pass.

## Item 2 — Input Validation Audit — PASS (2 gaps found & fixed)

| Input | Validation | Status |
|---|---|---|
| Payment signature payload (PAYMENT-SIGNATURE header) | base64 -> JSON decode -> structural parse (`structurallyValid`); never executed/evaluated; no shell construction (manual static review). | PASS (no change needed) |
| EIP-3009/EIP-2612 fields (from, to, value, validAfter, validBefore, nonce) | **GAP FIXED**: gateway.verifyAuthorization now type-checks ALL fields (address regex, numeric-string, bounded length) BEFORE any BigInt/verify use; rejects malformed with explicit reason instead of a confusing verify exception. Range checks: validAfter <= now+1d, validBefore <= now+30d. | PASS |
| x402.js live branch validity window | **GAP FIXED**: NaN window (`Number('abc')` -> NaN -> comparisons false -> silently ACCEPTED). Now requires numeric-string validAfter/validBefore/deadline before comparison. | PASS |
| Demand request fields (capability, budget, deadline) | capability: fail-closed sanitization (delimiters/imperatives -> 422, existing). **GAP FIXED**: budget must be finite number or numeric string, deadline must be valid date/timestamp — else 422 at the HTTP boundary. | PASS |
| Agent ID (reputation lookup) | `getAgentByOwner` validates address regex; `agentId` is `Number()`-coerced and checked against the known index (`isKnownAgent`) before on-chain calls in feedback; identity reverse-lookup uses the validated index. | PASS (no change needed) |

## Item 3 — Access Control Review — PASS (1 gap found & fixed)

| Boundary | Verification | Status |
|---|---|---|
| Kill switch = first gate | **GAP FIXED**: handleRoute ran `parsePayload` (400 on malformed body) BEFORE the kill switch. Now the kill switch is the literal first gate — a halted server answers 503 even to a malformed body. | PASS |
| No code path bypasses kill switch | requireKillSwitch(live) halts before body parse, rate limit, idempotency, sanitization, verification. Verified by item3 tests (T4a-d + zero-RPC counter). | PASS |
| Seller wallet key never logged/echoed | gateway.loadSellerKey reads env only; no logging of the key; settlement errors slice messages (no key). Confirmed by source review + secret scan. | PASS |
| Admin-only scripts not HTTP-invocable | route-server serves ONLY /route + /health; no static/file/script endpoints; gen-seller-wallet.js, probe-*.js never required by the server. | PASS |
| Supabase/PostgREST anon cannot read/write ax_router | roles.sql: anon NOLOGIN; schema grants anon SELECT on agents only, ZERO grants on idempotency_keys/rate_limits/ranking_outcomes; RLS enabled with zero policies on strict tables; PostgREST PGRST_DB_ANON_ROLE=anon, PGRST_DB_SCHEMA=ax_router. | PASS |
| **XFF spoofing** | **GAP FIXED**: clientIp trusted X-Forwarded-For unconditionally — an attacker could rotate IPs to bypass the per-IP rate limit. Now XFF is only trusted when `AX_TRUST_PROXY=true` (explicit trusted-proxy config). | PASS |

## Item 4 — x402 Gateway Attack Surface Review — PASS (2 gaps found & fixed)

USENIX Security 2026 four attack classes, mapped to AX Router:

| Attack class | Mitigation status |
|---|---|
| Free shopping (access without payment) | Verify-before-serve: payment verification happens before ranking/routing/settlement (route-server flow: kill -> rate -> idem -> sanitize -> verify -> rank -> route -> settle). No path serves ranked suppliers without a verified payment. Re-verified in code review. PASS |
| Asset theft | Settlement revalidation added: settleAuthorization re-checks recipient == seller, self-transfer forbidden, bounded value, validity window immediately before broadcast. Permit calldata strictly owner->spender->value; transferFrom strictly owner->seller->value. No arbitrary approvals possible. PASS |
| Service denial (payment without delivery) | Settlement happens ONLY after ranking + routing succeed (settle after route). On broadcast failure -> 502, no partial charge, nonce marked failed. PASS |
| Gas abuse (server pays gas for attacker tx) | The seller wallet only ever broadcasts the verified permit + transferFrom for the exact verified amount to itself; no free-form calldata from the client reaches the wallet. Nonce-bound idempotency prevents re-broadcast. PASS |
| Nonce replay | Nonce-hash idempotency key (hash(nonce) as key, overriding client header) + in-process nonce guard (settled->402, pending->409) — re-presented signature under a FRESH request key collides. Verified T6. PASS |
| Untrusted transaction fields | **GAP FIXED**: settleAuthorization now re-validates every field (addresses, bounded numeric value/nonce, validity window) immediately before broadcast, independent of verify. PASS |
| Memory-DoS (nonce map) | **GAP FIXED**: nonceStore capped at 100k entries with oldest eviction. PASS |

## Item 5 — Wallet Custody Hardening — PASS

- Risk documented: single key controls all seller funds; plaintext .env; same
  key is signer + gas payer. File:
  `daily-logs/security-sprint-item5-wallet-custody.md`.
- Mitigation proposed with trade-offs: multi-sig (Safe) vs hardware wallet vs
  KMS; recommended = KMS or Safe for the automated signer + separate fee-payer
  + hardware emergency admin before mainnet.
- **Testnet key rotated**: old `0x6611Fadc...` archived (TESTNET-ONLY banner),
  new `0xAd57875a7fdf2cA6F6b3B43D5226790c4A4468fb` active. Day 9 harness
  passes with the new key.
- `.env` never committed: no .git; no .env in handoff-staging; zip contains
  only .env.example (verified).

## Item 6 — ERC-8004 Feedback Integrity — PASS (gaps fixed)

- Self-feedback prevention: **ADDED** — buildSubmitFeedback rejects when the
  signer wallet owns the target agent (verified CASE A: "self-feedback
  forbidden"). Non-owner builds (CASE B).
- Payment-proof binding: **ADDED** — feedbackHash/URI now bind the x402
  settlement tx hash (paymentProof) + agentId + score, so a proof cannot be
  reused for a different agent/outcome. Live mode REFUSES unbound feedback
  (CASE C). Mock derives a deterministic proof (regression contract kept).
- Score validation: valueDecimals fixed 0 (valid 0-18); scores from the fixed
  OUTCOME_SCORES set (100 / 20 / -50 / 0) — no out-of-range (CASE D).

## Item 7 — Static Analysis — PASS (manual review executed)

- semgrep: not installed; trivy: not installed; eslint: not installed. The
  brief's explicit fallback (manual review of security-sensitive patterns) was
  executed via `scripts/manual-static-review.js`.
- Patterns scanned: eval(), new Function, child_process/exec/spawn, dynamic
  require of variables, shell template interpolation, JSON.parse of untrusted
  input.
- Findings: all `spawn` calls are test/diagnostic harnesses launching the
  route server with a FIXED path (never attacker input). `require(path.join(
  __dirname,...))` uses fixed string paths. No eval, no new Function, no shell
  interpolation. **Zero exploitable findings.**
- Residual: no automated SAST tooling installed; recommend adding semgrep to
  CI before mainnet (a config/process item, not a code gap).

## Item 8 — Secret Detection — PASS (no secrets leaked)

- `scripts/scan.js` + `scripts/scan-secrets-precise.js` over the whole tree
  (excluding .env, node_modules, handoff-staging).
- Findings: 0x+64-hex occurrences are public transaction hashes in
  .output-* / daily-log evidence (not keys). API-prefix matches are prose
  ("live:", "PostgREST") or placeholder values in .env.example. The only real
  key material is the ARCHIVED OLD TESTNET KEY in
  daily-logs/archived-keys/ — deliberately archived, marked TESTNET-ONLY,
  excluded from the handoff zip. docker-compose uses ${POSTGRES_PASSWORD}
  placeholder (no real password).
- Verified: no .env in handoff-staging; archive folder not in staging.

## Regression Confirmation — ALL GREEN

After all fixes (pinning, validation, kill-switch order, XFF, settlement
revalidation, feedback binding, wallet rotation):
- Day 5 unit: ALL PASSED
- Day 5 E2E: ALL PASSED
- Day 6: ALL PASSED
- Day 7 E2E: ALL 4 SCENARIOS PASS
- Day 8 Item 1 (idempotency): ALL PASSED
- Day 8 Item 2 (rate limit): ALL PASSED
- Day 8 Item 3 (kill switch): ALL PASSED
- Day 8 Item 4 (reputation): ALL PASSED
- Day 9 gateway harness (self-hosted x402, dry-run): ALL DAY 9 GATEWAY TESTS PASSED (with rotated seller wallet)

Also: `npm audit` still 0/0/0/0 after changes. Precise secret scan: no real
secret in source or handoff.

## Overall Security Posture

**Defended:** payment signatures are structurally parsed, type-checked, and
EIP-712-verified before any routing/settlement; kill switch is the first gate
and halts with zero RPC; rate limiting resists IP spoofing (trusted-proxy
gated); idempotency is nonce-bound and replay-safe; settlement re-validates
every field and can only ever pay the verified amount to the seller; feedback
is self-feedback-proof and payment-proof-bound; DB access is service-role-only
for all strict tables; dependency tree is clean and fully pinned; manual
static review found no code-execution sinks; secret scan shows no leaked
credentials.

**Remains exposed (accepted risk, operator to decide):** single-key testnet
custody (mitigation proposed — KMS/Safe before mainnet); no automated SAST in
CI (recommend semgrep); MPP/Stripe rail still stubbed (not in scope); the
legacy `x-x402-mock` compat header is processed in mock mode only (live/self
mode ignores it); `AX_X402_MODE` default remains mock so a misconfig cannot
silently enable live settlement (fail-closed default).

## Files changed this sprint

- endpoint/route-server.js — kill switch first gate; budget/deadline 422;
  XFF trusted-proxy gate; removed debug log; AX_IDEMPOTENCY_STORE=memory seam.
- endpoint/gateway.js — EIP-3009/2612 field type+range checks; settlement
  revalidation; nonceStore cap.
- endpoint/x402.js — numeric-string validity window guard (live branch).
- endpoint/feedback.js — self-feedback guard; payment-proof binding; live
  requires proof.
- endpoint/test-day8-item2.js — AX_TRUST_PROXY=true for the IP-simulation harness.
- scripts/test-gateway.js — AX_IDEMPOTENCY_STORE=memory isolation.
- package.json / package-lock.json — exact version pinning.
- .env — seller wallet rotated (new key/address).
- scripts/ — scan.js, scan-secrets-precise.js, manual-static-review.js,
  rotate-seller-wallet.js, clean-idem-store.js, verify-item6.js (tooling).
- daily-logs/security-sprint-item5-wallet-custody.md, daily-logs/archived-keys/
  (old testnet key archive).