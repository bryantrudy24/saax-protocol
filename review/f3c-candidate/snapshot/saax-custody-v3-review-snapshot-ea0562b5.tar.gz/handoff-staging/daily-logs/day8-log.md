# AX Router — Day 8 Build Log (closure run)

> Chronological record of the Day 8 pre-live security-hardening build AND the
> Day 8 closure run (RPC fix, Item 4 harness, kill-switch harness, E2E
> regressions, documents). Sprint 1 does NOT broadcast, does NOT flip live
> mode, does NOT touch a wallet. All tests below are mock-mode or offline
> unit-harness tests unless explicitly noted.

---

## 1. Day 8 Build (original) — the four items

### Item 1 — Idempotency keys on every payment request

**What was built** (`endpoint/idempotency.js`, `endpoint/store.js`):
- `Idempotency-Key` header OR deterministic server-derived key
  `hash(buyerAddress | capability | budget | deadline | nonce)`.
- Persistent store: Supabase `ax_router.idempotency_keys` (RLS ON, zero
  policies → service-role-only) via a minimal PostgREST client
  (`endpoint/store.js`), with an in-memory fallback when no Supabase creds
  are configured (brief-sanctioned route-around).
- State machine: new → insert `pending` → on success `verified`/`settled`
  (with cached `response_status` + `response_body`), on error `failed`.
- Replay rule: `verified`/`settled` with same key+payload → return cached
  response, no re-process. `pending` → **409**. Same key + different payload
  hash (`hash(capability|budget|deadline)`) → **422**.
- TTL 24h, hourly sweep (`SWEEP_INTERVAL_MS`), in-process + pg-side.
- Atomic acquire: SQL RPC `ax_router.acquire_idempotency` using
  `pg_advisory_xact_lock` on a key hash (serializes concurrent duplicates —
  one processes, the other sees `pending` → 409).

**Files:** `endpoint/idempotency.js` (new), `endpoint/store.js` (new),
Supabase migration `ax_router.idempotency_keys` + RPC
`ax_router.acquire_idempotency` (deployed before this log entry).

**Initial harness** (`endpoint/test-day8-item1.js`): T1 cached replay
(same txHash), T2 422, T3 derived key, T4 concurrent no-double-settle +
module-level 409. **ALL PASS** (see §2 below for the post-fix re-run).

### Item 2 — Rate limiting on /route

**What was built** (`endpoint/ratelimit.js`, `endpoint/store.js`):
- Two-tier sliding window at the HTTP boundary, BEFORE sanitization and
  payment verification: per-IP 60/min, per-wallet 30/min.
- Storage: Supabase `ax_router.rate_limits` (RLS ON, zero policies),
  in-memory sliding window with hourly sweep as fallback.
- On limit: **429** + `Retry-After` header, body includes `limitType`
  (`ip`|`wallet`) and the limit. No exemptions (operator wallet obeys too).

**Files:** `endpoint/ratelimit.js` (new), `endpoint/store.js` (shared),
Supabase migration `ax_router.rate_limits`.

**Harness** (`endpoint/test-day8-item2.js`): T1 61st request → 429,
T2 31st wallet request → 429, T3 window reset, T4 fires before verification.
**ALL PASS**.

### Item 3 — Kill switch at the verification layer

**What was built** (`endpoint/killswitch.js`):
- `AX_KILL_SWITCH` (`true`|`false`, default `false`) read at CALL TIME (no
  startup caching) + file-based fallback `AX_KILL_SWITCH_FILE` (file exists =
  ON). Runtime toggle without restart.
- The FIRST gate in `route-server.js` — before idempotency, rate limit,
  sanitization, signature, on-chain, amount.
- On: live verifications → **503** `{status:"halted", reason:"operator_kill_switch"}`,
  nothing else runs. Mock lane stays open when `AX_X402_VERIFY_MODE=mock`.

**Files:** `endpoint/killswitch.js` (new), wiring in `route-server.js`.

**Initial harness** (`endpoint/test-day8-item3.js`): T0 baseline, T1 503,
T2 resumes, T3 file toggle at runtime, T4 first-gate (injection → 503 not
422; over-limit → 503 not 429; malformed → 503 not 409/400). **ALL PASS**.
(Closure run added an RPC-call counter — see §3.)

### Item 4 — Buyer reputation from x402 signature

**What was built** (`endpoint/identity.js`):
- After a live x402 payment verifies, recover the signer from
  `authorization.from`; reverse-lookup `getAgentByOwner(address)` →
  agentId | null (local Day-1 index first, on-chain `ownerOf` probe over the
  known id set as fallback, `getAgentWallet(agentId)` binding checklast).
- Query ReputationRegistry with the Day-2 pattern
  (`getClients(agentId)` → `getSummary(...)`); zero clients → no score → 0.
- Discount tiers: 0 for no agent / no feedback, actual score with feedback.
- `x-mock-buyer-rep` KEPT in mock mode as stand-in; **ignored in live mode**
  (discount derives from the verified signer only).
- Recovered signer ≠ `authorization.from` → **401** (tampered payload).
- Logs every resolution `{ walletAddress, resolvedAgentId, reputationScore,
  discountApplied, source: "signature" | "mock_header" }`.

**Files:** `endpoint/identity.js` (new), wiring in `route-server.js`; ABIs
`abis/IdentityRegistry.json`, `abis/ReputationRegistry.json`; data snapshots
`data/agents-day1-named.json`, `data/agent-ids-day2.json`.

**Initial state:** no dedicated harness existed (zero test coverage) — built
in the closure run (§2 below).

---

## 2. Closure run — Item 1: RPC name mismatch fixed

**Bug (live break in Supabase mode):** the code called
`_supabaseClient.rpc('ax_router_acquire_idempotency', ...)`. The DEPLOYED
function on the live project is `ax_router.acquire_idempotency`. PostgREST
resolves RPC names against the exposed schemas; `ax_router_acquire_idempotency`
does not exist anywhere in the search path → the idempotency acquire would
404/error in Supabase mode (idempotency non-functional in production).

**Fix:**
1. `endpoint/store.js` — the client is now schema-scoped (equivalent of
   `db: { schema: 'ax_router' }`): every request carries
   `Accept-Profile: ax_router` / `Content-Profile: ax_router`. Exposed the
   schema to PostgREST via
   `ALTER ROLE authenticator SET pgrst.db_schemas = 'public, ax_router'`
   (was `public, graphql_public` only → PGRST106 before).
2. `endpoint/idempotency.js` — RPC call changed to the PostgREST-correct
   bare name: `rpc('acquire_idempotency', { p_key, p_payload_hash,
   p_ttl_hours })`.
3. Grants locked down (security fix found during verification): revoked
   PUBLIC and the leftover explicit anon/authenticated EXECUTE on the
   function (from the earlier `GRANT ALL ON ALL ROUTINES` exposure recipe);
   `service_role` is the only API role that can execute. Table grants:
   `idempotency_keys`/`rate_limits` CRUD → service_role, authenticated;
   anon gets usage only (RLS + zero policies = anon sees/affects nothing).

**Before/after diff (code):**

```diff
- // idempotency.js storeAcquire()
-   const { data, error } = await _supabaseClient.rpc('ax_router_acquire_idempotency', {
+   const { data, error } = await _supabaseClient.rpc('acquire_idempotency', {
       p_key: key,
       p_payload_hash: payloadHashValue,
       p_ttl_hours: TTL_HOURS,
     });
```

```diff
- // store.js buildSupabaseClient() — no schema concept; bare auth headers
-   const auth = { apikey: key, Authorization: 'Bearer ' + key };
+   const schema = schemaName || 'ax_router';
+   const scoped = { ...auth, 'Accept-Profile': schema, 'Content-Profile': schema };
+   // every from()/rpc() call now uses `scoped` headers
```

**Supabase-mode verification (live project, deployed function):**

| Check | Result |
|---|---|
| Schema exposed (no more PGRST106) | PROBE1: 42501 permission denied for table (NOT invalid schema) — exposed |
| anon table access | denied (correct — no grants, RLS on) |
| anon RPC execute | 401 `permission denied for function acquire_idempotency` (locked to service_role) |
| T1 same key twice → cached replay path | `{status:"pending","conflict":true}` on 2nd acquire (row exists, no duplicate insert) |
| T2 same key + different payload hash | deployed fn RAISES `payload hash mismatch: idempotency key reused for a different request` → gate maps to **422** |
| T3 pending → 409 | `conflict:true` + `status=pending` → gate returns **409** |
| test-row cleanup | 0 probe rows remain |

---

## 3. Closure run — Item 2: Item 4 test harness (`test-day8-item4.js`)

Added an offline test seam to `identity.js` (`setOfflineStub`) so the
harness runs against fixture registry data — no real RPC, no real wallet,
no real funds (brief constraint). Signed "mock" payloads are REAL ECDSA
signatures made with throwaway wallets over x402's canonical message
(offline crypto).

| Test | Result | Evidence |
|---|---|---|
| T1 mock header 96 → 20% off, source mock_header | **PASS** | rep 96, discount 0.2, `source:"mock_header"` |
| T2 live signed payload → signer recovered, agent resolved, on-chain score 96 → 20% off, source signature | **PASS** | agentId 7, rep 96, discount 0.2, `source:"signature"` |
| T3 live unknown signer → rep 0, no discount | **PASS** | resolvedAgentId null, rep 0, discount 0, source signature |
| T4 tampered payload (signer mismatch) → 401, no processing | **PASS** | ok:false, status 401, "signer mismatch" |
| T5 x-mock-buyer-rep ignored in live | **PASS** | live path source is always signature; route-server live branch never reads the header (source assertion) |

**5/5 tests pass.** First run failed only because `signLivePayload` required
`AX_X402_PRIVATE_KEY`; the harness now builds the signed payload directly
with the throwaway wallet (no env dependency) — test fixed, not code.

---

## 4. Closure run — Item 3: Kill-switch harness with RPC counter

The Day 8 report's original skip reason (harness would fire ~100 real RPC
calls) was wrong: the kill switch runs BEFORE any RPC. The harness now
**instruments the RPC layer** (`identity.rpcCalled()` counter + file flush
via `AX_RPC_COUNTER_FILE`) and asserts ZERO RPC calls when the switch is ON.

| Test | Result | Evidence |
|---|---|---|
| T0 switch off + live request → normal processing | **PASS** | 200; counter=1 (instrumentation sanity — counts when off) |
| T1 switch ON + valid live request → 503 halted | **PASS** | 503 `{halted, operator_kill_switch}`, clean body, **counter=0 RPC calls** |
| T2 switch off → same request resumes | **PASS** | 200, payment verified live |
| T3 file fallback toggled at runtime | **PASS** | flag create → 503; flag remove → 200, same process, no restart |
| T4 first gate (injection/rate-limit/malformed) | **PASS** | 503 not 422/429/409; **counter=0 under all gates** |

**4/4 tests pass** (T1/T4 include the zero-RPC assertion).

---

## 5. Closure run — Item 4: E2E regressions

Run on the current codebase after all Day 8 changes:

| Suite | Expected | Actual | Result |
|---|---|---|---|
| Day 5 unit | 26/26 | ALL PASS (26 assertions, 5 tests) | ✅ |
| Day 5 E2E | 17/17 | ALL PASS (17 assertions, 5 scenarios) | ✅ |
| Day 6 unit | 21/21 | ALL PASS (21 assertions, 5 tests) | ✅ |
| Day 7 E2E | 4/4 | **4/4 after ONE regression fix** (below) | ✅ |

**Regression found & fixed (Day 7 E2E S3):** S1 (no rep header) and S3
(rep:96) send the IDENTICAL demand body from the same buyer → the Day 8
server-derived idempotency key COLLIDED → S3 got S1's CACHED response
(`no buyer address; no discount`). Fix (minimal, not a test tweak): fold
fee-affecting inputs into the derived-key identity — `deriveKey()` gained an
`extra` field; `route-server.js` passes the `x-mock-buyer-rep` value when
present. After fix, S3 applies the 20% discount and Day 7 E2E is 4/4.

No tests were disabled. No test was modified to match broken behavior; the
code was fixed and the failing scenario re-verified (S3.2 discountPct 0.2 /
finalUsd 0.04 now PASS).

---

## 6. Blockers, route-arounds, divergences

- **Supabase MCP execute_sql permission flakiness** mid-run — routed around:
  verified grants/ACL via targeted queries once access returned; REST probes
  used the anon publishable key (read-only surface) for the security checks.
- **No Supabase env creds in the local shell** — the store adapter falls
  back to in-memory locally (brief-sanctioned route-around); live-project
  verification was done through the MCP SQL path + REST probes.
- **Schema exposure was a second half of the RPC break** — the code fix alone
  wasn't enough; `ax_router` had to be exposed to PostgREST and granted.
  This was a necessary Supabase config change (no money, no wallet, no live
  flip). Logged herein and in the completion report §8 (needs operator
  awareness; not a code divergence).
- **S3 discount regression** (idempotency cached-replay) — fixed in code
  (§5); the root cause was a Day 8 interaction, so it is a closure fix, not a
  new feature.
- **Node stdout quirk with inline `node -e` async** in this environment —
  verification scripts were written to files instead (no impact on build).

---

## 7. What remains before wallet activation

1. Operator acceptance of this Day 8 closure report.
2. Wallet custody decision (raw key env vs Coinbase Agentic Wallet MCP) —
   checklist §12.1.
3. Live-mode swap per checklist §2 (verify → live, feedback → live, payTo).
4. Test-transaction sequence checklist §3 (three $0.01 Base USDC txs) +
   the new Day 8 live tests (idempotency replay, rate-limit boundary,
   kill-switch toggle, reputation-from-signature) per checklist §3 update.
5. PostgREST exposure is DONE as part of this closure (was checklist §12.3);
   confirm before any external reader service.