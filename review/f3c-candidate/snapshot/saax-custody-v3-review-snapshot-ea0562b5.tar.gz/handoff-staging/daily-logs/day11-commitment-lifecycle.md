# AX Router — Day 11: Rail-Agnostic Commitment Lifecycle (Phase 1)

Date: 2026-10-04. Phase 1 of the shift from x402-native to
settlement-method-neutral commitment lifecycle. All seven items implemented,
unit + gateway harness verified, and every Day 8/9/10 regression suite re-run
green. No mainnet transactions. No real funds. No external spend.

---

## 1. Commitment Schema + Manifest Hash Computation

`endpoint/commitment.js` implements the Cedulon Trade Manifest
(draft-dogru-cedulon-core):

```json
{
  "commitmentId": "0x...",
  "buyerAgentId": "0x...",
  "sellerAgentId": "0x...",
  "capability": "security-scan",
  "price": { "amount": "50000", "currency": "USDC", "decimals": 6 },
  "acceptanceCriteria": { "type": "hash", "value": "sha256:..." },
  "deadline": "2026-10-05T12:00:00Z",
  "cancelCondition": "buyer-cancel-before-delivery",
  "manifestHash": "sha256:...",
  "signature": "COSE_Sign1..."
}
```

- **manifestHash** = `sha256:` + SHA-256 of the **signed COSE bytes** (the
  serialized COSE_Sign1 envelope: protected header, payload, signature).
  Verified by the test: `buildManifest()` produces a `sha256:` prefixed 64-hex
  digest; the drain-pipe test re-computes the envelope hash and asserts the
  prefix and length.
- **Signature**: `COSE_Sign1:<65-byte-hex>`. Phase 1 EMULATES the COSE_Sign1
  envelope structurally (RFC 9052 tag + protected header with alg/kid +
  payload + signature). No COSE library or key material is installed; the
  builder accepts an optional `signingHook(payloadBytes) -> signatureHex` so a
  real COSE signer can be plugged in later without changing the API. **The
  emulated envelope is NOT a real cryptographic signature** — treat it as a
  structural placeholder.
- **Manifest before value moves**: the manifest carries NO rail, NO credential,
  NO settlement reference. It is issued before any payment challenge.
- **Spend binding (critical rule)**: `checkSpendBinding(manifest, spend)`
  denies a spend when requested amount or currency differs from the manifest.
  Tested: same amount/currency passes; wrong amount and wrong currency both
  denied.

## 2. R/S Separation — Why x402 Is Not Mandatory

Per the IETF Agent-Initiated Payment Gating draft
(draft-king-yew-choo-agentic-payments):

- **R (requirement)** = `<amt, cur, payee, eta, scheme, t_exp>` — settlement-
  method-NEUTRAL. `eta` is a server-minted single-use nonce; `scheme` is
  `"Payment"`; `t_exp` is the requirement expiry.
- **S (settlement method)** = card, wallet, stablecoin, entitlement — the rail
  that REALISES R, resolved at EXECUTION time, never at commitment time.
- The **commitment** binds the TERMS (amount, currency, payee, acceptance
  criteria). The **rail** knows nothing about the commitment's content; it only
  knows how to realise R.

`endpoint/requirement.js` implements issuance:

- **Exactly one R per commitment**: `issueRequirement(commitmentId, ...)` is
  idempotent — a second issue returns the SAME R (same eta); no nonce churn.
- **Single-use nonce**: `consumeNonce(eta)` consumes on successful gate
  commit (`ok:true`); any later call on the same nonce is rejected
  (`ok:false, reason: "nonce already consumed (replay rejected)"`).
- **Fresh R -> fresh nonce**: a new commitmentId yields a new eta.

## 3. Rail Registry Interface + Adding New Rails

`endpoint/rails/index.js` is the single seam where settlement methods are
registered and resolved:

```js
registry.register('x402', { realise, validate, settle });
const rail = registry.resolve('x402');   // -> implementation or null
registry.list();                          // -> ['x402']
```

Every rail implementation MUST expose:

```js
realise(R): Credential           // turn a neutral requirement into a credential
validate(Credential, R): boolean // is this credential valid FOR R?
settle(Credential): TransactionReference // move value; return PUBLIC tx ref
```

Files:

| File | Status |
|---|---|
| `rails/index.js` | Registry (register/resolve/list) — DONE |
| `rails/x402.js` | Wraps the existing Day 5/9 x402 machinery (mock + self gateway) through the interface — DONE |
| `rails/mpp.js` | Interface-complete STUB (throws NOT_IMPLEMENTED) — DONE (stub) |
| `rails/entitlement.js` | Interface-complete STUB (throws NOT_IMPLEMENTED) — DONE (stub) |

**To add a new rail** (e.g. Stripe): create `rails/stripe.js` exporting
`{ realise, validate, settle }`, then register it where rails are wired
(route-server.js module init): `railsMod.register('stripe', stripeRail)`. The
gateway then advertises it in the 402 challenge's `accepts[]` automatically.

**Why MPP/entitlement are NOT registered in the mock lane**: registration is
the operator's explicit opt-in for a LIVE rail. Stubs are never registered, so
a stub can never be resolved by accident. The gateway advertiser supports
dual-rail (x402 + MPP) when both rails are registered — tested via the
advertiser with an mpp rail present (accepts = [x402, mpp]).

## 4. Spend Receipt Structure + Credential Non-Leakage Rule

`endpoint/receipt.js` builds the Cedulon Spend Receipt:

```json
{
  "receiptId": "0x...",
  "commitmentId": "0x...",
  "manifestHash": "sha256:...",
  "payer": "0x...",
  "payee": "0x...",
  "amount": "50000",
  "currency": "USDC",
  "rail": "x402",
  "railReference": "0xabc123...",
  "settledAt": "2026-10-04T14:32:00Z",
  "noManifest": false,
  "signature": "COSE_Sign1..."
}
```

**Non-leakage rule (enforced + tested)**:
- Rail credentials MUST NOT appear in the receipt, logs, or tool results.
- The receipt carries ONLY the railReference (public transaction identifier) —
  never the signature, credential, or authorization.
- `assertNoCredentialLeakage(receipt)` walks the receipt structurally and
  fails if any x402 credential structure (`authorization`, `accepted`,
  `x402Version`, wire `payload`) is present anywhere.
- The gateway response path emits the receipt but NEVER the credential;
  `G4 NO rail credential material in response` passed on the full body.
- A spend NOT bound to a verified manifest is marked `noManifest:true`
  (derived automatically when no commitmentId+manifestHash are supplied).

## 5. Recovery Interface (Kleros Escrow V2) — Stub

`endpoint/recovery.js` exposes the Kleros Escrow V2 integration interface:

```js
createEscrow(commitment, manifest) -> escrow ID
proposeSettlement(escrowId, amount) -> settlement proposal
acceptSettlement(escrowId) -> finalize
raiseDispute(escrowId, evidence) -> dispute ID
```

Per Phase 1 constraints this is a STUB: the interface is complete and each
method validates its inputs, then throws `NOT_IMPLEMENTED` with a clear error.
Nothing is deployed; the real Kleros integration is a post-mainnet item.

## 6. What Is Implemented vs Stubbed

**Implemented (executed to evidence):**

- Commitment schema + manifest builder (hash computation, COSE_Sign1 envelope,
  spend binding).
- Requirement R issuance (one R per commitment, single-use nonce, replay
  rejection, fresh-nonce-on-fresh-R).
- Rail registry (register/resolve/list) + x402 rail wrapped through the
  interface. Unregistered MPP/entitlement stubs with complete interfaces.
- Gateway commitment flow: manifest issued BEFORE the payment challenge; 402
  carries `commitment` + `requirement`; R nonce consumed on gate commit; spend
  receipt bound to the manifest with railReference; health reports registered
  rails.
- Spend Receipt builder with credential non-leakage.
- Recovery interface stub (Kleros Escrow V2).
- Day 8/9/10 regression suites re-run green against the new flow.

**Stubbed / not implemented (per operator constraints):**

- Real COSE_Sign1 cryptographic signing (structural placeholder + signingHook).
- MPP and entitlement rails (interface-complete stubs only).
- Kleros escrow deployment (interface only).
- Mainnet transactions, real funds, external spend — none.

## 7. How to Test the Full Lifecycle

```bash
# 1) Unit + drain-pipe (Items 1,2,3,5,6): 24 assertions
node endpoint/test-day11-smoke.js

# 2) Gateway commitment flow (Item 4): 17 assertions (spawns /route)
node scripts/test-day11-gateway.js

# 3) Day 8/9/10 regressions (must stay green)
node endpoint/test-day8-item1.js     # idempotency     12/12
node endpoint/test-day8-item2.js     # rate limiting   10/10
node endpoint/test-day8-item3.js     # kill switch     14/14
node endpoint/test-day8-item4.js     # buyer reputation 14/14
node scripts/verify-item6.js         # security sprint  4/4
node scripts/test-gateway.js         # Day 9 gateway harness (dry-run) 38/38
```

All suites above passed on this closure run (see per-suite artifacts).

## 8. Divergences From the Brief

1. **COSE_Sign1 is emulated structurally, not cryptographically** — no COSE
   library or key material exists; the envelope (protected header, payload,
   signature placeholder) is complete and a `signingHook` seam is provided for
   real signing later. The manifest/receipt/requirement signatures are
   `COSE_Sign1:<hex>` tags.
2. **Rail registration is explicit opt-in** — the gateway registers only
   `x402`. MPP/entitlement stubs are never registered (a stub cannot be
   resolved by accident). The challenge advertiser supports dual-rail when both
   rails are registered (verified with the mpp rail present).
3. **R nonce replay is enforced in-process** — the requirement store is
   in-memory (single server instance) for Phase 1; a shared store (Supabase)
   is a later-phase durability item.
4. **The mock lane intentionally stays open under the kill switch** (Day 8
   design — the kill switch halts LIVE processing, not mock testing). The
   halt-before-commitment proof runs the kill-switch server in SELF mode with
   `AX_GATEWAY_DRY_RUN=1` (no funds).