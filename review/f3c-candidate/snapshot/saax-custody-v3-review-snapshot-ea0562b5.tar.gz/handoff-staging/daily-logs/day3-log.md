AX ROUTER — SPRINT 1 DAILY LOG
DAY 3 · Ranking Engine
Date: 2026-10-01 (run f4fff824)

WHAT WAS BUILT
- scripts/rank-suppliers.js: ranking function implementing
  Score = (ReputationScore * 0.6) + (FeedbackFreshness * 0.2) + (PriceCompetitiveness * 0.2),
  with capability match as the primary sort key (specialists first, then
  reputation-ranked generalists). Capability query is sanitized (alphanumeric
  keywords only) — never executed; untrusted-input gate holds.
- Leaderboard supplier pool: data/leaderboard-suppliers-day3.json (5 real
  high-reputation ERC-8004 agents: Surf AI 51085, Captain Dackie 1380, Agent
  2290, Knidos 55985, Agent 7522) probed on-chain + fetched registration files.
- Canonical rep map data/reputation-day3.json (10 scored agents).
- Supabase: 5 leaderboard agents upserted; DB now 124 agents, 10 with reputation.

WHAT WAS TESTED
- 'security scan' -> [SYBIL 84667, Apex Leviathan 85380 (capability match 0.5,
  score 10, no on-chain rep yet)] then [Surf AI 89, Captain Dackie 89, Agent 2290 89].
- 'savings yield deposit' -> [Surf AI (0.67 match, 89), Knidos (0.67, 85 —
  corrected from 10 after explorer validation 91/13,168), aiworker-data, ...].
- Sanitizer strips punctuation/control chars; e.g. a demand text containing
  shell metacharacters yields only plain alphanumeric keywords.
- Staging Researcher independently verified all 5 leaderboard agents registered
  on Base via QuickNode ERC-8004 Explorer (3 sources cited in its brief);
  confirmed SYBIL/Leviathan have zero reputation (cold start).

WHAT BROKE / ROUTED AROUND
- Math.round(x, 4) truncated scores to integers -> fixed to proper 0-100 scale.
- Capability matches were dropped (filtered to topN before reaching sort) -> fixed
  pool selection so matches rank first, generalists fill the rest.
- Direct RPC probe of Knidos 55985 reverted on publicnode -> reputation taken
  from ERC-8004 explorer (91/13,168) and cross-validated by researcher.
- Surf AI composite: explorer shows 90 vs our on-chain probe 99 (matches the
  99.6 'starred' signal) — discrepancy documented; on-chain probe is source
  of truth for the ranker.

WHAT IS MOCKED
- PriceCompetitiveness = neutral 50 (no on-chain price oracle); Layer 3 (Day 5)
  feeds real prices. PayTo = Identity Registry owner address (no settlement).
- FeedbackFreshness = feedback_count proxy (no on-chain timestamp yet).

WHAT IS NEXT
- Day 4: Demand intake endpoint (mock x402 middleware, 402 challenge, ranked
  matches after mock payment header). Foundry Engineer + Payments specialist.