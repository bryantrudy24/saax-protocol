# AX Router — Day 4 Log: Demand Intake Endpoint (Mock Mode)

## PRE-DAY 4 FIXES

### Fix 1 — Configurable Price & Freshness Scoring (APPLIED)
- Extracted into the ranking engine (`scripts/rank-suppliers.js`), read from env at load:
  - **`AX_PRICE_SCORE_DEFAULT`** — default `50` (neutral price-competitiveness, 0–100). Day 5 feeds real prices via x402/MPP probing into this slot; the engine reads the variable, not a literal.
  - **`AX_FRESHNESS_STRATEGY`** — default `count_proxy`. When the archive event-scan resolves missing timestamps, switch to `timestamp_delta` with NO code change (the `feedbackFreshness()` function branches on the strategy). The `timestamp_delta` branch is implemented but behaves as `count_proxy` until real timestamps exist — the engine cannot change behavior without the data to back it.
- Verified: `AX_PRICE_SCORE_DEFAULT=60` propagates (printed `price_default: 60` at rank time).

### Fix 2 — Capability Match Floor (APPLIED)
- **`AX_CAPABILITY_FLOOR`** — chosen default **`0.4`**.
  - Rationale from Day 3 outputs: real capability query "security scan" produced `match=0.5` for the specialist set (SYBIL, Apex Leviathan) and `match=0.0` for pure-reputation generalists. 0.4 admits real matches, rejects non-matches.
- The engine returns explicit `{ status: "no_match", capability, reason: "no supplier meets minimum capability threshold" }` when the top match across ALL indexed suppliers falls below the floor — no generalist fallthrough for capabilities nobody offers.
- Verified: `node scripts/rank-suppliers.js "underwater welding certification"` → `status: no_match` with exact reason (no generalist results).
- Verified on the endpoint too: POST /route with mock header + "underwater welding certification" → `no_match` + reason.

### Fix 3 — RLS on ax_router.agents (APPLIED & VERIFIED)
- Exact SQL applied (via Supabase migration `enable_rls_ax_router_agents_anon_select`):
```sql
ALTER TABLE "ax_router"."agents" ENABLE ROW LEVEL SECURITY;

CREATE POLICY "agents_select_anon"
ON "ax_router"."agents"
FOR SELECT
TO anon
USING (true);
```
- Follow-up required to make the anon read actually reach the policy (schema + base grants; the demand-intake endpoint is public-facing):
```sql
GRANT USAGE ON SCHEMA ax_router TO anon;
GRANT SELECT ON ax_router.agents TO anon;
```
- Verification (role-level, authoritative):
  - `SET ROLE anon; SELECT count(*) FROM ax_router.agents;` → **124 rows read OK**
  - `SET ROLE anon; INSERT INTO ax_router.agents ...` → **ERROR 42501 permission denied** (writes blocked)
  - `pg_policies` shows exactly one policy: `agents_select_anon` | SELECT | anon | true.
- Note: REST boundary (`ax_router` schema is not in PostgREST's exposed schemas) — exposing it is a dashboard/Supabase config change, out of Sprint-1 scope. Documented for the Day 7 wallet checklist.

## DAY 4 — DEMAND INTAKE ENDPOINT

### Route & Hosting
- **Route:** `POST /route` — accepts `{ capability, budget, deadline }` (JSON).
- **Hosting:** local station HTTP server (Vercel reauth pending; per route-around protocol). Port 8080 default (`AX_PORT` to override).
- **Reproduce:**
```
node endpoint/route-server.js
curl -X POST http://localhost:8080/route -H "Content-Type: application/json" -d "{\"capability\":\"security scan\",\"budget\":500,\"deadline\":\"2026-10-08\"}"
```

### Mock x402 flow
- No valid payment header → **HTTP 402** with x402 v2 challenge: `accepts[0]` = `{ scheme: "x402", network: "base", maxAmountRequired: 0.05, payTo: "0x0000...Xp402" (mock), asset: "USDC", resource: "urn:ax-router:route:v1" }`.
- Valid mock header (`x-x402-mock: mock`) → runs the Day 3 ranking engine, returns top 3–5 suppliers with scores + payTo.

### Mock fee logic (Payments)
- Base routing fee **$0.05 USDC on Base** (mock).
- Reputation discount: **10% off** for buyer reputation **>90**, **20% off** for **>95**.
- Buyer reputation queried from ReputationRegistry via the Day 2 layer (`getClients` → `getSummary`). In mock mode the registry key is a buyer address (ReputationRegistry keys by agentId), so the discount tiers are exercised via `x-mock-buyer-rep` header; the decision path is logged per request in the `fee.decision` field.
- Verified tiers: rep 96 → 20% ($0.04 final); rep 92 → 10% ($0.045 final); none → $0.05.

### Security gate (applied at HTTP boundary)
- `capability` sanitized to alphanumeric keywords FIRST, before any ranking/specialist logic. Empty after sanitization → **HTTP 422**.
- Verified: `{"capability":"!!!",...}` → 422 `capability field empty after sanitization`.
- Nothing in capability/budget/deadline is ever executed, evaluated, echoed, or used as a key.

## TEST OUTPUTS (ALL FOUR)
1. `POST /route` no header → **402** + full x402 v2 challenge (above). PASS.
2. `POST /route` + `x-x402-mock: mock` + "security scan" → **200** ranked matches: SYBIL (0.5, payTo 0xea8a…5cc4), Apex Leviathan (0.5, 0x87ef…05d4), then trusted fallbacks Surf AI (89), Captain Dackie (89), Agent 2290 (89). PASS.
3. `POST /route` + mock header + "underwater welding certification" → **200** `{ status: "no_match", reason: "no supplier meets minimum capability threshold" }`. PASS.
4. `POST /route` + mock header + `x-mock-buyer-rep: 96` → fee `discountPct: 0.2, finalUsd: 0.04`, decision `buyer rep 96 >= 95 -> 20% off`. PASS.

## MOCKED vs REAL vs NEXT
- **Mocked:** payment header validation (any `x-x402-mock: mock` accepted), payTo address, fee settlement ($0.05 simulated), buyer reputation discount tiers (via header), x402 signing.
- **Real:** ranking engine (124 agents, 10 with real on-chain reputation), capability match + floor, reputation fetch layer (Day 2), sanitization gate, RLS policy on agents table.
- **Next:** Day 5 payment routing logic (x402 vs MPP selection, mock signing, mock receipts).

## BLOCKERS / ROUTE-AROUNDS
- Vercel reauth pending → local hosting (documented above). No impact on build.
- `ax_router` schema not exposed to PostgREST REST API → RLS verified at role level (SQL), which is authoritative; REST exposure is a dashboard config item for Day 7 checklist.
- Buyer reputation: ReputationRegistry keys by agentId not buyer address — discount tiers exercised via mock header in Sprint 1; real buyer-side reputation feed deferred to Layer 4/5 wiring.

## DAILY SUMMARY (5 lines)
- Built: POST /route endpoint with mock x402 middleware, fee + reputation discount logic, sanitization gate at the HTTP boundary; applied Fix 1 (AX_PRICE_SCORE_DEFAULT=50, AX_FRESHNESS_STRATEGY=count_proxy), Fix 2 (AX_CAPABILITY_FLOOR=0.4), Fix 3 (RLS + anon SELECT-only policy).
- Tested: 402 challenge, ranked matches for "security scan", no_match for "underwater welding certification", 20%/10% buyer fee discounts, 422 on empty sanitized capability; RLS read 124 / write denied.
- Broke: nothing (all four tests pass; RLS verification surfaced schema-exposure gap, logged).
- Mocked: payment header, payTo, fee settlement, buyer-rep discount input; everything payment-path is mock per Sprint 1.
- Next: Day 5 payment routing (x402 vs MPP decision tree, mock signing + receipts).