# SAAX Escrow Custody — Phase 5 Security Review Package

**Status:** PREPARED for independent review — this document is NOT an independent audit.
It is the vendor's (SAAX's) own review, assembled so an external reviewer can reproduce every claim.
**Date:** Day 20b. **Scope:** `contracts/SAAXEscrowCustodyV1.sol` + the Phase 4 application integration.
**Deployed testnet artifact (current):** `0x5a5472d751839cd4968cbf1b136baf862279ff5d` (Base Sepolia 84532).
Older deployments `0x76cce76caf348199fe8756f7f253f981f21477ae` and `0xf85abb3bcd8c7183e8b81d51d739fdb2980f6ce6` exist from earlier phases (funless flows); the Phase 4 app flow uses `0x5a5472...`.

---

## 1. Trust model and authority (explicit)

| Authority | Holder | Effect |
|---|---|---|
| Evaluator | `SAAX_SIGNER_PRIVATE_KEY` (testnet operator) | The ONLY signature that authorizes `release` / `refund` / `resolve` verdicts (EIP-712). |
| Buyer | `SAAX_TEST_BUYER_KEY` | Funds escrow (`fund` via allowance); may `raiseDispute`; receives `refund`. |
| Seller | external address (`0x9830...`) | Receives `release`; may `raiseDispute`. |
| Anyone (relayer) | n/a | May CALL `release`/`refund`/`resolve`/`raiseDispute`; the call only succeeds if the embedded verdict is valid (relayer-friendly, no authority). |
| Admin / owner / upgrade | **NONE exists** | No `owner`, no `upgrade`, no `pause`, no `withdraw`. Funds move ONLY via `release` (to seller) or `refund` (to buyer). |

**Testnet note:** in the current test setup one operator controls buyer AND evaluator keys (labeled in the broadcast harness). This is a TEST-ONLY simplification; the contract itself does not assume it.

## 2. Signature domain and replay protection

- EIP-712 domain: `name="SAAX Escrow Custody V1"`, `version="1"`, `chainId` (bound at construction from `block.chainid`), `verifyingContract = address(this)`.
  - Chain + contract binding prevents cross-chain and cross-deployment verdict replay.
- Verdict type: `EscrowVerdict(bytes32 commitmentId, bytes32 commitmentDigest, string action, uint256 nonce, uint256 issuedAt)`.
  - commitmentId + digest bind the verdict to ONE escrow.
  - `action` distinguishes release/refund/hold — a release verdict cannot authorize a refund.
- Nonce: `usedVerdictNonce[nonce]` — one-time use (revert `Replay` on reuse).
- Time window: `issuedAt` must be ≤ now+120s and ≥ now−300s (revert `NotYetValid` / `ExpiredVerdict`) — verdicts are short-lived, signed near the action.

## 3. Funding cannot be falsely recorded or duplicated

- `fund` reverts if: `commitmentId==0` / `commitmentDigest==0` / any party address==0 (`WrongDigest`); `buyer==seller` (`SelfTransfer`); `amount==0`; `escrows[id].state != None` (`WrongState` — already-funded ids cannot be re-funded).
- The token movement (`_safeTransferFrom(token, msg.sender, this, amount)`) happens BEFORE the state write: a failed transfer reverts the whole tx; the escrow is never recorded funded without the funds actually landing. Verified by the eth_call-validated fund + on-chain balance checks.

## 4. Release/refund mutual exclusivity and balance limits

- Terminal states are exclusive: `release` requires `state == Funded`; `refund` requires `state == Funded`; after one terminal write the other reverts (`WrongState`).
- Amount is frozen at `fund` (the escrow's `amount`); a terminal action moves exactly that amount via `_safeTransfer`; the custody's balance must cover the sum of outstanding funded escrows. No amount can exceed held funds because each escrow's `amount` was pulled in at fund time (and the contract does not hold free balance beyond outstanding escrows).
- `resolve` (dispute path) also moves exactly `e.amount` to seller (release) or buyer (refund), or `hold` (state stays Disputed).

## 5. Token transfer handling (day-20 hardening)

- All movements go through `_safeTransferFrom` / `_safeTransfer`:
  - `token == address(0)` → `InvalidToken`.
  - Explicit `false` return → `TransferFailed`.
  - Reverting call → `TransferFailed` (propagated).
  - No-return tokens: supported — the **exact balance-delta check** (before/after `balanceOf`) proves the movement.
  - **Fee-on-transfer / rebasing not supported:** the exact-delta comparison reverts on any mismatch. NOTE (documented limitation): exact-delta does NOT prove rejection of EVERY hypothetical rebasing token; this deployment is constrained to the verified Base Sepolia test USDC `0x036CbD53842c5426634e7929541eC2318f3dCF7e` only.
- Ordering: token movement BEFORE state write + success event; a failed movement leaves no terminal state and no success event.

## 6. Reentrancy and effects ordering

- `nonReentrant` mutex on `fund`/`release`/`refund`/`raiseDispute`/`resolve`.
- Checks → token movement → state write → event (checks-effects-interactions). The external token call completes before any state mutation, so a malicious token cannot reenter into a half-updated escrow.

## 7. Deadline boundaries

- `fund` accepts any `deadline` (bound from the commitment terms); a `deadline` in the past makes the escrow immediately timeout-refundable (used deliberately in Flow B).
- `release` gates on `block.timestamp >= minReleaseTime` (default 0).
- `refund` without a signature requires `block.timestamp >= deadline` (`DeadlineNotPassed` otherwise).
- Evaluator verdicts have their own 120s/300s window (independent of the escrow deadline).

## 8. Dispute liveness (explicit analysis)

- **Who can open:** ONLY the escrow's buyer or seller (`NotParty` otherwise) — an unrelated wallet cannot freeze funds (proof: harness case "unauthorized raiseDispute reverts", state stays Funded).
- **Who resolves:** ONLY the evaluator's signed verdict via `resolve(..., resolution: release|refund|hold)`.
- **Timeout after dispute:** NO — once Disputed, `refund` reverts (`WrongState` because state != Funded); funds stay frozen until `resolve`. This is a DELIBERATE tradeoff (no unilateral exit), now explicit.
- **Evaluator disappears:** pre-dispute → deadline timeout refund recovers funds (no signature needed). POST-dispute → **funds can remain locked indefinitely** if the evaluator never signs a resolution. There is no admin override, no second exit — by design (adding a unilateral withdrawal would change the trust model and requires explicit authorization).
- **Permanent lock:** YES in exactly one scenario: Disputed + evaluator never resolves. Documented; not "fixed" without authorization.

## 9. Integration (Phase 4) review

- The application's escrow-backed mode (`SAAX_ESCROW_BACKED=1`) reads the ACTUAL contract via `escrow.verifyOnChain()` (getEscrow tuple + chain/RPC check); it never trusts the DB or in-memory `escrowStatus()`.
- Reject paths (proven against live contracts): unfunded → 402; terminal (released/refunded/timed_out) → 402; non-84532 chain → 402 (`testnet-only`); provider/RPC mismatch → 402.
- The branch short-circuits the direct `settleAuthorization` transfer; it does NOT call Circle settlement or create a second payment. Circle /verify still runs (payment authorization), but funding proof is the contract read.
- Receipt identity: response body carries `escrow` block (mode, commitmentId, digest, custody, amount, asset, parties, deadline, state, verifiedOnChain); PAYMENT-RESPONSE header reports `status: escrow-funded` (never a false "settled" for the custody pathway).
- **Escrow-backed mode is NOT enabled in production** (flag + chain 84532 guard; production mainnet fails safe).

## 10. Adversarial test evidence (reproducible)

Harness: `node scripts/_escrow-custody-harness.cjs` → **51 passed, 0 failed**. Covers:
- Successful fund/release/refund; no-return token; false-return failure; reverting transfer; invalid target (addr0); fee-on-transfer rejection.
- Wrong-actor (non-evaluator) verdict → revert; wrong digest → revert; replay nonce → revert; expired verdict → revert; release-after-refund / refund-after-release → revert (terminal).
- raiseDispute: buyer ok, seller ok, attacker reverts; state stays Funded on attacker attempt; Disputed after authorized raise; timeout refund during dispute reverts; state stays Disputed past deadline; evaluator resolve → release (seller paid) [resolve->release verified].

Real testnet evidence (Base Sepolia 84532, custody `0x5a5472...`):
- Flow A release: fund tx `0xd03afb4cdc4298a103073f1422e489d8fbedd39c6b32e47c27cfd3d58e8672c3`; release tx `0xfa2ae379d0f6562039deba5e4e47637e941bcba9d11312f00deb5e31af02489b`; escrow state RELEASED; seller paid; custody 0.
- Flow B refund: fund (past deadline) + refund tx `0x543b679f1769beba2d4cba4ae183609c173c655416cbc20b780dcc6e5641f9d4`; escrow state REFUNDED; buyer repaid; custody 0.
- Reject evidence via the app endpoint: unfunded / terminal / non-84532 (all 402, from the contract read).

## 11. What an external reviewer should independently verify

1. Compile `contracts/SAAXEscrowCustodyV1.sol` (solc 0.8.26) and compare the deployed code hash at `0x5a5472...` with the artifact's creation-tx code (deployment tx created the runtime visible on-chain).
2. Re-run the harness (51 cases) on a local EVM with the identical bytecode.
3. Read `getEscrow(commitmentId)` on-chain for the Flow A/B commitment ids and confirm state/parties/amounts.
4. Check the Funded/Released/Refunded event logs for the two flows (public chain data).
5. Confirm the `SAAX_ESCROW_BACKED=1` app path rejects unfunded/terminal/non-84532 without touching Circle settlement.
6. Assess the documented dispute-liveness limitation (post-dispute freeze without evaluator) against the project's risk posture.

## 12. Remaining decision needed (not blocked)

- **Dispute liveness:** whether post-dispute freeze is acceptable, or a governed secondary exit (e.g., buyer/seller mutual consent, or a long-delay escape) should be added — REQUIRES explicit authorization (trust-model change).
- **Mainnet readiness:** NOT claimed. Needs the independent review, the liveness decision, and a production custody deployment decision.

*End of vendor review package — prepared for independent review; not an independent audit.*