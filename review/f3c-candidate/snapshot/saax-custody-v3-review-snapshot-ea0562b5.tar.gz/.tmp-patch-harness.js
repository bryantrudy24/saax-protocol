// one-off: make test-gateway.js signing path-aware (EIP-3009 on mainnet, EIP-2612 default)
const fs = require('fs');
const p = 'scripts/test-gateway.js';
let c = fs.readFileSync(p, 'utf8');
let count = 0;

// --- 1) Replace the eip3009Message + signAuthorization + wireAuth block ---
const oldBlock = `function eip3009Message(buyerAccount, sellerAddress, valueRaw, { validAfter, validBefore, nonce }) {
  return {
    owner: buyerAccount.address.toLowerCase(),
    spender: sellerAddress.toLowerCase(),
    value: BigInt(valueRaw),
    nonce: BigInt(nonce),
    deadline: BigInt(validBefore),
  };
}

async function signAuthorization(buyerAccount, sellerAddress, valueRaw, domain, { validAfter, validBefore, nonce }) {
  const message = eip3009Message(buyerAccount, sellerAddress, valueRaw, { validAfter, validBefore, nonce });
  const wallet = createWalletClient({ account: buyerAccount, chain: gateway.baseSepolia, transport: viemHttp() });
  const signature = await wallet.signTypedData({
    domain,
    types: gateway.EIP3009_TYPES,
    primaryType: 'Permit',
    message,
  });
  return { message, signature };
}`;
const newBlock = `// Active signature path (Day 14 mainnet): resolved once up-front from the
// gateway's dual-path probe/pin. eip3009 = Base MAINNET USDC
// (transferWithAuthorization, bytes32 nonce, to=vault); eip2612 = Base
// Sepolia FiatTokenV2 (Permit, uint256 counter).
let ACTIVE_SIG_PATH = 'eip2612';

// EIP-2612 Permit message (FiatTokenV2-style). from=owner, to=spender (the
// signer/broadcaster), nonce = uint256 counter, validBefore=deadline.
function eip2612Message(buyerAccount, signerAddress, valueRaw, { validAfter, validBefore, nonce }) {
  return {
    owner: buyerAccount.address.toLowerCase(),
    spender: signerAddress.toLowerCase(),
    value: BigInt(valueRaw),
    nonce: BigInt(nonce),
    deadline: BigInt(validBefore),
  };
}

// EIP-3009 TransferWithAuthorization message (Base MAINNET USDC). from =
// buyer, to = VAULT (the direct transfer destination), nonce = bytes32 hex,
// validAfter/validBefore are signed fields.
function eip3009Message(buyerAccount, vaultAddress, valueRaw, { validAfter, validBefore, nonce }) {
  return {
    from: buyerAccount.address.toLowerCase(),
    to: vaultAddress.toLowerCase(),
    value: BigInt(valueRaw),
    validAfter: BigInt(validAfter),
    validBefore: BigInt(validBefore),
    nonce: nonce, // bytes32 hex (0x + 64 hex)
  };
}

async function signAuthorization(buyerAccount, recipientAddress, valueRaw, domain, { validAfter, validBefore, nonce }) {
  const wallet = createWalletClient({ account: buyerAccount, chain: gateway.baseSepolia, transport: viemHttp() });
  if (ACTIVE_SIG_PATH === 'eip3009') {
    const message = eip3009Message(buyerAccount, recipientAddress, valueRaw, { validAfter, validBefore, nonce });
    const signature = await wallet.signTypedData({
      domain,
      types: gateway.EIP3009_TRANSFER_TYPES,
      primaryType: 'TransferWithAuthorization',
      message,
    });
    return { message, signature };
  }
  const message = eip2612Message(buyerAccount, recipientAddress, valueRaw, { validAfter, validBefore, nonce });
  const signature = await wallet.signTypedData({
    domain,
    types: gateway.EIP3009_TYPES,
    primaryType: 'Permit',
    message,
  });
  return { message, signature };
}`;
if (!c.includes(oldBlock)) { console.error('BLOCK 1 NOT FOUND'); process.exit(1); }
c = c.replace(oldBlock, newBlock); count++;

// --- 2) wireAuth -> path-aware (eip3009: nonce is hex already; from/to straight) ---
const oldWire = `function wireAuth(message, validAfter, validBefore) {
  return {
    from: message.owner,
    to: message.spender,
    value: String(message.value),
    validAfter: String(validAfter),
    validBefore: String(validBefore),
    nonce: String(message.nonce),
  };
}`;
const newWire = `function wireAuth(message, validAfter, validBefore) {
  if (ACTIVE_SIG_PATH === 'eip3009') {
    return {
      from: message.from,
      to: message.to,
      value: String(message.value),
      validAfter: String(message.validAfter),
      validBefore: String(message.validBefore),
      nonce: message.nonce,
    };
  }
  return {
    from: message.owner,
    to: message.spender,
    value: String(message.value),
    validAfter: String(validAfter),
    validBefore: String(validBefore),
    nonce: String(message.nonce),
  };
}`;
if (!c.includes(oldWire)) { console.error('BLOCK 2 NOT FOUND'); process.exit(1); }
c = c.replace(oldWire, newWire); count++;

// --- 3) Resolve ACTIVE_SIG_PATH + path-aware nonce sourcing in the IIFE ---
const oldStart = `(async () => {
  console.log('========== SAAX Protocol \u2014 DAY 9: SELF-HOSTED x402 GATEWAY E2E ==========');
  console.log('mode: ' + (USE_DRY_RUN ? 'DRY RUN (no real broadcast; SAAX_GATEWAY_DRY_RUN=1)' : 'LIVE BROADCAST (testnet USDC; wallets must be funded)'));
  console.log('signer address (hot wallet, broadcasts):', gateway.getSignerAddress() || '(none \u2014 check .env SAAX_SIGNER_ADDRESS)');
  console.log('vault address (cold storage, receives):', gateway.getVaultAddress() || '(none \u2014 check .env SAAX_VAULT_ADDRESS)');
  console.log('signer key loaded:', !!gateway.loadSignerKey());
  const domain = gateway.domainFor();`;
const newStart = `(async () => {
  console.log('========== SAAX Protocol \u2014 DAY 14: SELF-HOSTED x402 GATEWAY E2E ==========');
  console.log('mode: ' + (USE_DRY_RUN ? 'DRY RUN (no real broadcast; SAAX_GATEWAY_DRY_RUN=1)' : 'LIVE BROADCAST (USDC; wallets must be funded)'));
  console.log('active chain id:', gateway.BASE_SEPOLIA_CHAIN_ID, '(SAAX_CHAIN_ID=' + (process.env.SAAX_CHAIN_ID || '84532 (default testnet)') + ')');
  console.log('active asset:', gateway.USDC_BASE_SEPOLIA);
  console.log('active network:', gateway.NETWORK_CAIP2_BASE_SEPOLIA);
  console.log('signer address (hot wallet, broadcasts):', gateway.getSignerAddress() || '(none \u2014 check .env SAAX_SIGNER_ADDRESS)');
  console.log('vault address (cold storage, receives):', gateway.getVaultAddress() || '(none \u2014 check .env SAAX_VAULT_ADDRESS)');
  console.log('signer key loaded:', !!gateway.loadSignerKey());
  const domain = gateway.domainFor();
  // Resolve the active signature path (dual-path probe/pin) BEFORE scenarios.
  try {
    const pathInfo = await gateway.getSignaturePath({ asset: gateway.USDC_BASE_SEPOLIA, chainId: gateway.BASE_SEPOLIA_CHAIN_ID });
    ACTIVE_SIG_PATH = pathInfo.path;
    console.log('signature path:', ACTIVE_SIG_PATH, '(' + (pathInfo.evidence && pathInfo.evidence.source || '') + ')');
  } catch (e) {
    console.log('WARN could not resolve signature path (default eip2612): ' + String(e.message || e).slice(0, 80));
  }`;
if (!c.includes(oldStart)) { console.error('BLOCK 3 NOT FOUND'); process.exit(1); }
c = c.replace(oldStart, newStart); count++;

// --- 4) path-aware nonce sourcing: read counter only for eip2612 ---
const oldNonceRead = `  let permitNonceCounter = 0;
  if (!USE_DRY_RUN) {
    try {
      const { createPublicClient } = require('viem');
      const pub = createPublicClient({ chain: gateway.baseSepolia, transport: viemHttp() });
      const abi = [{ name: 'nonces', type: 'function', stateMutability: 'view', inputs: [{ name: 'a', type: 'address' }], outputs: [{ name: '', type: 'uint256' }] }];
      const n = await pub.readContract({ address: gateway.USDC_BASE_SEPOLIA, abi, functionName: 'nonces', args: [buyerAccount.address] });
      permitNonceCounter = Number(n);
      console.log('buyer permit nonce starts at:', permitNonceCounter);
    } catch (e) {
      console.log('WARN could not read on-chain permit nonce (using 0): ' + (e.message || e).slice(0, 80));
    }
  }
  const nextPermitNonce = () => permitNonceCounter++;`;
const newNonceRead = `  let permitNonceCounter = 0;
  if (!USE_DRY_RUN && ACTIVE_SIG_PATH !== 'eip3009') {
    try {
      const { createPublicClient } = require('viem');
      const pub = createPublicClient({ chain: gateway.baseSepolia, transport: viemHttp() });
      const abi = [{ name: 'nonces', type: 'function', stateMutability: 'view', inputs: [{ name: 'a', type: 'address' }], outputs: [{ name: '', type: 'uint256' }] }];
      const n = await pub.readContract({ address: gateway.USDC_BASE_SEPOLIA, abi, functionName: 'nonces', args: [buyerAccount.address] });
      permitNonceCounter = Number(n);
      console.log('buyer permit nonce starts at:', permitNonceCounter);
    } catch (e) {
      console.log('WARN could not read on-chain permit nonce (using 0): ' + (e.message || e).slice(0, 80));
    }
  }
  // Path-aware nonce source: eip3009 = fresh random bytes32 per settlement
  // (EIP-3009 uses a random 32-byte nonce, not a counter); eip2612 = counter.
  const nextPermitNonce = () => {
    if (ACTIVE_SIG_PATH === 'eip3009') return '0x' + crypto.randomBytes(32).toString('hex');
    return permitNonceCounter++;
  };`;
if (!c.includes(oldNonceRead)) { console.error('BLOCK 4 NOT FOUND'); process.exit(1); }
c = c.replace(oldNonceRead, newNonceRead); count++;

// --- 5) T1 network assertion -> dynamic (active network, not hardcoded 84532) ---
const oldT1 = `    check('T1 network eip155:84532', prDecoded && prDecoded.network === 'eip155:84532', prDecoded && prDecoded.network);`;
const newT1 = `    check('T1 network = ' + gateway.NETWORK_CAIP2_BASE_SEPOLIA, prDecoded && prDecoded.network === gateway.NETWORK_CAIP2_BASE_SEPOLIA, prDecoded && prDecoded.network);`;
if (!c.includes(oldT1)) { console.error('BLOCK 5 NOT FOUND'); process.exit(1); }
c = c.replace(oldT1, newT1); count++;

// --- 6) T10 assertion: on eip3009 path, the 'Base Sepolia selects EIP-2612' check must not demand eip2612
const oldT10 = `    const want2612 = String(process.env.SAAX_X402_SIGNATURE_PATH || '').toLowerCase() !== 'eip3009';
    check('T10 Base Sepolia selects EIP-2612 (permit) path', want2612 ? pathInfo.path === 'eip2612' : true,
      'path=' + pathInfo.path + ' (testnet FiatTokenV2 expected eip2612 unless pinned)');`;
const newT10 = `    const want2612 = String(process.env.SAAX_X402_SIGNATURE_PATH || '').toLowerCase() !== 'eip3009';
    check('T10 active chain selects consistent path', (gateway.BASE_SEPOLIA_CHAIN_ID === 84532) ? (want2612 ? pathInfo.path === 'eip2612' : true) : (pathInfo.path === 'eip3009' || pathInfo.path === 'eip2612'),
      'path=' + pathInfo.path + ' (testnet FiatTokenV2 expected eip2612 unless pinned; mainnet expected eip3009)');`;
if (!c.includes(oldT10)) { console.error('BLOCK 6 NOT FOUND'); process.exit(1); }
c = c.replace(oldT10, newT10); count++;

fs.writeFileSync(p, c);
console.log('harness patched; replacements:', count, '; ACTIVE_SIG_PATH refs:', (c.match(/ACTIVE_SIG_PATH/g) || []).length);