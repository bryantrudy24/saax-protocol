// SAAX Protocol — commitment persistence adapter (CJS).
//
// Persists commitments issued by gateway.commitmentFlow.issueFromPayload into
// the Supabase ax_router.commitments table via the upsert_commitment RPC.
//
// Design notes:
//  - Mirrors endpoint/store.js's PostgREST client pattern (schema-scoped
//    requests via Accept-Profile/Content-Profile, SUPABASE_URL + anon key).
//    store.js uses the 'saax_router' schema by default; the commitments RPCs
//    live there and are granted EXECUTE to anon, so the anon key suffices for
//    BOTH writes (upsert) and reads (lookups).
//  - The persist call is ADDITIVE: the commitment is issued (manifest built,
//    requirement R derived) exactly as before, and persistence is a fire-
//    and-forget side effect with error logging. A persistence failure must
//    never block or change the issuance return contract (route-server keeps
//    responding exactly as today). Real durability is enforced at the
//    MCP read layer: get_commitment / list_commitments / get_commitment_status
//    read from Supabase (the source of truth).
const STORE_BASE_URL = (process.env.SUPABASE_URL || process.env.SAAX_SUPABASE_URL || '').trim();
const STORE_KEY = process.env.SUPABASE_ANON_KEY || process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.SAAX_SUPABASE_KEY || '';
const SCHEMA = 'ax_router';

// Minimal schema-scoped PostgREST client (same shape store.js builds).
function buildClient() {
  const base = String(STORE_BASE_URL).trim().replace(/\/+$/, '');
  const isPlatform = /supabase\.co/i.test(base);
  const PREFIX = isPlatform ? '/rest/v1' : '';
  const headers = {
    apikey: STORE_KEY,
    Authorization: 'Bearer ' + STORE_KEY,
    'Accept-Profile': SCHEMA,
    'Content-Profile': SCHEMA,
    'Content-Type': 'application/json',
  };
  return {
    async rpc(fn, params) {
      const res = await fetch(base + PREFIX + '/rpc/' + fn, {
        method: 'POST',
        headers,
        body: JSON.stringify(params || {}),
      });
      if (res.status >= 400) {
        const txt = (await res.text()).slice(0, 300);
        return { data: null, error: new Error('RPC ' + fn + ' -> ' + res.status + ' ' + txt) };
      }
      const body = await res.json();
      return { data: body, error: null };
    },
  };
}

function isConfigured() {
  return !!(STORE_BASE_URL && STORE_KEY);
}

// Persist a commitment row. Non-throwing: returns { ok, error? }.
async function persistCommitment({ commitmentId, state, capability, buyerEmail, terms, authorityRef, evidenceRefs, settlementRef, manifestHash }) {
  if (!isConfigured()) return { ok: false, error: 'commitment persistence skipped: SUPABASE_URL/SUPABASE_ANON_KEY not configured' };
  try {
    const client = buildClient();
    const { data, error } = await client.rpc('upsert_commitment', {
      p_commitment_id: commitmentId,
      p_state: state || 'issued',
      p_capability: capability,
      p_buyer_email: buyerEmail,
      p_terms: terms || {},
      p_authority_ref: authorityRef,
      p_evidence_refs: (evidenceRefs && evidenceRefs.length) ? evidenceRefs : [],
      p_settlement_ref: settlementRef,
      p_manifest_hash: manifestHash,
    });
    if (error) throw error;
    return { ok: true, data };
  } catch (e) {
    console.error('[commitment-store] upsert_commitment failed:', e.message);
    return { ok: false, error: e.message };
  }
}

// Persist the settlement linkage on an already-issued commitment row.
//
// upsert_commitment is a FULL-COLUMN upsert: on conflict it overwrites every
// column with the passed values. A partial re-upsert would wipe the row's
// other fields (state, terms, buyer_email, ...). So this replays the complete
// issuance record with settlementRef added — the safe, additive form.
async function persistSettlementRef({ commitmentId, state, capability, buyerEmail, terms, authorityRef, evidenceRefs, settlementRef, manifestHash }) {
  if (!isConfigured()) return { ok: false, error: 'commitment persistence skipped: SUPABASE_URL/SUPABASE_ANON_KEY not configured' };
  if (!commitmentId || !settlementRef) return { ok: false, error: 'commitmentId and settlementRef are required' };
  try {
    const client = buildClient();
    const { data, error } = await client.rpc('upsert_commitment', {
      p_commitment_id: commitmentId,
      p_state: state || 'issued',
      p_capability: capability,
      p_buyer_email: buyerEmail,
      p_terms: terms || {},
      p_authority_ref: authorityRef,
      p_evidence_refs: (evidenceRefs && evidenceRefs.length) ? evidenceRefs : [],
      p_settlement_ref: typeof settlementRef === 'string' ? settlementRef : JSON.stringify(settlementRef),
      p_manifest_hash: manifestHash,
    });
    if (error) throw error;
    return { ok: true, data };
  } catch (e) {
    console.error('[commitment-store] persistSettlementRef failed:', e.message);
    return { ok: false, error: e.message };
  }
}

module.exports = { persistCommitment, persistSettlementRef, isConfigured, SCHEMA };