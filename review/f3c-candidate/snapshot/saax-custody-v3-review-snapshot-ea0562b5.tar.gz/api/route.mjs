// SAAX Protocol — /route as a Vercel serverless function.
//
// Converts endpoint/route-server.js's handleRoute (a Node http handler) into a
// Vercel function. handleRoute(req, res, body) is fully self-contained: it
// reads req.method / req.headers / req.url and writes via res.writeHead / res.end.
// The standalone server now guards its listener behind require.main, so this
// module can import handleRoute without starting a socket.
import { handleRoute } from "../endpoint/route-server.js";

export const config = { runtime: "nodejs", maxDuration: 60 };

/**
 * Vercel handler: adapts the incoming request to the shape handleRoute expects.
 * Only POST /route is supported (matches the standalone server's routing).
 */
export default async function handler(req, res) {
  // CORS preflight (matched by vercel.json headers, but handle it explicitly).
  if (req.method === "OPTIONS") {
    res.status(204).end();
    return;
  }

  const url = new URL(req.url || "/", "http://localhost");
  if (req.method !== "POST" || url.pathname !== "/route") {
    res.statusCode = 404;
    res.setHeader("Content-Type", "application/json");
    res.end(JSON.stringify({ error: "not found" }));
    return;
  }

  // Buffer the raw body (handleRoute expects a string; it parses internally).
  const chunks = [];
  for await (const chunk of req) {
    chunks.push(typeof chunk === "string" ? chunk : Buffer.from(chunk).toString("utf8"));
    if (chunks.join("").length > 64 * 1024) break;
  }
  const body = chunks.join("");

  // Adapter: handleRoute calls res.writeHead(status, headers) and res.end(string).
  const adaptedRes = {
    writeHead(status, headers) {
      res.statusCode = status;
      for (const [k, v] of Object.entries(headers || {})) res.setHeader(k, v);
    },
    end(payload) {
      if (!res.headersSent) {
        if (!res.getHeader("Content-Type")) res.setHeader("Content-Type", "application/json");
        res.end(payload === undefined ? "" : String(payload));
      } else {
        res.end(payload === undefined ? "" : String(payload));
      }
    },
  };

  // handleRoute also uses req.headers (payment-signature, idempotency-key,
  // x-mock-*, x-x402-mock) and req.method — Vercel's req has all of these.
  try {
    await handleRoute(req, adaptedRes, body);
  } catch (e) {
    if (!res.headersSent) {
      res.statusCode = 500;
      res.setHeader("Content-Type", "application/json");
    }
    res.end(JSON.stringify({ error: "internal error", reason: String(e.message || e).slice(0, 300) }));
  }
}