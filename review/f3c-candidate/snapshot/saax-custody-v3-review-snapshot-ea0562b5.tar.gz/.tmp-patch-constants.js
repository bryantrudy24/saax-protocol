// one-off: replace the chain/asset constants block in gateway.js (project dir)
const fs = require('fs');
const p = 'endpoint/gateway.js';
const c = fs.readFileSync(p, 'utf8');
const old = `const BASE_SEPOLIA_CHAIN_ID = 84532;
const baseSepolia = defineChain({
  id: BASE_SEPOLIA_CHAIN_ID,
  name: 'Base Sepolia',
  network: 'base-sepolia',
  nativeCurrency: { name: 'Ether', symbol: 'ETH', decimals: 18 },
  rpcUrls: {
    default: {
      http: [process.env.SAAX_BASE_SEPOLIA_RPC || 'https://sepolia.base.org'],
    },
  },
  blockExplorers: {
    default: { name: 'BaseScan', url: 'https://base-sepolia.blockscout.com' },
  },
});
const NETWORK_CAIP2_BASE_SEPOLIA = 'eip155:84532';
const USDC_BASE_SEPOLIA = '0x036CbD53842c5426634e7929541eC2318f3dCF7e';
const USDC_DECIMALS = 6;`;
const next = `// ---------------------------------------------------------------------------
// Active chain / asset selection (MAINNET ACTIVATION, Day 14).
// The gateway is chain-selectable via env (defaults: Base Sepolia testnet):
//   SAAX_CHAIN_ID        84532 (Base Sepolia) | 8453 (Base mainnet)
//   SAAX_X402_ASSET      USDC contract for the active chain
//   SAAX_RPC_URL         RPC endpoint for the active chain
//   SAAX_NETWORK_CAIP2   caip-2 network id (defaults to eip155:<CHAIN_ID>)
// The exported names BASE_SEPOLIA_* / baseSepolia are LEGACY ALIASES that
// resolve to the ACTIVE chain, so every consumer (route-server, harness,
// rails) follows the .env switch without further edits. Mainnet USDC
// (0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913) implements EIP-3009; the
// dual-path probe selects transferWithAuthorization automatically.
const BASE_SEPOLIA_CHAIN_ID = 84532;   // legacy name; ACTIVE_CHAIN_ID below is used
const USDC_BASE_SEPOLIA_ADDR = '0x036CbD53842c5426634e7929541eC2318f3dCF7e'; // legacy testnet USDC
const USDC_MAINNET_BASE_ADDR = '0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913';
const ACTIVE_CHAIN_ID = Number(process.env.SAAX_CHAIN_ID || 84532);
const ACTIVE_ASSET = String(process.env.SAAX_X402_ASSET || (
  ACTIVE_CHAIN_ID === 8453 ? USDC_MAINNET_BASE_ADDR : USDC_BASE_SEPOLIA_ADDR
)).trim();
const ACTIVE_RPC = String(process.env.SAAX_RPC_URL || (
  ACTIVE_CHAIN_ID === 8453 ? 'https://mainnet.base.org' : 'https://sepolia.base.org'
)).trim();
const ACTIVE_NETWORK_CAIP2 = String(
  process.env.SAAX_NETWORK_CAIP2 || ('eip155:' + ACTIVE_CHAIN_ID)
).trim();
// Active chain object (resolves the RPC + native currency per chain).
const baseSepolia = defineChain({
  id: ACTIVE_CHAIN_ID,
  name: ACTIVE_CHAIN_ID === 8453 ? 'Base' : 'Base Sepolia',
  network: ACTIVE_CHAIN_ID === 8453 ? 'base' : 'base-sepolia',
  nativeCurrency: { name: 'Ether', symbol: 'ETH', decimals: 18 },
  rpcUrls: {
    default: { http: [ACTIVE_RPC] },
  },
  blockExplorers: {
    default: { name: 'BaseScan', url: ACTIVE_CHAIN_ID === 8453 ? 'https://basescan.org' : 'https://base-sepolia.blockscout.com' },
  },
});
// Legacy aliases (exported; consumed by route-server, harness, mpp rail).
const NETWORK_CAIP2_BASE_SEPOLIA = ACTIVE_NETWORK_CAIP2;
const USDC_BASE_SEPOLIA = ACTIVE_ASSET;
const USDC_DECIMALS = 6;`;
if (!c.includes(old)) { console.error('OLD BLOCK NOT FOUND'); process.exit(1); }
fs.writeFileSync(p, c.replace(old, next));
console.log('constants block replaced OK; new length', fs.readFileSync(p, 'utf8').length);